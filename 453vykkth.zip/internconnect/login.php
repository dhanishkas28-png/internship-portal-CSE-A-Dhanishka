<?php
session_start();

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $role = $_POST["role"] ?? "";



    if ($role === "admin") {

        $adminEmail = "admin@internconnect.com";
        $adminPassword = "admin123";

        if ($email === $adminEmail && $password === $adminPassword) {

            $_SESSION["admin_logged_in"] = true;
            $_SESSION["admin_email"] = $email;

            header("Location: admin/dashboard.php");
            exit();

        } else {

            $message = "Invalid Admin email or password!";
        }
    }

    

    elseif ($role === "company") {

        $companyEmail = "company@internconnect.com";
        $companyPassword = "company123";

        if ($email === $companyEmail && $password === $companyPassword) {

            $_SESSION["company_logged_in"] = true;
            $_SESSION["company_email"] = $email;
            $_SESSION["company_name"] = "InternConnect Company";

            header("Location: company/dashboard.php");
            exit();

        } else {

            $message = "Invalid Company email or password!";
        }
    }

    

    elseif ($role === "student") {

        if (
            isset($_SESSION["registered_email"]) &&
            isset($_SESSION["registered_password"]) &&
            $email === $_SESSION["registered_email"] &&
            $password === $_SESSION["registered_password"]
        ) {

            $_SESSION["user_id"] = 1;
            $_SESSION["user_name"] = $_SESSION["registered_name"];
            $_SESSION["user_email"] = $email;

            header("Location: student/dashboard.php");
            exit();

        } else {

            $message = "Invalid Student email or password!";
        }
    }

    else {

        $message = "Please select your login role!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>InternConnect - Login</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {

    min-height: 100vh;

    font-family: Arial, Helvetica, sans-serif;

    background:
        radial-gradient(circle at 10% 20%, rgba(212,175,112,0.12), transparent 28%),
        radial-gradient(circle at 90% 80%, rgba(212,175,112,0.08), transparent 30%),
        linear-gradient(135deg, #070D18, #0B1220 55%, #111827);

    color: #F8FAFC;

    display: flex;
    align-items: center;
    justify-content: center;

    padding: 30px;

    position: relative;
    overflow: hidden;
}

body::before {

    content: "";

    position: absolute;

    width: 280px;
    height: 280px;

    border: 1px solid rgba(212,175,112,0.18);

    border-radius: 50%;

    top: -100px;
    left: -90px;
}

body::after {

    content: "";

    position: absolute;

    width: 360px;
    height: 360px;

    border: 1px solid rgba(212,175,112,0.12);

    border-radius: 50%;

    bottom: -170px;
    right: -120px;
}

.login-wrapper {

    width: 100%;
    max-width: 1050px;

    min-height: 620px;

    display: grid;

    grid-template-columns: 1fr 1fr;

    background: rgba(15, 23, 42, 0.82);

    border: 1px solid rgba(212,175,112,0.18);

    border-radius: 28px;

    overflow: hidden;

    box-shadow:
        0 30px 80px rgba(0,0,0,0.45),
        0 0 50px rgba(212,175,112,0.05);

    backdrop-filter: blur(18px);

    position: relative;

    z-index: 2;
}


.login-info {

    padding: 55px;

    background:
        linear-gradient(
            145deg,
            rgba(212,175,112,0.10),
            rgba(11,18,32,0.45)
        );

    display: flex;

    flex-direction: column;

    justify-content: center;

    border-right: 1px solid rgba(255,255,255,0.08);
}

.logo {

    display: flex;

    align-items: center;

    gap: 12px;

    margin-bottom: 55px;
}

.logo-mark {

    width: 48px;
    height: 48px;

    border-radius: 14px;

    background: linear-gradient(
        135deg,
        #D4AF70,
        #B88A3B
    );

    color: #0B1220;

    display: flex;

    align-items: center;
    justify-content: center;

    font-size: 18px;

    font-weight: 900;

    box-shadow:
        0 8px 25px rgba(212,175,112,0.20);
}

.logo-text {

    font-size: 23px;

    font-weight: 800;

    color: #F8FAFC;
}

.logo-text span {

    color: #D4AF70;
}

.info-title {

    font-size: 42px;

    line-height: 1.12;

    color: #F8FAFC;

    margin-bottom: 20px;
}

.info-title span {

    color: #D4AF70;
}

.info-description {

    color: #AAB4C3;

    font-size: 16px;

    line-height: 1.7;

    max-width: 390px;

    margin-bottom: 35px;
}

.benefits {

    display: flex;

    flex-direction: column;

    gap: 16px;
}

.benefit {

    display: flex;

    align-items: center;

    gap: 13px;

    color: #D8DEE8;

    font-size: 14px;
}

.benefit-icon {

    width: 34px;
    height: 34px;

    border-radius: 10px;

    display: flex;

    align-items: center;
    justify-content: center;

    background: rgba(212,175,112,0.12);

    border: 1px solid rgba(212,175,112,0.22);

    color: #D4AF70;

    font-weight: bold;
}


.login-section {

    padding: 55px;

    background: rgba(9, 15, 27, 0.65);

    display: flex;

    flex-direction: column;

    justify-content: center;
}

.login-heading {

    margin-bottom: 25px;
}

.login-heading h2 {

    font-size: 30px;

    color: #F8FAFC;

    margin-bottom: 8px;
}

.login-heading p {

    color: #8F9AAA;

    font-size: 14px;
}



.error {

    background: rgba(185, 28, 28, 0.14);

    border: 1px solid rgba(248,113,113,0.25);

    color: #FCA5A5;

    padding: 12px 14px;

    border-radius: 12px;

    text-align: center;

    margin-bottom: 20px;

    font-size: 14px;
}



.role-title {

    display: block;

    margin-bottom: 10px;

    color: #DDE3EC;

    font-size: 14px;

    font-weight: 600;
}

.role-container {

    display: grid;

    grid-template-columns: repeat(3, 1fr);

    gap: 10px;

    margin-bottom: 22px;
}

.role-option {

    position: relative;
}

.role-option input {

    position: absolute;

    opacity: 0;

    pointer-events: none;
}

.role-label {

    display: flex;

    flex-direction: column;

    align-items: center;

    justify-content: center;

    gap: 6px;

    min-height: 78px;

    padding: 10px;

    border-radius: 13px;

    border: 1px solid rgba(148,163,184,0.18);

    background: rgba(255,255,255,0.045);

    color: #AAB4C3;

    cursor: pointer;

    transition: 0.25s;

    text-align: center;

    font-size: 12px;

    font-weight: 700;
}

.role-icon {

    font-size: 23px;
}

.role-option input:checked + .role-label {

    border-color: #D4AF70;

    background: rgba(212,175,112,0.12);

    color: #D4AF70;

    box-shadow:
        0 0 0 2px rgba(212,175,112,0.06);
}

.role-label:hover {

    border-color: rgba(212,175,112,0.55);

    transform: translateY(-2px);
}


.form-group {

    margin-bottom: 18px;
}

label {

    display: block;

    margin-bottom: 8px;

    color: #DDE3EC;

    font-size: 14px;

    font-weight: 600;
}

.input-box {

    position: relative;
}

.input-box span {

    position: absolute;

    left: 15px;

    top: 50%;

    transform: translateY(-50%);

    color: #8B97A8;

    font-size: 15px;
}

input[type="email"],
input[type="password"] {

    width: 100%;

    padding: 14px 15px 14px 43px;

    border-radius: 12px;

    border: 1px solid rgba(148,163,184,0.18);

    background: rgba(255,255,255,0.045);

    color: #F8FAFC;

    font-size: 14px;

    outline: none;

    transition: 0.25s;
}

input::placeholder {

    color: #687588;
}

input[type="email"]:focus,
input[type="password"]:focus {

    border-color: #D4AF70;

    background: rgba(255,255,255,0.07);

    box-shadow:
        0 0 0 3px rgba(212,175,112,0.08);
}



button {

    width: 100%;

    padding: 15px;

    margin-top: 7px;

    border: none;

    border-radius: 12px;

    background: linear-gradient(
        135deg,
        #D4AF70,
        #B98A42
    );

    color: #0B1220;

    font-size: 15px;

    font-weight: 800;

    cursor: pointer;

    transition: 0.25s;

    box-shadow:
        0 10px 25px rgba(212,175,112,0.16);
}

button:hover {

    transform: translateY(-2px);

    box-shadow:
        0 14px 30px rgba(212,175,112,0.25);
}



.register-link {

    text-align: center;

    margin-top: 23px;

    color: #8793A5;

    font-size: 14px;
}

.register-link a {

    color: #D4AF70;

    text-decoration: none;

    font-weight: 700;
}

.register-link a:hover {

    text-decoration: underline;
}

.home-link {

    text-align: center;

    margin-top: 18px;
}

.home-link a {

    color: #7F8A9B;

    text-decoration: none;

    font-size: 13px;

    transition: 0.2s;
}

.home-link a:hover {

    color: #D4AF70;
}

.security-note {

    margin-top: 25px;

    padding-top: 18px;

    border-top: 1px solid rgba(255,255,255,0.07);

    text-align: center;

    color: #667386;

    font-size: 11px;
}



@media (max-width: 800px) {

    body {

        padding: 18px;
    }

    .login-wrapper {

        grid-template-columns: 1fr;

        max-width: 500px;

        min-height: auto;
    }

    .login-info {

        padding: 38px 30px;

        border-right: none;

        border-bottom: 1px solid rgba(255,255,255,0.08);
    }

    .logo {

        margin-bottom: 35px;
    }

    .info-title {

        font-size: 32px;
    }

    .info-description {

        font-size: 14px;
    }

    .login-section {

        padding: 38px 30px;
    }
}

@media (max-width: 420px) {

    body {

        padding: 10px;
    }

    .login-info,
    .login-section {

        padding: 28px 22px;
    }

    .info-title {

        font-size: 28px;
    }

    .login-heading h2 {

        font-size: 26px;
    }

    .role-container {

        gap: 6px;
    }

    .role-label {

        min-height: 70px;

        font-size: 11px;
    }
}

</style>

</head>

<body>

<div class="login-wrapper">

    

    <div class="login-info">

        <div class="logo">

            <div class="logo-mark">
                IC
            </div>

            <div class="logo-text">
                Intern<span>Connect</span>
            </div>

        </div>

        <h1 class="info-title">

            Welcome back to
            <span>your future.</span>

        </h1>

        <p class="info-description">

            Connect students, companies and administrators
            in one premium internship platform.

        </p>

        <div class="benefits">

            <div class="benefit">

                <div class="benefit-icon">
                    ✓
                </div>

                <span>
                    Discover internship opportunities
                </span>

            </div>

            <div class="benefit">

                <div class="benefit-icon">
                    ✓
                </div>

                <span>
                    Track applications easily
                </span>

            </div>

            <div class="benefit">

                <div class="benefit-icon">
                    ✓
                </div>

                <span>
                    Connect students with companies
                </span>

            </div>

        </div>

    </div>


    

    <div class="login-section">

        <div class="login-heading">

            <h2>
                Welcome Back
            </h2>

            <p>
                Select your role and login to continue
            </p>

        </div>


        <?php if ($message !== ""): ?>

            <div class="error">

                <?php echo htmlspecialchars($message); ?>

            </div>

        <?php endif; ?>


        <form method="POST" action="">

            <!-- ROLE -->

            <span class="role-title">
                Login As
            </span>

            <div class="role-container">

                <div class="role-option">

                    <input
                        type="radio"
                        id="student"
                        name="role"
                        value="student"
                        checked
                    >

                    <label
                        for="student"
                        class="role-label"
                    >

                        <span class="role-icon">
                            👩‍🎓
                        </span>

                        Student

                    </label>

                </div>


                <div class="role-option">

                    <input
                        type="radio"
                        id="company"
                        name="role"
                        value="company"
                    >

                    <label
                        for="company"
                        class="role-label"
                    >

                        <span class="role-icon">
                            🏢
                        </span>

                        Company

                    </label>

                </div>


                <div class="role-option">

                    <input
                        type="radio"
                        id="admin"
                        name="role"
                        value="admin"
                    >

                    <label
                        for="admin"
                        class="role-label"
                    >

                        <span class="role-icon">
                            👨‍💼
                        </span>

                        Admin

                    </label>

                </div>

            </div>


            <!-- EMAIL -->

            <div class="form-group">

                <label>
                    Email Address
                </label>

                <div class="input-box">

                    <span>✉</span>

                    <input
                        type="email"
                        name="email"
                        placeholder="Enter your email"
                        required
                    >

                </div>

            </div>


            

            <div class="form-group">

                <label>
                    Password
                </label>

                <div class="input-box">

                    <span>🔒</span>

                    <input
                        type="password"
                        name="password"
                        placeholder="Enter your password"
                        required
                    >

                </div>

            </div>


            <button type="submit">
                Login to InternConnect →
            </button>

        </form>


        <div class="register-link">

            Student don't have an account?

            <a href="register.php">
                Create Account
            </a>

        </div>


        <div class="home-link">

            <a href="index.php">
                ← Back to Home
            </a>

        </div>


        <div class="security-note">

            🔐 Your account information is securely handled.

        </div>

    </div>

</div>

</body>

</html>