<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>InternConnect</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<header class="topbar">

    <div class="logo">
        <span>Intern</span>Connect
    </div>

    <nav>
        <a href="index.php">Home</a>

        <?php if (isset($_SESSION['user_id'])): ?>

            <a href="student/dashboard.php">Dashboard</a>
            <a href="student/internships.php">Internships</a>
            <a href="student/profile.php">Profile</a>
            <a href="logout.php">Logout</a>

        <?php else: ?>

            <a href="login.php">Login</a>
            <a href="register.php" class="nav-button">Register</a>

        <?php endif; ?>

    </nav>

</header>

<main class="main-container">