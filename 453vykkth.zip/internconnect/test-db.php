<?php

require_once "database.php";

echo "DATABASE CONNECTED SUCCESSFULLY";

?>