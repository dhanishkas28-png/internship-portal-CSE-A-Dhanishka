<?php
session_start();

if (
    !isset($_SESSION["company_logged_in"]) ||
    $_SESSION["company_logged_in"] !== true
) {
    header("Location: ../login.php");
    exit();
}

$companyName = $_SESSION["company_name"] ?? "InternConnect Company";
$message = "";
$messageType = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $title = trim($_POST["title"] ?? "");
    $location = trim($_POST["location"] ?? "");
    $category = trim($_POST["category"] ?? "");
    $skills = trim($_POST["skills"] ?? "");
    $stipend = trim($_POST["stipend"] ?? "");
    $duration = trim($_POST["duration"] ?? "");
    $description = trim($_POST["description"] ?? "");

    if (
        $title === "" ||
        $location === "" ||
        $category === "" ||
        $skills === "" ||
        $stipend === "" ||
        $duration === "" ||
        $description === ""
    ) {
        $message = "Please fill all fields.";
        $messageType = "error";
    } else {

        if (!isset($_SESSION["company_internships"])) {
            $_SESSION["company_internships"] = [];
        }

        $internship = [
            "id" => time(),
            "title" => $title,
            "company" => $companyName,
            "location" => $location,
            "category" => $category,
            "skills" => $skills,
            "stipend" => $stipend,
            "duration" => $duration,
            "description" => $description,
            "status" => "Active",
            "created_at" => date("d M Y")
        ];

        $_SESSION["company_internships"][] = $internship;

        $message = "Internship posted successfully!";
        $messageType = "success";

        $_POST = [];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Post Internship | InternConnect</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Segoe UI", Arial, sans-serif;
            background: #0B1220;
            color: #f8f4ea;
            min-height: 100vh;
        }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            height: 100vh;
            background: #0d1728;
            border-right: 1px solid rgba(212,175,112,0.20);
            padding: 30px 18px;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0 12px 35px;
        }

        .logo-box {
            width: 45px;
            height: 45px;
            border-radius: 14px;
            background: linear-gradient(135deg,#D4AF70,#f2d59a);
            color: #0B1220;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: 900;
            font-size: 18px;
        }

        .logo-text {
            font-size: 20px;
            font-weight: 800;
        }

        .menu-title {
            color: #7e899c;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 0 14px 12px;
        }

        .menu a {
            display: block;
            text-decoration: none;
            color: #aeb7c7;
            padding: 14px;
            border-radius: 12px;
            margin-bottom: 7px;
            transition: 0.3s;
        }

        .menu a:hover,
        .menu a.active {
            background: rgba(212,175,112,0.12);
            color: #D4AF70;
        }

        .main {
            margin-left: 250px;
            padding: 35px 45px;
            min-height: 100vh;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 35px;
        }

        .topbar h1 {
            font-size: 30px;
        }

        .badge {
            border: 1px solid rgba(212,175,112,0.35);
            color: #D4AF70;
            padding: 9px 16px;
            border-radius: 30px;
            font-size: 13px;
        }

        .card {
            max-width: 950px;
            background: rgba(255,255,255,0.035);
            border: 1px solid rgba(212,175,112,0.18);
            border-radius: 24px;
            padding: 35px;
            box-shadow: 0 25px 70px rgba(0,0,0,0.28);
        }

        .card-header {
            margin-bottom: 30px;
        }

        .card-header h2 {
            color: #D4AF70;
            font-size: 25px;
            margin-bottom: 8px;
        }

        .card-header p {
            color: #8f9aad;
            line-height: 1.6;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 22px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .full {
            grid-column: 1 / -1;
        }

        label {
            margin-bottom: 9px;
            color: #d9dce3;
            font-size: 14px;
            font-weight: 600;
        }

        input,
        select,
        textarea {
            width: 100%;
            border: 1px solid rgba(255,255,255,0.10);
            background: #111c2e;
            color: #f8f4ea;
            padding: 14px 15px;
            border-radius: 12px;
            outline: none;
            font-size: 14px;
            transition: 0.3s;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: #D4AF70;
            box-shadow: 0 0 0 3px rgba(212,175,112,0.08);
        }

        textarea {
            min-height: 140px;
            resize: vertical;
        }

        select option {
            background: #111c2e;
        }

        .message {
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-size: 14px;
        }

        .success {
            background: rgba(52,211,153,0.10);
            border: 1px solid rgba(52,211,153,0.35);
            color: #6ee7b7;
        }

        .error {
            background: rgba(248,113,113,0.10);
            border: 1px solid rgba(248,113,113,0.35);
            color: #fca5a5;
        }

        .button-row {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 30px;
        }

        .btn {
            text-decoration: none;
            border: none;
            cursor: pointer;
            padding: 14px 24px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 14px;
        }

        .cancel {
            background: rgba(255,255,255,0.06);
            color: #c6ccd7;
        }

        .submit {
            background: linear-gradient(135deg,#D4AF70,#f0d295);
            color: #0B1220;
            box-shadow: 0 10px 25px rgba(212,175,112,0.18);
        }

        .submit:hover {
            transform: translateY(-2px);
        }

        @media (max-width: 850px) {

            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }

            .main {
                margin-left: 0;
                padding: 25px 18px;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .full {
                grid-column: auto;
            }

            .topbar {
                gap: 15px;
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>

<body>

<aside class="sidebar">

    <div class="logo">
        <div class="logo-box">IC</div>
        <div class="logo-text">InternConnect</div>
    </div>

    <div class="menu-title">Company Portal</div>

    <div class="menu">

        <a href="dashboard.php">
            🏠 Dashboard
        </a>

        <a href="post-internship.php" class="active">
            ➕ Post Internship
        </a>

        <a href="internships.php">
            💼 My Internships
        </a>

        <a href="applications.php">
            📄 Applications
        </a>

        <a href="profile.php">
            👤 Company Profile
        </a>

        <a href="../logout.php">
            🚪 Logout
        </a>

    </div>

</aside>


<main class="main">

    <div class="topbar">

        <h1>Post Internship</h1>

        <div class="badge">
            Company Portal
        </div>

    </div>


    <div class="card">

        <div class="card-header">

            <h2>Create a New Opportunity</h2>

            <p>
                Share your internship opportunity and connect with talented students.
            </p>

        </div>


        <?php if ($message !== ""): ?>

            <div class="message <?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>

        <?php endif; ?>


        <form method="POST">

            <div class="form-grid">

                <div class="form-group">

                    <label>Internship Title</label>

                    <input
                        type="text"
                        name="title"
                        placeholder="Example: PHP Developer Intern"
                        value="<?php echo htmlspecialchars($_POST["title"] ?? ""); ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Location</label>

                    <input
                        type="text"
                        name="location"
                        placeholder="Example: Chennai / Remote"
                        value="<?php echo htmlspecialchars($_POST["location"] ?? ""); ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Category</label>

                    <select name="category" required>

                        <option value="">Select Category</option>

                        <option value="Web Development">Web Development</option>

                        <option value="PHP Development">PHP Development</option>

                        <option value="Python">Python</option>

                        <option value="Data Science">Data Science</option>

                        <option value="AI & Machine Learning">
                            AI & Machine Learning
                        </option>

                        <option value="Java Development">
                            Java Development
                        </option>

                        <option value="Cyber Security">
                            Cyber Security
                        </option>

                        <option value="Cloud Computing">
                            Cloud Computing
                        </option>

                        <option value="UI/UX Design">
                            UI/UX Design
                        </option>

                        <option value="Mobile App Development">
                            Mobile App Development
                        </option>

                    </select>

                </div>


                <div class="form-group">

                    <label>Required Skills</label>

                    <input
                        type="text"
                        name="skills"
                        placeholder="PHP, MySQL, HTML, CSS"
                        value="<?php echo htmlspecialchars($_POST["skills"] ?? ""); ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Stipend</label>

                    <input
                        type="text"
                        name="stipend"
                        placeholder="Example: ₹12,000 / month"
                        value="<?php echo htmlspecialchars($_POST["stipend"] ?? ""); ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Duration</label>

                    <select name="duration" required>

                        <option value="">Select Duration</option>

                        <option value="1 Month">1 Month</option>

                        <option value="2 Months">2 Months</option>

                        <option value="3 Months">3 Months</option>

                        <option value="4 Months">4 Months</option>

                        <option value="6 Months">6 Months</option>

                    </select>

                </div>


                <div class="form-group full">

                    <label>Internship Description</label>

                    <textarea
                        name="description"
                        placeholder="Describe the internship, responsibilities, requirements and learning opportunities..."
                        required
                    ><?php echo htmlspecialchars($_POST["description"] ?? ""); ?></textarea>

                </div>

            </div>


            <div class="button-row">

                <a href="dashboard.php" class="btn cancel">
                    Cancel
                </a>

                <button type="submit" class="btn submit">
                    Publish Internship →
                </button>

            </div>

        </form>

    </div>

</main>

</body>
</html>