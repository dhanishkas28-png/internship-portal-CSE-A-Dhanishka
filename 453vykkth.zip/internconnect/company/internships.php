<?php
session_start();

if (
    !isset($_SESSION["company_logged_in"]) ||
    $_SESSION["company_logged_in"] !== true
) {
    header("Location: ../login.php");
    exit();
}

$companyName = $_SESSION["company_name"] ?? "InternConnect Company";

$internships = $_SESSION["company_internships"] ?? [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Internships | InternConnect</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Segoe UI", Arial, sans-serif;
            background: #0B1220;
            color: #f8f4ea;
            min-height: 100vh;
        }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            height: 100vh;
            background: #0d1728;
            border-right: 1px solid rgba(212,175,112,0.20);
            padding: 30px 18px;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0 12px 35px;
        }

        .logo-box {
            width: 45px;
            height: 45px;
            border-radius: 14px;
            background: linear-gradient(135deg,#D4AF70,#f2d59a);
            color: #0B1220;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: 900;
            font-size: 18px;
        }

        .logo-text {
            font-size: 20px;
            font-weight: 800;
        }

        .menu-title {
            color: #7e899c;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 0 14px 12px;
        }

        .menu a {
            display: block;
            text-decoration: none;
            color: #aeb7c7;
            padding: 14px;
            border-radius: 12px;
            margin-bottom: 7px;
            transition: 0.3s;
        }

        .menu a:hover,
        .menu a.active {
            background: rgba(212,175,112,0.12);
            color: #D4AF70;
        }

        .main {
            margin-left: 250px;
            padding: 35px 45px;
            min-height: 100vh;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 35px;
        }

        .topbar h1 {
            font-size: 30px;
        }

        .badge {
            border: 1px solid rgba(212,175,112,0.35);
            color: #D4AF70;
            padding: 9px 16px;
            border-radius: 30px;
            font-size: 13px;
        }

        .intro {
            margin-bottom: 30px;
        }

        .intro h2 {
            font-size: 25px;
            color: #D4AF70;
            margin-bottom: 8px;
        }

        .intro p {
            color: #8f9aad;
        }

        .actions {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 25px;
        }

        .post-btn {
            text-decoration: none;
            background: linear-gradient(135deg,#D4AF70,#f0d295);
            color: #0B1220;
            padding: 13px 22px;
            border-radius: 12px;
            font-weight: 800;
            transition: 0.3s;
        }

        .post-btn:hover {
            transform: translateY(-2px);
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 22px;
        }

        .card {
            background: rgba(255,255,255,0.035);
            border: 1px solid rgba(212,175,112,0.18);
            border-radius: 22px;
            padding: 25px;
            transition: 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
            border-color: rgba(212,175,112,0.45);
            box-shadow: 0 20px 45px rgba(0,0,0,0.25);
        }

        .card-top {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 18px;
        }

        .category {
            color: #D4AF70;
            font-size: 12px;
            font-weight: 700;
            background: rgba(212,175,112,0.10);
            padding: 7px 10px;
            border-radius: 20px;
        }

        .status {
            color: #6ee7b7;
            font-size: 12px;
            background: rgba(52,211,153,0.10);
            padding: 7px 10px;
            border-radius: 20px;
        }

        .card h3 {
            font-size: 20px;
            margin-bottom: 13px;
            line-height: 1.35;
        }

        .company {
            color: #b4bdca;
            font-size: 14px;
            margin-bottom: 17px;
        }

        .info {
            display: grid;
            gap: 9px;
            color: #8f9aad;
            font-size: 13px;
            margin-bottom: 18px;
        }

        .skills {
            color: #c9cdd5;
            font-size: 13px;
            line-height: 1.6;
            border-top: 1px solid rgba(255,255,255,0.07);
            padding-top: 16px;
        }

        .description {
            color: #8f9aad;
            font-size: 13px;
            line-height: 1.6;
            margin-top: 15px;
        }

        .date {
            margin-top: 18px;
            color: #6f7a8e;
            font-size: 11px;
        }

        .empty {
            background: rgba(255,255,255,0.035);
            border: 1px solid rgba(212,175,112,0.18);
            border-radius: 22px;
            padding: 70px 25px;
            text-align: center;
        }

        .empty-icon {
            font-size: 55px;
            margin-bottom: 18px;
        }

        .empty h2 {
            color: #D4AF70;
            margin-bottom: 10px;
        }

        .empty p {
            color: #8f9aad;
            margin-bottom: 25px;
        }

        @media (max-width: 1100px) {
            .grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 850px) {
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }

            .main {
                margin-left: 0;
                padding: 25px 18px;
            }

            .grid {
                grid-template-columns: 1fr;
            }

            .topbar {
                gap: 15px;
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>

<body>

<aside class="sidebar">

    <div class="logo">
        <div class="logo-box">IC</div>
        <div class="logo-text">InternConnect</div>
    </div>

    <div class="menu-title">Company Portal</div>

    <div class="menu">

        <a href="dashboard.php">
            🏠 Dashboard
        </a>

        <a href="post-internship.php">
            ➕ Post Internship
        </a>

        <a href="internships.php" class="active">
            💼 My Internships
        </a>

        <a href="applications.php">
            📄 Applications
        </a>

        <a href="profile.php">
            👤 Company Profile
        </a>

        <a href="../logout.php">
            🚪 Logout
        </a>

    </div>

</aside>


<main class="main">

    <div class="topbar">

        <h1>My Internships</h1>

        <div class="badge">
            Company Portal
        </div>

    </div>


    <div class="intro">

        <h2>
            Your Internship Opportunities
        </h2>

        <p>
            Manage the internship opportunities posted by
            <?php echo htmlspecialchars($companyName); ?>.
        </p>

    </div>


    <div class="actions">

        <a href="post-internship.php" class="post-btn">
            + Post New Internship
        </a>

    </div>


    <?php if (empty($internships)): ?>

        <div class="empty">

            <div class="empty-icon">
                💼
            </div>

            <h2>No Internships Yet</h2>

            <p>
                You haven't posted any internship opportunities yet.
            </p>

            <a href="post-internship.php" class="post-btn">
                Post Your First Internship
            </a>

        </div>

    <?php else: ?>

        <div class="grid">

            <?php foreach ($internships as $internship): ?>

                <div class="card">

                    <div class="card-top">

                        <span class="category">
                            <?php echo htmlspecialchars($internship["category"]); ?>
                        </span>

                        <span class="status">
                            ● <?php echo htmlspecialchars($internship["status"]); ?>
                        </span>

                    </div>


                    <h3>
                        <?php echo htmlspecialchars($internship["title"]); ?>
                    </h3>


                    <div class="company">
                        🏢 <?php echo htmlspecialchars($internship["company"]); ?>
                    </div>


                    <div class="info">

                        <div>
                            📍 <?php echo htmlspecialchars($internship["location"]); ?>
                        </div>

                        <div>
                            💰 <?php echo htmlspecialchars($internship["stipend"]); ?>
                        </div>

                        <div>
                            ⏱ <?php echo htmlspecialchars($internship["duration"]); ?>
                        </div>

                    </div>


                    <div class="skills">

                        <strong>Skills:</strong>

                        <?php echo htmlspecialchars($internship["skills"]); ?>

                    </div>


                    <div class="description">

                        <?php echo htmlspecialchars($internship["description"]); ?>

                    </div>


                    <div class="date">

                        Posted on
                        <?php echo htmlspecialchars($internship["created_at"]); ?>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

</main>

</body>
</html>