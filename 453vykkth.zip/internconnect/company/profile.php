<?php
session_start();

if (!isset($_SESSION["company_logged_in"]) || $_SESSION["company_logged_in"] !== true) {
    header("Location: ../login.php");
    exit();
}

$companyName = $_SESSION["company_name"] ?? "InternConnect Company";
$companyEmail = $_SESSION["company_email"] ?? "company@internconnect.com";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $newName = trim($_POST["company_name"] ?? "");
    $newEmail = trim($_POST["company_email"] ?? "");

    if ($newName !== "" && $newEmail !== "") {
        $_SESSION["company_name"] = $newName;
        $_SESSION["company_email"] = $newEmail;

        $companyName = $newName;
        $companyEmail = $newEmail;

        $message = "Company profile updated successfully!";
    } else {
        $message = "Please fill all fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Company Profile | InternConnect</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: #0B1220;
    color: #F8F1E5;
    min-height: 100vh;
}

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    background: #101827;
    border-right: 1px solid rgba(212,175,112,0.25);
    padding: 28px 18px;
}

.logo {
    text-align: center;
    font-size: 28px;
    font-weight: bold;
    color: #D4AF70;
    margin-bottom: 45px;
}

.nav a {
    display: block;
    text-decoration: none;
    color: #B8B8B8;
    padding: 14px 18px;
    margin: 8px 0;
    border-radius: 12px;
    transition: 0.3s;
}

.nav a:hover,
.nav a.active {
    background: rgba(212,175,112,0.12);
    color: #D4AF70;
}

.logout {
    position: absolute;
    bottom: 30px;
    left: 18px;
    right: 18px;
}

.logout a {
    display: block;
    text-align: center;
    padding: 13px;
    border: 1px solid rgba(212,175,112,0.4);
    border-radius: 12px;
    color: #D4AF70;
    text-decoration: none;
}

.main {
    margin-left: 250px;
    padding: 45px;
}

.topbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 35px;
}

.topbar h1 {
    font-size: 30px;
}

.badge {
    padding: 10px 18px;
    border-radius: 30px;
    background: rgba(212,175,112,0.12);
    color: #D4AF70;
    border: 1px solid rgba(212,175,112,0.3);
}

.profile-card {
    max-width: 700px;
    background: #111C2D;
    border: 1px solid rgba(212,175,112,0.25);
    border-radius: 22px;
    padding: 35px;
    box-shadow: 0 20px 50px rgba(0,0,0,0.25);
}

.profile-icon {
    width: 85px;
    height: 85px;
    border-radius: 50%;
    background: #D4AF70;
    color: #0B1220;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 35px;
    margin-bottom: 25px;
}

.profile-card h2 {
    margin-bottom: 8px;
}

.subtitle {
    color: #9EA6B5;
    margin-bottom: 30px;
}

label {
    display: block;
    margin-bottom: 8px;
    color: #D4AF70;
}

input {
    width: 100%;
    padding: 15px;
    margin-bottom: 22px;
    background: #0B1220;
    border: 1px solid #2A3547;
    border-radius: 12px;
    color: white;
    outline: none;
}

input:focus {
    border-color: #D4AF70;
}

button {
    width: 100%;
    padding: 15px;
    border: none;
    border-radius: 12px;
    background: #D4AF70;
    color: #0B1220;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
}

button:hover {
    opacity: 0.9;
}

.message {
    margin-bottom: 25px;
    padding: 14px;
    border-radius: 10px;
    background: rgba(212,175,112,0.12);
    color: #D4AF70;
}

@media(max-width: 800px) {
    .sidebar {
        width: 210px;
    }

    .main {
        margin-left: 210px;
        padding: 25px;
    }
}

@media(max-width: 600px) {
    .sidebar {
        position: relative;
        width: 100%;
        height: auto;
    }

    .logout {
        position: relative;
        left: auto;
        right: auto;
        bottom: auto;
        margin-top: 20px;
    }

    .main {
        margin-left: 0;
    }
}
</style>
</head>

<body>

<div class="sidebar">

    <div class="logo">IC</div>

    <div class="nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="post-internship.php">Post Internship</a>
        <a href="internships.php">My Internships</a>
        <a href="applications.php">Applications</a>
        <a href="profile.php" class="active">Company Profile</a>
    </div>

    <div class="logout">
        <a href="../logout.php">Logout</a>
    </div>

</div>

<div class="main">

    <div class="topbar">
        <h1>Company Profile</h1>
        <div class="badge">Company Portal</div>
    </div>

    <div class="profile-card">

        <div class="profile-icon">🏢</div>

        <h2>Company Information</h2>

        <p class="subtitle">
            Manage your InternConnect company profile.
        </p>

        <?php if ($message !== ""): ?>
            <div class="message">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <label>Company Name</label>

            <input
                type="text"
                name="company_name"
                value="<?php echo htmlspecialchars($companyName); ?>"
                required
            >

            <label>Company Email</label>

            <input
                type="email"
                name="company_email"
                value="<?php echo htmlspecialchars($companyEmail); ?>"
                required
            >

            <button type="submit">
                Update Company Profile
            </button>

        </form>

    </div>

</div>

</body>
</html>