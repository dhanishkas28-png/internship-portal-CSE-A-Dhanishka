<?php

session_start();

if (
    !isset($_SESSION["company_logged_in"]) ||
    $_SESSION["company_logged_in"] !== true
) {
    header("Location: ../login.php");
    exit();
}

$companyName = $_SESSION["company_name"] ?? "InternConnect Company";

$applications = $_SESSION["applications"] ?? [];

$companyApplications = $applications;

$total = count($companyApplications);

$pending = 0;
$approved = 0;
$rejected = 0;

foreach ($companyApplications as $application) {

    $status = $application["status"] ?? "Pending";

    if ($status === "Pending") {

        $pending++;

    } elseif ($status === "Approved") {

        $approved++;

    } elseif ($status === "Rejected") {

        $rejected++;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Applications | InternConnect</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {

    font-family:
        "Segoe UI",
        Arial,
        sans-serif;

    background: #0B1220;

    color: #f8f4ea;

    min-height: 100vh;
}



.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 250px;

    height: 100vh;

    background: #0d1728;

    border-right:
        1px solid
        rgba(212,175,112,0.20);

    padding: 30px 18px;
}

.logo {

    display: flex;

    align-items: center;

    gap: 12px;

    padding: 0 12px 35px;
}

.logo-box {

    width: 45px;
    height: 45px;

    border-radius: 14px;

    background:
        linear-gradient(
            135deg,
            #D4AF70,
            #f2d59a
        );

    color: #0B1220;

    display: flex;

    justify-content: center;

    align-items: center;

    font-weight: 900;

    font-size: 18px;
}

.logo-text {

    font-size: 20px;

    font-weight: 800;
}

.logo-text span {

    color: #D4AF70;
}

.menu-title {

    color: #7e899c;

    font-size: 11px;

    text-transform: uppercase;

    letter-spacing: 2px;

    padding: 0 14px 12px;
}

.menu a {

    display: block;

    text-decoration: none;

    color: #aeb7c7;

    padding: 14px;

    border-radius: 12px;

    margin-bottom: 7px;

    transition: 0.3s;
}

.menu a:hover,
.menu a.active {

    background:
        rgba(212,175,112,0.12);

    color: #D4AF70;
}



.main {

    margin-left: 250px;

    padding: 35px 45px;

    min-height: 100vh;
}



.topbar {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 35px;
}

.topbar h1 {

    font-size: 30px;
}

.badge {

    border:
        1px solid
        rgba(212,175,112,0.35);

    color: #D4AF70;

    padding: 9px 16px;

    border-radius: 30px;

    font-size: 13px;
}



.intro {

    margin-bottom: 28px;
}

.intro h2 {

    color: #D4AF70;

    font-size: 25px;

    margin-bottom: 8px;
}

.intro p {

    color: #8f9aad;
}



.stats {

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 18px;

    margin-bottom: 30px;
}

.stat {

    background:
        rgba(255,255,255,0.035);

    border:
        1px solid
        rgba(212,175,112,0.16);

    border-radius: 18px;

    padding: 22px;
}

.stat-title {

    color: #8f9aad;

    font-size: 13px;

    margin-bottom: 10px;
}

.stat-number {

    color: #D4AF70;

    font-size: 28px;

    font-weight: 800;
}



.applications {

    display: grid;

    gap: 18px;
}

.application {

    background:
        rgba(255,255,255,0.035);

    border:
        1px solid
        rgba(212,175,112,0.16);

    border-radius: 20px;

    padding: 25px;

    transition: 0.25s;
}

.application:hover {

    border-color:
        rgba(212,175,112,0.35);

    transform:
        translateY(-2px);

    box-shadow:
        0 15px 35px
        rgba(0,0,0,0.20);
}

.application-header {

    display: flex;

    justify-content: space-between;

    align-items: flex-start;

    gap: 20px;

    margin-bottom: 20px;
}

.application h3 {

    color: #f8f4ea;

    font-size: 20px;

    margin-bottom: 7px;
}

.student {

    color: #D4AF70;

    font-size: 14px;
}

.status {

    padding: 8px 14px;

    border-radius: 20px;

    font-size: 12px;

    font-weight: 700;
}

.pending {

    color: #f6d58d;

    background:
        rgba(212,175,112,0.10);
}

.approved {

    color: #6ee7b7;

    background:
        rgba(52,211,153,0.10);
}

.rejected {

    color: #fca5a5;

    background:
        rgba(248,113,113,0.10);
}



.details {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 14px;

    border-top:
        1px solid
        rgba(255,255,255,0.07);

    padding-top: 18px;
}

.detail {

    color: #8f9aad;

    font-size: 13px;

    line-height: 1.6;
}

.detail strong {

    display: block;

    color: #cfd4dd;

    margin-top: 5px;

    word-break: break-word;
}



.extra-details {

    margin-top: 18px;

    padding-top: 18px;

    border-top:
        1px solid
        rgba(255,255,255,0.07);

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 15px;
}

.skills {

    color: #D4AF70;
}



.empty {

    background:
        rgba(255,255,255,0.035);

    border:
        1px solid
        rgba(212,175,112,0.16);

    border-radius: 22px;

    padding: 70px 25px;

    text-align: center;
}

.empty-icon {

    font-size: 55px;

    margin-bottom: 15px;
}

.empty h2 {

    color: #D4AF70;

    margin-bottom: 10px;
}

.empty p {

    color: #8f9aad;
}



@media (max-width: 1000px) {

    .stats {

        grid-template-columns:
            repeat(2, 1fr);
    }

    .details {

        grid-template-columns:
            1fr 1fr;
    }
}

@media (max-width: 850px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;
    }

    .main {

        margin-left: 0;

        padding: 25px 18px;
    }

    .topbar {

        flex-direction: column;

        align-items: flex-start;

        gap: 15px;
    }
}

@media (max-width: 600px) {

    .stats {

        grid-template-columns: 1fr;
    }

    .details,
    .extra-details {

        grid-template-columns: 1fr;
    }

    .application-header {

        flex-direction: column;
    }
}

</style>

</head>

<body>



<aside class="sidebar">

    <div class="logo">

        <div class="logo-box">
            IC
        </div>

        <div class="logo-text">
            InternConnect
        </div>

    </div>

    <div class="menu-title">
        Company Portal
    </div>

    <div class="menu">

        <a href="dashboard.php">
            🏠 Dashboard
        </a>

        <a href="post-internship.php">
            ➕ Post Internship
        </a>

        <a href="internships.php">
            💼 My Internships
        </a>

        <a href="applications.php" class="active">
            📄 Applications
        </a>

        <a href="profile.php">
            👤 Company Profile
        </a>

        <a href="../logout.php">
            🚪 Logout
        </a>

    </div>

</aside>




<main class="main">

    <div class="topbar">

        <h1>
            Applications
        </h1>

        <div class="badge">
            Company Portal
        </div>

    </div>


    <div class="intro">

        <h2>
            Student Applications
        </h2>

        <p>
            Review applications submitted by students.
        </p>

    </div>


    

    <div class="stats">

        <div class="stat">

            <div class="stat-title">
                Total Applications
            </div>

            <div class="stat-number">
                <?php echo $total; ?>
            </div>

        </div>


        <div class="stat">

            <div class="stat-title">
                Pending
            </div>

            <div class="stat-number">
                <?php echo $pending; ?>
            </div>

        </div>


        <div class="stat">

            <div class="stat-title">
                Approved
            </div>

            <div class="stat-number">
                <?php echo $approved; ?>
            </div>

        </div>


        <div class="stat">

            <div class="stat-title">
                Rejected
            </div>

            <div class="stat-number">
                <?php echo $rejected; ?>
            </div>

        </div>

    </div>


    

    <?php if (empty($companyApplications)): ?>

        <div class="empty">

            <div class="empty-icon">
                📄
            </div>

            <h2>
                No Applications Yet
            </h2>

            <p>
                Student applications will appear here when students apply.
            </p>

        </div>

    <?php else: ?>


        <div class="applications">

            <?php foreach ($companyApplications as $application): ?>

                <?php

                $status =
                    $application["status"]
                    ?? "Pending";

                $statusClass = "pending";

                if ($status === "Approved") {

                    $statusClass = "approved";

                } elseif ($status === "Rejected") {

                    $statusClass = "rejected";
                }

                ?>


                <div class="application">

                    <div class="application-header">

                        <div>

                            <h3>

                                <?php

                                echo htmlspecialchars(
                                    $application["internship"]
                                    ?? "Internship Application"
                                );

                                ?>

                            </h3>


                            <div class="student">

                                👤

                                <?php

                                echo htmlspecialchars(
                                    $application["student_name"]
                                    ?? "Student"
                                );

                                ?>

                            </div>

                        </div>


                        <span
                            class="status <?php echo $statusClass; ?>"
                        >

                            <?php

                            echo htmlspecialchars($status);

                            ?>

                        </span>

                    </div>


                    

                    <div class="details">

                        <div class="detail">

                            📧 Email

                            <strong>

                                <?php

                                echo htmlspecialchars(
                                    $application["email"]
                                    ?? "Not available"
                                );

                                ?>

                            </strong>

                        </div>


                        <div class="detail">

                            📱 Phone

                            <strong>

                                <?php

                                echo htmlspecialchars(
                                    $application["phone"]
                                    ?? "Not available"
                                );

                                ?>

                            </strong>

                        </div>


                        <div class="detail">

                            🏫 College

                            <strong>

                                <?php

                                echo htmlspecialchars(
                                    $application["college"]
                                    ?? "Not available"
                                );

                                ?>

                            </strong>

                        </div>


                        <div class="detail">

                            💰 Stipend

                            <strong>

                                <?php

                                echo htmlspecialchars(
                                    $application["stipend"]
                                    ?? "Not available"
                                );

                                ?>

                            </strong>

                        </div>


                        <div class="detail">

                            📍 Location

                            <strong>

                                <?php

                                echo htmlspecialchars(
                                    $application["location"]
                                    ?? "Not available"
                                );

                                ?>

                            </strong>

                        </div>


                        <div class="detail">

                            📅 Applied On

                            <strong>

                                <?php

                                echo htmlspecialchars(
                                    $application["applied_at"]
                                    ?? "Recently"
                                );

                                ?>

                            </strong>

                        </div>

                    </div>


                    

                    <div class="extra-details">

                        <div class="detail">

                            🛠 Skills

                            <strong class="skills">

                                <?php

                                echo htmlspecialchars(
                                    $application["skills"]
                                    ?? "Not provided"
                                );

                                ?>

                            </strong>

                        </div>


                        <div class="detail">

                            📄 Resume

                            <strong>

                                <?php

                                echo htmlspecialchars(
                                    $application["resume"]
                                    ?? "Not uploaded"
                                );

                                ?>

                            </strong>

                        </div>


                        <div class="detail">

                            ⏱ Duration

                            <strong>

                                <?php

                                echo htmlspecialchars(
                                    $application["duration"]
                                    ?? "Not available"
                                );

                                ?>

                            </strong>

                        </div>


                        <div class="detail">

                            📝 Cover Letter

                            <strong>

                                <?php

                                echo htmlspecialchars(
                                    $application["cover_letter"]
                                    ?? "Not provided"
                                );

                                ?>

                            </strong>

                        </div>

                    </div>

                </div>


            <?php endforeach; ?>

        </div>

    <?php endif; ?>

</main>

</body>

</html>