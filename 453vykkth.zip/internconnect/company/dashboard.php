<?php

session_start();

if (!isset($_SESSION["company_logged_in"]) || $_SESSION["company_logged_in"] !== true) {
    header("Location: ../login.php");
    exit();
}

$companyName = $_SESSION["company_name"] ?? "InternConnect Company";
$companyEmail = $_SESSION["company_email"] ?? "company@internconnect.com";

$totalInternships = 0;
$totalApplications = 0;
$pendingApplications = 0;
$approvedApplications = 0;

$applications = $_SESSION["applications"] ?? [];

foreach ($applications as $application) {

    $totalApplications++;

    $status = $application["status"] ?? "Pending";

    if ($status === "Pending") {
        $pendingApplications++;
    }

    if ($status === "Approved") {
        $approvedApplications++;
    }
}

$companyInternships = $_SESSION["company_internships"] ?? [];

$totalInternships = count($companyInternships);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Company Dashboard - InternConnect</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {

    font-family:
        Arial,
        Helvetica,
        sans-serif;

    min-height: 100vh;

    background:
        radial-gradient(
            circle at 85% 10%,
            rgba(212,175,112,0.08),
            transparent 28%
        ),
        linear-gradient(
            135deg,
            #070D18,
            #0B1220 55%,
            #111827
        );

    color: #F8FAFC;
}



.sidebar {

    position: fixed;

    left: 0;
    top: 0;
    bottom: 0;

    width: 250px;

    background: rgba(8,14,26,0.96);

    border-right:
        1px solid
        rgba(212,175,112,0.14);

    padding: 28px 18px;

    z-index: 10;
}

.logo {

    display: flex;

    align-items: center;

    gap: 12px;

    padding: 0 12px;

    margin-bottom: 45px;
}

.logo-mark {

    width: 45px;
    height: 45px;

    border-radius: 13px;

    display: flex;

    align-items: center;
    justify-content: center;

    background:
        linear-gradient(
            135deg,
            #D4AF70,
            #B88A3B
        );

    color: #0B1220;

    font-size: 17px;

    font-weight: 900;
}

.logo-text {

    font-size: 20px;

    font-weight: 800;
}

.logo-text span {

    color: #D4AF70;
}

.nav-title {

    color: #657184;

    font-size: 10px;

    text-transform: uppercase;

    letter-spacing: 1.5px;

    padding: 0 13px;

    margin-bottom: 12px;
}

.nav {

    display: flex;

    flex-direction: column;

    gap: 7px;
}

.nav a {

    text-decoration: none;

    color: #8D99AA;

    padding: 13px 14px;

    border-radius: 12px;

    font-size: 14px;

    transition: 0.25s;

    display: flex;

    align-items: center;

    gap: 11px;
}

.nav a:hover {

    color: #D4AF70;

    background:
        rgba(212,175,112,0.07);
}

.nav a.active {

    color: #D4AF70;

    background:
        linear-gradient(
            90deg,
            rgba(212,175,112,0.13),
            rgba(212,175,112,0.04)
        );

    border:
        1px solid
        rgba(212,175,112,0.12);
}



.main {

    margin-left: 250px;

    min-height: 100vh;

    padding: 35px 42px;
}



.topbar {

    display: flex;

    align-items: center;

    justify-content: space-between;

    margin-bottom: 35px;
}

.breadcrumb {

    color: #718096;

    font-size: 12px;

    margin-bottom: 7px;
}

.page-title {

    font-size: 27px;

    font-weight: 800;
}

.company-badge {

    display: flex;

    align-items: center;

    gap: 10px;

    padding: 9px 14px;

    border-radius: 30px;

    background:
        rgba(212,175,112,0.08);

    border:
        1px solid
        rgba(212,175,112,0.17);

    color: #D4AF70;

    font-size: 12px;

    font-weight: 700;
}

.company-dot {

    width: 8px;
    height: 8px;

    border-radius: 50%;

    background: #D4AF70;

    box-shadow:
        0 0 10px
        rgba(212,175,112,0.6);
}



.hero {

    border-radius: 22px;

    padding: 32px;

    margin-bottom: 28px;

    background:
        linear-gradient(
            135deg,
            rgba(212,175,112,0.12),
            rgba(15,23,42,0.78)
        );

    border:
        1px solid
        rgba(212,175,112,0.16);

    box-shadow:
        0 20px 45px
        rgba(0,0,0,0.20);
}

.hero-small {

    color: #D4AF70;

    font-size: 12px;

    font-weight: 700;

    letter-spacing: 1px;

    text-transform: uppercase;

    margin-bottom: 10px;
}

.hero h1 {

    font-size: 30px;

    margin-bottom: 10px;
}

.hero p {

    color: #9AA6B7;

    max-width: 650px;

    line-height: 1.7;

    font-size: 14px;
}


.stats {

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 18px;

    margin-bottom: 30px;
}

.stat-card {

    background:
        rgba(15,23,42,0.72);

    border:
        1px solid
        rgba(255,255,255,0.07);

    border-radius: 18px;

    padding: 22px;

    transition: 0.25s;
}

.stat-card:hover {

    transform:
        translateY(-3px);

    border-color:
        rgba(212,175,112,0.22);
}

.stat-icon {

    width: 40px;
    height: 40px;

    border-radius: 12px;

    display: flex;

    align-items: center;
    justify-content: center;

    background:
        rgba(212,175,112,0.10);

    color: #D4AF70;

    margin-bottom: 15px;

    font-size: 18px;
}

.stat-number {

    font-size: 28px;

    font-weight: 800;

    margin-bottom: 5px;
}

.stat-label {

    color: #7F8B9D;

    font-size: 12px;
}



.section-title {

    font-size: 19px;

    margin-bottom: 17px;
}

.quick-grid {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 18px;
}

.quick-card {

    text-decoration: none;

    color: inherit;

    padding: 25px;

    min-height: 170px;

    border-radius: 18px;

    background:
        rgba(15,23,42,0.70);

    border:
        1px solid
        rgba(255,255,255,0.07);

    transition: 0.25s;
}

.quick-card:hover {

    transform:
        translateY(-4px);

    border-color:
        rgba(212,175,112,0.28);

    box-shadow:
        0 15px 35px
        rgba(0,0,0,0.20);
}

.quick-icon {

    width: 45px;
    height: 45px;

    border-radius: 13px;

    display: flex;

    align-items: center;
    justify-content: center;

    background:
        rgba(212,175,112,0.10);

    color: #D4AF70;

    font-size: 20px;

    margin-bottom: 17px;
}

.quick-card h3 {

    font-size: 16px;

    margin-bottom: 8px;
}

.quick-card p {

    color: #7F8B9D;

    font-size: 12px;

    line-height: 1.6;
}


.profile-box {

    margin-top: 30px;

    padding: 25px;

    border-radius: 18px;

    background:
        rgba(15,23,42,0.70);

    border:
        1px solid
        rgba(255,255,255,0.07);

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 20px;
}

.profile-info {

    display: flex;

    align-items: center;

    gap: 15px;
}

.avatar {

    width: 50px;
    height: 50px;

    border-radius: 50%;

    background:
        linear-gradient(
            135deg,
            #D4AF70,
            #9B6D28
        );

    color: #0B1220;

    display: flex;

    align-items: center;
    justify-content: center;

    font-weight: 900;
}

.profile-info h3 {

    font-size: 15px;

    margin-bottom: 5px;
}

.profile-info p {

    color: #7F8B9D;

    font-size: 12px;
}

.logout {

    text-decoration: none;

    color: #D4AF70;

    border:
        1px solid
        rgba(212,175,112,0.22);

    padding: 10px 15px;

    border-radius: 10px;

    font-size: 12px;

    font-weight: 700;

    transition: 0.2s;
}

.logout:hover {

    background:
        rgba(212,175,112,0.09);
}

@media (max-width: 1000px) {

    .stats {

        grid-template-columns:
            repeat(2, 1fr);
    }

    .quick-grid {

        grid-template-columns:
            repeat(2, 1fr);
    }
}

@media (max-width: 750px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;

        border-right: none;

        border-bottom:
            1px solid
            rgba(212,175,112,0.14);
    }

    .nav {

        flex-direction: row;

        flex-wrap: wrap;
    }

    .main {

        margin-left: 0;

        padding: 25px 18px;
    }

    .topbar {

        align-items: flex-start;

        gap: 15px;
    }
}

@media (max-width: 550px) {

    .stats,
    .quick-grid {

        grid-template-columns: 1fr;
    }

    .hero {

        padding: 24px;
    }

    .hero h1 {

        font-size: 25px;
    }

    .profile-box {

        align-items: flex-start;

        flex-direction: column;
    }
}

</style>

</head>

<body>


<aside class="sidebar">

    <div class="logo">

        <div class="logo-mark">
            IC
        </div>

        <div class="logo-text">
            Intern<span>Connect</span>
        </div>

    </div>

    <div class="nav-title">
        Company
    </div>

    <nav class="nav">

        <a
            href="dashboard.php"
            class="active"
        >
            🏠 Dashboard
        </a>

        <a href="post-internship.php">
            ➕ Post Internship
        </a>

        <a href="internships.php">
            📋 My Internships
        </a>

        <a href="applications.php">
            👩‍🎓 Applications
        </a>

        <a href="profile.php">
            🏢 Company Profile
        </a>

    </nav>

</aside>



<main class="main">

    <div class="topbar">

        <div>

            <div class="breadcrumb">
                Company / Dashboard
            </div>

            <div class="page-title">
                Company Dashboard
            </div>

        </div>

        <div class="company-badge">

            <span class="company-dot"></span>

            Company Portal

        </div>

    </div>


    

    <section class="hero">

        <div class="hero-small">
            Welcome to InternConnect
        </div>

        <h1>
            Grow your team with the right talent.
        </h1>

        <p>
            Create internship opportunities, discover talented students,
            manage applications and build the next generation of professionals.
        </p>

    </section>


    

    <h2 class="section-title">
        Overview
    </h2>

    <section class="stats">

        <div class="stat-card">

            <div class="stat-icon">
                💼
            </div>

            <div class="stat-number">
                <?php echo $totalInternships; ?>
            </div>

            <div class="stat-label">
                Active Internships
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-icon">
                📩
            </div>

            <div class="stat-number">
                <?php echo $totalApplications; ?>
            </div>

            <div class="stat-label">
                Total Applications
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-icon">
                ⏳
            </div>

            <div class="stat-number">
                <?php echo $pendingApplications; ?>
            </div>

            <div class="stat-label">
                Pending Applications
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-icon">
                ✓
            </div>

            <div class="stat-number">
                <?php echo $approvedApplications; ?>
            </div>

            <div class="stat-label">
                Approved
            </div>

        </div>

    </section>


    

    <h2 class="section-title">
        Quick Actions
    </h2>

    <section class="quick-grid">

        <a href="post-internship.php" class="quick-card">

            <div class="quick-icon">
                ＋
            </div>

            <h3>
                Post Internship
            </h3>

            <p>
                Create and publish a new internship opportunity
                for talented students.
            </p>

        </a>


        <a href="internships.php" class="quick-card">

            <div class="quick-icon">
                📋
            </div>

            <h3>
                Manage Internships
            </h3>

            <p>
                View and manage all internship opportunities
                created by your company.
            </p>

        </a>


        <a href="applications.php" class="quick-card">

            <div class="quick-icon">
                👩‍🎓
            </div>

            <h3>
                View Applications
            </h3>

            <p>
                Review student applications and find the
                right candidates for your team.
            </p>

        </a>

    </section>


    
    <div class="profile-box">

        <div class="profile-info">

            <div class="avatar">
                IC
            </div>

            <div>

                <h3>
                    <?php echo htmlspecialchars($companyName); ?>
                </h3>

                <p>
                    <?php echo htmlspecialchars($companyEmail); ?>
                </p>

            </div>

        </div>

        <a
            href="../logout.php"
            class="logout"
        >
            Logout
        </a>

    </div>

</main>

</body>

</html>