CREATE DATABASE IF NOT EXISTS internconnect;

USE internconnect;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS internships (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    company VARCHAR(150) NOT NULL,
    location VARCHAR(100),
    description TEXT,
    skills VARCHAR(255),
    stipend VARCHAR(100),
    duration VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    internship_id INT NOT NULL,
    resume VARCHAR(255),
    status VARCHAR(30) DEFAULT 'Pending',
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (internship_id) REFERENCES internships(id) ON DELETE CASCADE
);

INSERT INTO internships
(title, company, location, description, skills, stipend, duration)
VALUES
(
    'Web Development Intern',
    'TechNova Solutions',
    'Chennai',
    'Work on modern web applications and real-world projects.',
    'HTML, CSS, JavaScript, PHP',
    '₹10,000/month',
    '3 Months'
),
(
    'Python Developer Intern',
    'CodeCraft Technologies',
    'Bangalore',
    'Develop Python applications and APIs.',
    'Python, SQL, Git',
    '₹12,000/month',
    '3 Months'
),
(
    'Data Science Intern',
    'DataVision Labs',
    'Remote',
    'Work with data analysis and machine learning projects.',
    'Python, Pandas, Machine Learning',
    '₹15,000/month',
    '4 Months'
);