<?php

$host = "db01.dbhost.dev";
$port = "5051";
$username = "user_455399b4j";
$password = "p455399b4j";
$database = "db_455399b4j";

$conn = new PDO(
    "mysql:host=$host;port=$port;dbname=$database;charset=utf8mb4",
    $username,
    $password
);

$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

?>