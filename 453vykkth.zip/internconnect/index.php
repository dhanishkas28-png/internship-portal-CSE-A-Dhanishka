<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>InternConnect | Your Career Begins Here</title>

    <link rel="stylesheet" href="css/style.css">

    <style>

        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Segoe UI", Arial, sans-serif;
            background: #f8f5ef;
            color: #182235;
            overflow-x: hidden;
        }

        a {
            text-decoration: none;
        }

        
        .premium-nav {
            position: sticky;
            top: 0;
            z-index: 999;

            height: 76px;
            padding: 0 7%;

            display: flex;
            align-items: center;
            justify-content: space-between;

            background: rgba(10, 17, 30, 0.97);
            border-bottom: 1px solid rgba(201,169,110,0.25);

            backdrop-filter: blur(15px);
        }

        .premium-logo {
            display: flex;
            align-items: center;
            gap: 11px;

            color: #ffffff;
            font-size: 23px;
            font-weight: 700;
            letter-spacing: -0.5px;
        }

        .logo-mark {
            width: 37px;
            height: 37px;

            display: flex;
            align-items: center;
            justify-content: center;

            border: 1px solid #c9a96e;
            border-radius: 10px;

            color: #e4cf9b;
            font-size: 16px;
        }

        .premium-logo span {
            color: #d6b878;
        }

        .premium-links {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .premium-links a {
            color: #d9dee7;

            padding: 10px 15px;

            border-radius: 9px;

            font-size: 14px;
            font-weight: 500;

            transition: 0.3s ease;
        }

        .premium-links a:hover {
            color: #e4cf9b;
            background: rgba(201,169,110,0.10);
        }

        .nav-login {
            border: 1px solid rgba(201,169,110,0.55);
        }

        .nav-register {
            color: #101827 !important;
            background: #d1b477;
            font-weight: 700 !important;
        }

        .nav-register:hover {
            color: #101827 !important;
            background: #e3cd9b !important;
        }

        

        .premium-hero {
            position: relative;
            min-height: 650px;

            display: grid;
            grid-template-columns: 1.05fr 0.95fr;

            align-items: center;

            gap: 65px;

            padding: 90px 7%;

            color: white;

            background:
                radial-gradient(
                    circle at 80% 15%,
                    rgba(201,169,110,0.18),
                    transparent 28%
                ),
                radial-gradient(
                    circle at 15% 90%,
                    rgba(42,67,104,0.55),
                    transparent 32%
                ),
                linear-gradient(
                    135deg,
                    #080f1c,
                    #101c30 55%,
                    #15253d
                );

            overflow: hidden;
        }

        .premium-hero::before {
            content: "";

            position: absolute;

            width: 430px;
            height: 430px;

            right: -180px;
            top: -170px;

            border: 1px solid rgba(201,169,110,0.18);

            border-radius: 50%;
        }

        .premium-hero::after {
            content: "";

            position: absolute;

            width: 300px;
            height: 300px;

            left: -170px;
            bottom: -170px;

            border: 1px solid rgba(201,169,110,0.12);

            border-radius: 50%;
        }

        .hero-content {
            position: relative;
            z-index: 2;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 9px;

            padding: 8px 14px;

            margin-bottom: 24px;

            color: #dfc58d;

            border: 1px solid rgba(201,169,110,0.30);

            background: rgba(201,169,110,0.07);

            border-radius: 30px;

            font-size: 11px;
            font-weight: 700;

            letter-spacing: 1.5px;
        }

        .eyebrow-dot {
            width: 6px;
            height: 6px;

            background: #d1b477;

            border-radius: 50%;

            box-shadow: 0 0 12px #d1b477;
        }

        .hero-content h1 {
            max-width: 760px;

            font-size: clamp(43px, 6vw, 76px);

            line-height: 1.02;

            letter-spacing: -3px;

            margin-bottom: 25px;
        }

        .hero-content h1 span {
            color: #d5b979;
        }

        .hero-content p {
            max-width: 600px;

            color: #bfc8d5;

            font-size: 17px;

            line-height: 1.8;

            margin-bottom: 32px;
        }

        .hero-actions {
            display: flex;
            align-items: center;
            gap: 14px;

            flex-wrap: wrap;
        }

        .gold-button {
            display: inline-flex;
            align-items: center;
            gap: 10px;

            padding: 14px 23px;

            color: #111a29;

            background: linear-gradient(
                135deg,
                #d7bd82,
                #b99657
            );

            border-radius: 10px;

            font-size: 14px;
            font-weight: 700;

            box-shadow: 0 12px 30px rgba(201,169,110,0.20);

            transition: 0.3s ease;
        }

        .gold-button:hover {
            transform: translateY(-3px);

            box-shadow:
                0 16px 35px rgba(201,169,110,0.32);
        }

        .outline-button {
            display: inline-flex;
            align-items: center;

            padding: 13px 23px;

            color: #e2e7ee;

            border: 1px solid rgba(255,255,255,0.20);

            border-radius: 10px;

            font-size: 14px;
            font-weight: 600;

            transition: 0.3s ease;
        }

        .outline-button:hover {
            color: #e3cc99;

            border-color: #c9a96e;

            background: rgba(201,169,110,0.07);
        }

        
        .hero-visual {
            position: relative;
            z-index: 2;
        }

        .opportunity-window {
            position: relative;

            padding: 22px;

            background: rgba(255,255,255,0.075);

            border: 1px solid rgba(255,255,255,0.14);

            border-radius: 25px;

            backdrop-filter: blur(18px);

            box-shadow:
                0 30px 80px rgba(0,0,0,0.28);
        }

        .window-header {
            display: flex;
            align-items: center;
            justify-content: space-between;

            padding-bottom: 19px;

            border-bottom: 1px solid rgba(255,255,255,0.10);

            margin-bottom: 15px;
        }

        .window-title {
            color: #ffffff;

            font-size: 17px;
            font-weight: 650;
        }

        .live {
            display: flex;
            align-items: center;
            gap: 6px;

            color: #9dd5b5;

            font-size: 11px;
            font-weight: 700;
        }

        .live-dot {
            width: 6px;
            height: 6px;

            background: #77c69c;

            border-radius: 50%;
        }

        .opportunity {
            padding: 17px;

            margin-bottom: 10px;

            border: 1px solid rgba(255,255,255,0.09);

            background: rgba(255,255,255,0.055);

            border-radius: 15px;

            transition: 0.3s ease;
        }

        .opportunity:last-child {
            margin-bottom: 0;
        }

        .opportunity:hover {
            transform: translateX(5px);

            border-color: rgba(201,169,110,0.35);

            background: rgba(201,169,110,0.07);
        }

        .opportunity h3 {
            color: #ffffff;

            font-size: 14px;

            margin-bottom: 5px;
        }

        .opportunity-company {
            color: #9ca8b8;

            font-size: 11px;
        }

        .opportunity-bottom {
            display: flex;
            align-items: center;
            justify-content: space-between;

            margin-top: 13px;
        }

        .mini-tags {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }

        .mini-tag {
            padding: 4px 7px;

            color: #d8c28f;

            border: 1px solid rgba(201,169,110,0.22);

            background: rgba(201,169,110,0.07);

            border-radius: 5px;

            font-size: 9px;
        }

        .stipend {
            color: #a8d7ba;

            font-size: 10px;
            font-weight: 700;
        }

        .intro {
            padding: 85px 7% 30px;

            text-align: center;

            background: #f8f5ef;
        }

        .section-label {
            color: #a17c42;

            font-size: 11px;

            font-weight: 800;

            letter-spacing: 2px;
        }

        .intro h2 {
            max-width: 700px;

            margin: 13px auto 12px;

            color: #101a2b;

            font-size: clamp(30px, 4vw, 43px);

            letter-spacing: -1.5px;
        }

        .intro p {
            max-width: 650px;

            margin: auto;

            color: #747b87;

            line-height: 1.8;

            font-size: 15px;
        }

        
        .features-section {
            padding: 45px 7% 85px;

            background: #f8f5ef;
        }

        .features {
            max-width: 1180px;

            margin: auto;

            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            gap: 20px;
        }

        .feature {
            position: relative;

            padding: 30px;

            background: #ffffff;

            border: 1px solid #e7e0d4;

            border-radius: 19px;

            box-shadow:
                0 8px 30px rgba(30,35,50,0.05);

            transition: 0.3s ease;
        }

        .feature:hover {
            transform: translateY(-7px);

            border-color: #d2b77d;

            box-shadow:
                0 20px 45px rgba(30,35,50,0.09);
        }

        .feature-number {
            position: absolute;

            right: 22px;
            top: 20px;

            color: #ebe5da;

            font-size: 35px;

            font-weight: 800;
        }

        .feature-icon {
            width: 50px;
            height: 50px;

            display: flex;
            align-items: center;
            justify-content: center;

            margin-bottom: 22px;

            color: #a17c42;

            background: #f5ecdc;

            border: 1px solid #e9d7b5;

            border-radius: 14px;

            font-size: 20px;
        }

        .feature h3 {
            color: #172033;

            font-size: 18px;

            margin-bottom: 9px;
        }

        .feature p {
            color: #747b87;

            font-size: 13px;

            line-height: 1.7;
        }

        

        .stats-section {
            padding: 20px 7% 90px;

            background: #f8f5ef;
        }

        .stats {
            max-width: 1180px;

            margin: auto;

            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            border-top: 1px solid #ded8cd;

            border-bottom: 1px solid #ded8cd;
        }

        .stat {
            padding: 28px 20px;

            text-align: center;

            border-right: 1px solid #ded8cd;
        }

        .stat:last-child {
            border-right: none;
        }

        .stat h2 {
            color: #182235;

            font-size: 34px;

            letter-spacing: -1px;
        }

        .stat h2 span {
            color: #b18c51;
        }

        .stat p {
            margin-top: 4px;

            color: #777e89;

            font-size: 12px;
        }

        
        .premium-cta {
            position: relative;

            margin: 0 7% 80px;

            padding: 70px 30px;

            text-align: center;

            overflow: hidden;

            color: white;

            background:
                radial-gradient(
                    circle at 80% 20%,
                    rgba(201,169,110,0.18),
                    transparent 30%
                ),
                linear-gradient(
                    135deg,
                    #09111f,
                    #17263d
                );

            border: 1px solid rgba(201,169,110,0.20);

            border-radius: 25px;
        }

        .premium-cta h2 {
            font-size: clamp(28px, 4vw, 42px);

            letter-spacing: -1px;

            margin-bottom: 12px;
        }

        .premium-cta p {
            color: #bfc8d5;

            margin-bottom: 27px;

            font-size: 14px;
        }

        

        .premium-footer {
            padding: 30px 7%;

            display: flex;
            align-items: center;
            justify-content: space-between;

            gap: 20px;

            color: #8993a2;

            background: #080f1c;

            border-top: 1px solid rgba(201,169,110,0.18);

            font-size: 12px;
        }

        .footer-brand {
            color: #d7dce5;

            font-weight: 700;
        }

        .footer-brand span {
            color: #c9a96e;
        }

        
        @media (max-width: 900px) {

            .premium-hero {
                grid-template-columns: 1fr;

                padding-top: 70px;
                padding-bottom: 70px;
            }

            .features {
                grid-template-columns: 1fr;
            }

            .hero-visual {
                max-width: 650px;

                width: 100%;

                margin: auto;
            }

            .premium-links a:first-child {
                display: none;
            }

        }

        @media (max-width: 650px) {

            .premium-nav {
                height: auto;

                padding: 15px 5%;

                gap: 15px;
            }

            .premium-logo {
                font-size: 19px;
            }

            .logo-mark {
                width: 32px;
                height: 32px;
            }

            .premium-links {
                gap: 5px;
            }

            .premium-links a {
                padding: 8px 10px;

                font-size: 12px;
            }

            .premium-hero {
                padding: 60px 6%;
            }

            .hero-content h1 {
                font-size: 45px;

                letter-spacing: -2px;
            }

            .hero-content p {
                font-size: 15px;
            }

            .hero-actions {
                flex-direction: column;

                align-items: stretch;
            }

            .gold-button,
            .outline-button {
                justify-content: center;
            }

            .stats {
                grid-template-columns: 1fr;
            }

            .stat {
                border-right: none;

                border-bottom: 1px solid #ded8cd;
            }

            .stat:last-child {
                border-bottom: none;
            }

            .premium-cta {
                margin: 0 5% 60px;

                padding: 55px 20px;
            }

            .premium-footer {
                flex-direction: column;

                text-align: center;
            }

        }

    </style>

</head>

<body>



<header class="premium-nav">

    <a href="index.php" class="premium-logo">

        <span class="logo-mark">IC</span>

        Intern<span>Connect</span>

    </a>


    <nav class="premium-links">

        <a href="index.php">Home</a>

        <a href="login.php" class="nav-login">
            Login
        </a>

        <a href="register.php" class="nav-register">
            Get Started
        </a>

    </nav>

</header>



<section class="premium-hero">

    <div class="hero-content">

        <div class="eyebrow">

            <span class="eyebrow-dot"></span>

            SMART INTERNSHIP PLATFORM

        </div>


        <h1>

            Your career

            <span>starts here.</span>

        </h1>


        <p>

            Discover meaningful internship opportunities,
            showcase your skills and take your first step
            towards a successful professional career.

        </p>


        <div class="hero-actions">

            <a
                href="register.php"
                class="gold-button"
            >

                Explore Opportunities →

            </a>


            <a
                href="login.php"
                class="outline-button"
            >

                Sign In

            </a>

        </div>

    </div>



    

    <div class="hero-visual">

        <div class="opportunity-window">


            <div class="window-header">

                <div class="window-title">

                    Featured Opportunities

                </div>


                <div class="live">

                    <span class="live-dot"></span>

                    LIVE

                </div>

            </div>



            
            <div class="opportunity">

                <h3>
                    Web Development Intern
                </h3>

                <div class="opportunity-company">

                    TechNova Solutions · Chennai

                </div>


                <div class="opportunity-bottom">

                    <div class="mini-tags">

                        <span class="mini-tag">
                            HTML
                        </span>
                        <span class="min-tags">CSS</span>
                        <span class="min-tags">PHP</span>
</div>
<span class="stipend">₹10K / month
                    </span>

                </div>

            </div>



            

            <div class="opportunity">

                <h3>
                    Python Developer Intern
                </h3>

                <div class="opportunity-company">

                    CodeCraft Technologies · Bangalore

                </div>


                <div class="opportunity-bottom">

                    <div class="mini-tags">

                        <span class="mini-tag">
                            Python
                        </span>

                        <span class="mini-tag">
                            SQL
                        </span>

                        <span class="mini-tag">
                            Git
                        </span>

                    </div>


                    <span class="stipend">
                        ₹12K / month
                    </span>

                </div>

            </div>



            
            <div class="opportunity">

                <h3>
                    Data Science Intern
                </h3>

                <div class="opportunity-company">

                    DataVision Labs · Remote

                </div>


                <div class="opportunity-bottom">

                    <div class="mini-tags">

                        <span class="mini-tag">
                            Python
                        </span>

                        <span class="mini-tag">
                            ML
                        </span>

                        <span class="mini-tag">
                            Pandas
                        </span>

                    </div>


                    <span class="stipend">
                        ₹15K / month
                    </span>

                </div>

            </div>


        </div>

    </div>

</section>





<section class="intro">

    <div class="section-label">
        THE INTERNCONNECT EXPERIENCE
    </div>


    <h2>
        More than an internship portal.
    </h2>


    <p>

        A thoughtfully designed platform that connects
        students with opportunities that help transform
        classroom knowledge into real-world experience.

    </p>

</section>





<section class="features-section">

    <div class="features">


        <div class="feature">

            <div class="feature-number">
                01
            </div>

            <div class="feature-icon">
                ◇
            </div>

            <h3>
                Discover
            </h3>

            <p>

                Explore internship opportunities based on
                your skills, interests, location and career goals.

            </p>

        </div>



        <div class="feature">

            <div class="feature-number">
                02
            </div>

            <div class="feature-icon">
                ✓
            </div>

            <h3>
                Apply with Ease
            </h3>

            <p>

                Submit applications through a simple,
                organized and student-friendly experience.

            </p>

        </div>



        <div class="feature">

            <div class="feature-number">
                03
            </div>

            <div class="feature-icon">
                ↗
            </div>

            <h3>
                Grow Forward
            </h3>

            <p>

                Gain practical experience, build confidence
                and move closer to your professional goals.

            </p>

        </div>


    </div>

</section>





<section class="stats-section">

    <div class="stats">


        <div class="stat">

            <h2>
                50<span>+</span>
            </h2>

            <p>
                Internship Opportunities
            </p>

        </div>


        <div class="stat">

            <h2>
                25<span>+</span>
            </h2>

            <p>
                Partner Companies
            </p>

        </div>


        <div class="stat">

            <h2>
                100<span>+</span>
            </h2>

            <p>
                Students Connected
            </p>

        </div>


    </div>

</section>





<section class="premium-cta">

    <h2>
        Ready to build your future?
    </h2>


    <p>

        Create your account and discover opportunities
        waiting for your skills.

    </p>


    <a
        href="register.php"
        class="gold-button"
    >

        Create Your Account →

    </a>

</section>





<footer class="premium-footer">

    <div class="footer-brand">

        Intern<span>Connect</span>

    </div>


    <div>

        © 2026 InternConnect · Student Internship Platform

    </div>


    <div>

        Skills · Opportunities · Growth

    </div>

</footer>


</body>
</html
