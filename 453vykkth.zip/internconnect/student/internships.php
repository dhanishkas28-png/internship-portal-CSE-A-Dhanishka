<?php

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$internships = [

    [
        "id" => 1,
        "title" => "Web Development Intern",
        "company" => "TechNova Solutions",
        "location" => "Chennai",
        "skills" => "HTML, CSS, JavaScript, PHP",
        "stipend" => 10000,
        "duration" => "3 Months"
    ],

    [
        "id" => 2,
        "title" => "Python Developer Intern",
        "company" => "CodeCraft Technologies",
        "location" => "Bangalore",
        "skills" => "Python, SQL, Git",
        "stipend" => 12000,
        "duration" => "3 Months"
    ],

    [
        "id" => 3,
        "title" => "Data Science Intern",
        "company" => "DataVision Labs",
        "location" => "Remote",
        "skills" => "Python, Pandas, Machine Learning",
        "stipend" => 15000,
        "duration" => "4 Months"
    ],

    [
        "id" => 4,
        "title" => "PHP Developer Intern",
        "company" => "WebCore Technologies",
        "location" => "Chennai",
        "skills" => "PHP, MySQL, HTML, CSS",
        "stipend" => 11000,
        "duration" => "3 Months"
    ],

    [
        "id" => 5,
        "title" => "Java Developer Intern",
        "company" => "InnovateSoft",
        "location" => "Hyderabad",
        "skills" => "Java, Spring Boot, SQL",
        "stipend" => 14000,
        "duration" => "4 Months"
    ],

    [
        "id" => 6,
        "title" => "AI & Machine Learning Intern",
        "company" => "FutureMind AI",
        "location" => "Remote",
        "skills" => "Python, AI, Machine Learning",
        "stipend" => 18000,
        "duration" => "6 Months"
    ],

    [
        "id" => 7,
        "title" => "Frontend Developer Intern",
        "company" => "PixelWorks Studio",
        "location" => "Chennai",
        "skills" => "HTML, CSS, JavaScript, React",
        "stipend" => 12000,
        "duration" => "3 Months"
    ],

    [
        "id" => 8,
        "title" => "Backend Developer Intern",
        "company" => "ServerStack Technologies",
        "location" => "Bangalore",
        "skills" => "PHP, Node.js, MySQL",
        "stipend" => 13000,
        "duration" => "4 Months"
    ],

    [
        "id" => 9,
        "title" => "Cyber Security Intern",
        "company" => "SecureNet Labs",
        "location" => "Hyderabad",
        "skills" => "Cyber Security, Networking, Linux",
        "stipend" => 16000,
        "duration" => "4 Months"
    ],

    [
        "id" => 10,
        "title" => "Cloud Computing Intern",
        "company" => "CloudNova Technologies",
        "location" => "Remote",
        "skills" => "AWS, Cloud, Linux",
        "stipend" => 15000,
        "duration" => "3 Months"
    ],

    [
        "id" => 11,
        "title" => "UI/UX Design Intern",
        "company" => "CreativePixel",
        "location" => "Chennai",
        "skills" => "Figma, UI Design, UX Research",
        "stipend" => 9000,
        "duration" => "3 Months"
    ],

    [
        "id" => 12,
        "title" => "Mobile App Development Intern",
        "company" => "AppWorks Technologies",
        "location" => "Coimbatore",
        "skills" => "Flutter, Dart, Firebase",
        "stipend" => 13000,
        "duration" => "4 Months"
    ]

];

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Internships | InternConnect</title>

<style>



* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {

    font-family: "Segoe UI", Arial, sans-serif;

    color: #f8f5ed;

    min-height: 100vh;

    background:
        radial-gradient(
            circle at 10% 5%,
            rgba(212,175,55,0.12),
            transparent 27%
        ),
        radial-gradient(
            circle at 90% 15%,
            rgba(69,91,145,0.18),
            transparent 30%
        ),
        radial-gradient(
            circle at 50% 100%,
            rgba(212,175,55,0.07),
            transparent 35%
        ),
        #07111f;
}




.topbar {

    position: sticky;

    top: 0;

    z-index: 1000;

    display: flex;

    justify-content: space-between;

    align-items: center;

    padding: 17px 6%;

    background:
        rgba(7,17,31,0.88);

    border-bottom:
        1px solid rgba(212,175,55,0.18);

    backdrop-filter: blur(18px);

    box-shadow:
        0 10px 40px rgba(0,0,0,0.20);
}




.logo {

    display: flex;

    align-items: center;

    gap: 11px;

    color: #fff;

    font-size: 21px;

    font-weight: 800;

    letter-spacing: -.5px;
}

.logo-mark {

    width: 40px;

    height: 40px;

    display: flex;

    justify-content: center;

    align-items: center;

    border-radius: 12px;

    color: #07111f;

    font-size: 13px;

    font-weight: 900;

    background:
        linear-gradient(
            135deg,
            #f4d889,
            #c99b2e
        );

    box-shadow:
        0 8px 25px rgba(212,175,55,0.25);
}

.logo span {
    color: #d9b95f;
}



.topbar nav {

    display: flex;

    align-items: center;

    gap: 6px;

    flex-wrap: wrap;
}

.topbar nav a {

    text-decoration: none;

    color: #c5cfdb;

    padding: 9px 14px;

    border-radius: 10px;

    font-size: 13px;

    font-weight: 600;

    transition: .3s;
}

.topbar nav a:hover {

    color: #f5d982;

    background:
        rgba(212,175,55,0.08);
}

.topbar nav a.active {

    color: #f5d982;

    background:
        rgba(212,175,55,0.10);

    border:
        1px solid rgba(212,175,55,0.20);
}

.logout {

    color: #ffcaca !important;

    border:
        1px solid rgba(255,80,80,0.22);

    background:
        rgba(180,40,40,0.09);
}

.logout:hover {

    color: white !important;

    background:
        rgba(220,60,60,0.20) !important;
}




.main-container {

    width: 92%;

    max-width: 1250px;

    margin: auto;

    padding: 45px 0 70px;
}




.page-header {

    position: relative;

    overflow: hidden;

    padding: 38px;

    margin-bottom: 25px;

    border-radius: 24px;

    background:
        linear-gradient(
            135deg,
            rgba(20,36,59,.95),
            rgba(8,22,38,.90)
        );

    border:
        1px solid rgba(212,175,55,.18);

    box-shadow:
        0 22px 60px rgba(0,0,0,.25);
}

.page-header::after {

    content: "";

    position: absolute;

    width: 230px;

    height: 230px;

    right: -80px;

    top: -100px;

    border-radius: 50%;

    background:
        radial-gradient(
            circle,
            rgba(212,175,55,.18),
            transparent 70%
        );
}

.page-label {

    position: relative;

    z-index: 2;

    display: inline-block;

    margin-bottom: 10px;

    color: #d9b95f;

    font-size: 11px;

    font-weight: 700;

    letter-spacing: 2px;

    text-transform: uppercase;
}

.page-header h1 {

    position: relative;

    z-index: 2;

    color: #fff;

    font-size: 34px;

    margin-bottom: 10px;
}

.page-header h1 span {
    color: #dfc368;
}

.page-header p {

    position: relative;

    z-index: 2;

    max-width: 680px;

    color: #9ba8b9;

    font-size: 14px;

    line-height: 1.7;
}




.search-box {

    padding: 22px;

    margin-bottom: 28px;

    border-radius: 20px;

    background:
        linear-gradient(
            145deg,
            rgba(18,34,55,.92),
            rgba(8,21,36,.92)
        );

    border:
        1px solid rgba(255,255,255,.07);

    box-shadow:
        0 18px 45px rgba(0,0,0,.20);
}




#searchInput {

    width: 100%;

    padding: 15px 18px;

    color: #f7f3e9;

    font-size: 14px;

    outline: none;

    border-radius: 12px;

    border:
        1px solid rgba(255,255,255,.09);

    background:
        rgba(255,255,255,.045);

    transition: .3s;
}

#searchInput::placeholder {
    color: #7f8b9d;
}

#searchInput:focus {

    border-color:
        rgba(212,175,55,.55);

    background:
        rgba(212,175,55,.035);

    box-shadow:
        0 0 0 3px rgba(212,175,55,.07);
}




.filters {

    display: grid;

    grid-template-columns:
        repeat(3,1fr);

    gap: 12px;

    margin-top: 14px;
}

.filters select {

    width: 100%;

    padding: 13px 14px;

    color: #d8e0ea;

    border-radius: 11px;

    border:
        1px solid rgba(255,255,255,.09);

    background:
        #0d1c2e;

    outline: none;

    cursor: pointer;

    font-size: 13px;

    transition: .3s;
}

.filters select:focus {

    border-color:
        rgba(212,175,55,.50);
}

.filters select option {

    background: #0d1c2e;

    color: white;
}




.internship-grid {

    display: grid;

    grid-template-columns:
        repeat(3,1fr);

    gap: 20px;
}




.internship-card {

    position: relative;

    overflow: hidden;

    padding: 24px;

    border-radius: 19px;

    background:
        linear-gradient(
            145deg,
            rgba(18,34,55,.94),
            rgba(8,21,36,.94)
        );

    border:
        1px solid rgba(255,255,255,.07);

    box-shadow:
        0 14px 40px rgba(0,0,0,.18);

    transition: .35s;
}

.internship-card::before {

    content: "";

    position: absolute;

    top: 0;

    left: 0;

    width: 100%;

    height: 2px;

    background:
        linear-gradient(
            90deg,
            transparent,
            #d6b557,
            transparent
        );

    opacity: 0;

    transition: .3s;
}

.internship-card:hover {

    transform:
        translateY(-7px);

    border-color:
        rgba(212,175,55,.28);

    box-shadow:
        0 24px 55px rgba(0,0,0,.30);

    background:
        linear-gradient(
            145deg,
            rgba(21,39,62,.97),
            rgba(9,23,39,.97)
        );
}

.internship-card:hover::before {
    opacity: 1;
}




.card-top {

    display: flex;

    justify-content: space-between;

    align-items: flex-start;

    gap: 10px;

    margin-bottom: 14px;
}

.internship-icon {

    width: 48px;

    height: 48px;

    display: flex;

    justify-content: center;

    align-items: center;

    flex-shrink: 0;

    border-radius: 13px;

    background:
        rgba(212,175,55,.08);

    border:
        1px solid rgba(212,175,55,.16);

    font-size: 21px;
}

.location-badge {

    padding: 6px 9px;

    border-radius: 20px;

    color: #d7c174;

    background:
        rgba(212,175,55,.07);

    border:
        1px solid rgba(212,175,55,.13);

    font-size: 10px;

    font-weight: 700;
}




.internship-card h2 {

    color: #f8f3e8;

    font-size: 17px;

    line-height: 1.4;

    margin-bottom: 7px;
}

.company {

    color: #d6b85e;

    font-size: 12px;

    font-weight: 700;

    margin-bottom: 15px;
}




.details {

    color: #929eae;

    font-size: 12px;

    line-height: 1.7;

    margin-bottom: 12px;
}



.skills {

    padding: 10px 11px;

    min-height: 42px;

    border-radius: 10px;

    color: #aebbd0;

    background:
        rgba(255,255,255,.035);

    border:
        1px solid rgba(255,255,255,.055);

    font-size: 11px;

    line-height: 1.5;

    margin-bottom: 17px;
}

.card-bottom {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 10px;

    padding-top: 14px;

    border-top:
        1px solid rgba(255,255,255,.06);
}

.stipend {

    color: #7ee19b;

    font-size: 15px;

    font-weight: 800;
}

.stipend-label {

    color: #718095;

    font-size: 9px;

    font-weight: 500;
}

.duration {

    color: #8d99aa;

    font-size: 11px;

    text-align: right;
}



.apply-btn {

    display: block;

    width: 100%;

    text-align: center;

    text-decoration: none;

    margin-top: 18px;

    padding: 11px;

    border-radius: 10px;

    color: #0a1422;

    background:
        linear-gradient(
            135deg,
            #f1d47b,
            #c79c31
        );

    font-size: 12px;

    font-weight: 800;

    box-shadow:
        0 8px 22px rgba(212,175,55,.12);

    transition: .3s;
}

.apply-btn:hover {

    transform:
        translateY(-2px);

    box-shadow:
        0 12px 30px rgba(212,175,55,.24);
}




.no-results {

    display: none;

    padding: 50px 20px;

    margin-top: 20px;

    text-align: center;

    border-radius: 20px;

    background:
        rgba(18,34,55,.90);

    border:
        1px solid rgba(255,255,255,.07);
}

.no-results-icon {

    font-size: 35px;

    margin-bottom: 12px;
}

.no-results h3 {

    color: #eee8db;

    font-size: 18px;

    margin-bottom: 8px;
}

.no-results p {

    color: #7f8b9c;

    font-size: 13px;
}




.footer {

    padding: 28px 20px;

    text-align: center;

    color: #697688;

    font-size: 11px;

    border-top:
        1px solid rgba(255,255,255,.05);
}




@media (max-width: 1000px) {

    .internship-grid {

        grid-template-columns:
            repeat(2,1fr);
    }

}

@media (max-width: 700px) {

    .topbar {

        flex-direction: column;

        align-items: flex-start;

        gap: 15px;

        padding: 15px 20px;
    }

    .topbar nav {

        width: 100%;
    }

    .topbar nav a {

        padding: 8px 9px;

        font-size: 11px;
    }

    .main-container {

        width: 94%;

        padding-top: 25px;
    }

    .page-header {

        padding: 30px 23px;
    }

    .page-header h1 {

        font-size: 27px;
    }

    .filters {

        grid-template-columns: 1fr;
    }

    .internship-grid {

        grid-template-columns: 1fr;
    }

}

</style>

</head>


<body>




<header class="topbar">

    <div class="logo">

        <div class="logo-mark">
            IC
        </div>

        <div>
            <span>Intern</span>Connect
        </div>

    </div>


    <nav>

        <a href="../index.php">
            Home
        </a>

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="internships.php" class="active">
            Internships
        </a>

        <a href="my-applications.php">
            Applications
        </a>

        <a href="profile.php">
            Profile
        </a>

        <a href="../logout.php" class="logout">
            Logout
        </a>

    </nav>

</header>




<main class="main-container">


    <!-- PAGE HEADER -->

    <section class="page-header">

        <div class="page-label">
            Career Opportunities
        </div>

        <h1>
            Explore
            <span>Internships</span>
        </h1>

        <p>
            Discover opportunities that match your skills, interests
            and career goals. Search, filter and find your next
            professional opportunity.
        </p>

    </section>


    

    <section class="search-box">

        <input
            type="text"
            id="searchInput"
            placeholder="🔍  Search internship, company or skill..."
            onkeyup="filterInternships()"
        >


        <div class="filters">


            <select
                id="locationFilter"
                onchange="filterInternships()"
            >

                <option value="">
                    📍 All Locations
                </option>

                <option value="Chennai">
                    Chennai
                </option>

                <option value="Bangalore">
                    Bangalore
                </option>

                <option value="Hyderabad">
                    Hyderabad
                </option>

                <option value="Coimbatore">
                    Coimbatore
                </option>

                <option value="Remote">
                    Remote
                </option>

            </select>


            <select
                id="skillFilter"
                onchange="filterInternships()"
            >

                <option value="">
                    💻 All Skills
                </option>

                <option value="PHP">
                    PHP
                </option>

                <option value="Python">
                    Python
                </option>

                <option value="Java">
                    Java
                </option>

                <option value="JavaScript">
                    JavaScript
                </option>

                <option value="HTML">
                    HTML
                </option>

                <option value="CSS">
                    CSS
                </option>

                <option value="Machine Learning">
                    Machine Learning
                </option>

                <option value="Cyber Security">
                    Cyber Security
                </option>

                <option value="Cloud">
                    Cloud
                </option>

                <option value="Flutter">
                    Flutter
                </option>

                <option value="UI Design">
                    UI Design
                </option>

            </select>


            <select
                id="stipendFilter"
                onchange="filterInternships()"
            >

                <option value="">
                    💰 All Stipends
                </option>

                <option value="10000">
                    ₹10,000+
                </option>

                <option value="12000">
                    ₹12,000+
                </option>

                <option value="15000">
                    ₹15,000+
                </option>

            </select>

        </div>

    </section>


    

    <div
        class="internship-grid"
        id="internshipGrid"
    >


        <?php foreach ($internships as $internship): ?>


            <article
                class="internship-card"

                data-location="<?php
                    echo htmlspecialchars(
                        $internship["location"]
                    );
                ?>"

                data-skills="<?php
                    echo htmlspecialchars(
                        $internship["skills"]
                    );
                ?>"

                data-stipend="<?php
                    echo $internship["stipend"];
                ?>"
            >


                <div class="card-top">

                    <div class="internship-icon">
                        💼
                    </div>

                    <div class="location-badge">
                        📍 <?php
                        echo htmlspecialchars(
                            $internship["location"]
                        );
                        ?>
                    </div>

                </div>


                <h2>

                    <?php

                    echo htmlspecialchars(
                        $internship["title"]
                    );

                    ?>

                </h2>


                <div class="company">

                    <?php

                    echo htmlspecialchars(
                        $internship["company"]
                    );

                    ?>

                </div>


                <div class="details">

                    📍

                    <?php

                    echo htmlspecialchars(
                        $internship["location"]
                    );

                    ?>

                </div>


                <div class="skills">

                    💻

                    <?php

                    echo htmlspecialchars(
                        $internship["skills"]
                    );

                    ?>

                </div>


                <div class="card-bottom">


                    <div>

                        <div class="stipend">

                            ₹<?php

                            echo number_format(
                                $internship["stipend"]
                            );

                            ?>/month

                        </div>

                        <div class="stipend-label">
                            Monthly Stipend
                        </div>

                    </div>


                    <div class="duration">

                        ⏱

                        <?php

                        echo htmlspecialchars(
                            $internship["duration"]
                        );

                        ?>

                    </div>


                </div>


                <a
                    href="apply.php?id=<?php
                        echo $internship["id"];
                    ?>"
                    class="apply-btn"
                >
                    View & Apply →
                </a>


            </article>


        <?php endforeach; ?>


    </div>


    

    <div
        class="no-results"
        id="noResults"
    >

        <div class="no-results-icon">
            🔎
        </div>

        <h3>
            No internships found
        </h3>

        <p>
            Try changing your search or filter options.
        </p>

    </div>


</main>


<footer class="footer">

    © 2026 InternConnect · Student Career Portal

</footer>


<script>

function filterInternships() {

    var search =
        document
        .getElementById("searchInput")
        .value
        .toLowerCase()
        .trim();


    var location =
        document
        .getElementById("locationFilter")
        .value
        .toLowerCase();


    var skill =
        document
        .getElementById("skillFilter")
        .value
        .toLowerCase();


    var stipend =
        document
        .getElementById("stipendFilter")
        .value;


    var cards =
        document.getElementsByClassName(
            "internship-card"
        );


    var visibleCount = 0;


    for (
        var i = 0;
        i < cards.length;
        i++
    ) {

        var card = cards[i];


        var text =
            card.innerText
            .toLowerCase();


        var cardLocation =
            card.getAttribute(
                "data-location"
            )
            .toLowerCase();


        var cardSkills =
            card.getAttribute(
                "data-skills"
            )
            .toLowerCase();


        var cardStipend =
            parseInt(
                card.getAttribute(
                    "data-stipend"
                )
            );


        var searchMatch =
            search === "" ||
            text.includes(search);


        var locationMatch =
            location === "" ||
            cardLocation === location;


        var skillMatch =
            skill === "" ||
            cardSkills.includes(skill);


        var stipendMatch =
            stipend === "" ||
            cardStipend >= parseInt(stipend);


        if (
            searchMatch &&
            locationMatch &&
            skillMatch &&
            stipendMatch
        ) {

            card.style.display = "block";

            visibleCount++;

        } else {

            card.style.display = "none";

        }

    }


    var noResults =
        document.getElementById(
            "noResults"
        );


    if (visibleCount === 0) {

        noResults.style.display = "block";

    } else {

        noResults.style.display = "none";

    }

}

</script>


</body>

</html>