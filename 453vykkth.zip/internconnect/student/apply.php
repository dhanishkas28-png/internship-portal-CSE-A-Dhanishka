<?php

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}




$internships = [

    1 => [
        "title" => "Web Development Intern",
        "company" => "TechNova Solutions",
        "location" => "Chennai",
        "skills" => "HTML, CSS, JavaScript, PHP",
        "stipend" => "₹10,000/month",
        "duration" => "3 Months"
    ],

    2 => [
        "title" => "Python Developer Intern",
        "company" => "CodeCraft Technologies",
        "location" => "Bangalore",
        "skills" => "Python, SQL, Git",
        "stipend" => "₹12,000/month",
        "duration" => "3 Months"
    ],

    3 => [
        "title" => "Data Science Intern",
        "company" => "DataVision Labs",
        "location" => "Remote",
        "skills" => "Python, Pandas, Machine Learning",
        "stipend" => "₹15,000/month",
        "duration" => "4 Months"
    ],

    4 => [
        "title" => "PHP Developer Intern",
        "company" => "WebCore Technologies",
        "location" => "Chennai",
        "skills" => "PHP, MySQL, HTML, CSS",
        "stipend" => "₹11,000/month",
        "duration" => "3 Months"
    ],

    5 => [
        "title" => "Java Developer Intern",
        "company" => "InnovateSoft",
        "location" => "Hyderabad",
        "skills" => "Java, Spring Boot, SQL",
        "stipend" => "₹14,000/month",
        "duration" => "4 Months"
    ],

    6 => [
        "title" => "AI & Machine Learning Intern",
        "company" => "FutureMind AI",
        "location" => "Remote",
        "skills" => "Python, AI, Machine Learning",
        "stipend" => "₹18,000/month",
        "duration" => "6 Months"
    ],

    7 => [
        "title" => "Frontend Developer Intern",
        "company" => "PixelWorks Studio",
        "location" => "Chennai",
        "skills" => "HTML, CSS, JavaScript, React",
        "stipend" => "₹12,000/month",
        "duration" => "3 Months"
    ],

    8 => [
        "title" => "Backend Developer Intern",
        "company" => "ServerStack Technologies",
        "location" => "Bangalore",
        "skills" => "PHP, Node.js, MySQL",
        "stipend" => "₹13,000/month",
        "duration" => "4 Months"
    ],

    9 => [
        "title" => "Cyber Security Intern",
        "company" => "SecureNet Labs",
        "location" => "Hyderabad",
        "skills" => "Cyber Security, Networking, Linux",
        "stipend" => "₹16,000/month",
        "duration" => "4 Months"
    ],

    10 => [
        "title" => "Cloud Computing Intern",
        "company" => "CloudNova Technologies",
        "location" => "Remote",
        "skills" => "AWS, Cloud, Linux",
        "stipend" => "₹15,000/month",
        "duration" => "3 Months"
    ],

    11 => [
        "title" => "UI/UX Design Intern",
        "company" => "CreativePixel",
        "location" => "Chennai",
        "skills" => "Figma, UI Design, UX Research",
        "stipend" => "₹9,000/month",
        "duration" => "3 Months"
    ],

    12 => [
        "title" => "Mobile App Development Intern",
        "company" => "AppWorks Technologies",
        "location" => "Coimbatore",
        "skills" => "Flutter, Dart, Firebase",
        "stipend" => "₹13,000/month",
        "duration" => "4 Months"
    ]

];



$id = isset($_GET["id"]) ? (int)$_GET["id"] : 1;

if (!isset($internships[$id])) {
    $id = 1;
}

$internship = $internships[$id];




$name = $_SESSION["user_name"] ?? "";
$email = $_SESSION["user_email"] ?? "";
$phone = $_SESSION["user_phone"] ?? "";
$college = $_SESSION["user_college"] ?? "";
$skills = $_SESSION["user_skills"] ?? "";

$error = "";




if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $phone = trim($_POST["phone"] ?? "");
    $college = trim($_POST["college"] ?? "");
    $skills = trim($_POST["skills"] ?? "");
    $coverLetter = trim($_POST["cover_letter"] ?? "");

    $resumeName = "";

    if (
        isset($_FILES["resume"]) &&
        $_FILES["resume"]["error"] === UPLOAD_ERR_OK
    ) {
        $resumeName = $_FILES["resume"]["name"];
    }


    

    if (
        $name === "" ||
        $email === "" ||
        $phone === "" ||
        $college === "" ||
        $skills === ""
    ) {

        $error = "Please fill all required fields.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = "Please enter a valid email address.";

    } elseif (strlen($phone) < 10) {

        $error = "Please enter a valid phone number.";

    } else {


        

        $_SESSION["user_name"] = $name;
        $_SESSION["user_email"] = $email;
        $_SESSION["user_phone"] = $phone;
        $_SESSION["user_college"] = $college;
        $_SESSION["user_skills"] = $skills;


        

        if (!isset($_SESSION["applications"])) {
            $_SESSION["applications"] = [];
        }


        $_SESSION["applications"][] = [

            "student_name" => $name,
            "email" => $email,
            "phone" => $phone,
            "college" => $college,
            "skills" => $skills,
            "resume" => $resumeName,
            "cover_letter" => $coverLetter,
            "internship" => $internship["title"],
            "company" => $internship["company"],
            "location" => $internship["location"],
            "stipend" => $internship["stipend"],
            "duration" => $internship["duration"],
            "status" => "Pending",
            "applied_at" => date("d-m-Y h:i A")

        ];


        

        header("Location: my-applications.php");
        exit();

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Apply | InternConnect</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

:root {

    --navy: #080d19;
    --navy-light: #101827;
    --card: rgba(18, 27, 43, 0.88);

    --gold: #d4af70;
    --gold-light: #f0d9a4;

    --cream: #f5f1e8;
    --muted: #9ca8ba;

    --border: rgba(212, 175, 112, 0.20);

}

body {

    font-family:
        Inter,
        Arial,
        sans-serif;

    background:
        radial-gradient(
            circle at 10% 10%,
            rgba(212,175,112,0.08),
            transparent 30%
        ),
        radial-gradient(
            circle at 90% 20%,
            rgba(50,80,130,0.15),
            transparent 30%
        ),
        var(--navy);

    color: var(--cream);

    min-height: 100vh;

}



.topbar {

    height: 78px;

    padding: 0 6%;

    display: flex;

    align-items: center;

    justify-content: space-between;

    background:
        rgba(8,13,25,0.86);

    border-bottom:
        1px solid var(--border);

    backdrop-filter: blur(18px);

    position: sticky;

    top: 0;

    z-index: 100;

}


.logo {

    display: flex;

    align-items: center;

    gap: 12px;

    font-size: 21px;

    font-weight: 700;

    letter-spacing: -0.4px;

}


.logo-mark {

    width: 38px;

    height: 38px;

    border-radius: 12px;

    display: flex;

    align-items: center;

    justify-content: center;

    background:
        linear-gradient(
            135deg,
            var(--gold-light),
            var(--gold)
        );

    color: #101010;

    font-size: 14px;

    font-weight: 900;

    box-shadow:
        0 8px 25px rgba(212,175,112,0.20);

}


.logo span {

    color: var(--gold);

}


nav {

    display: flex;

    align-items: center;

    gap: 28px;

}


nav a {

    color: #c4ccda;

    text-decoration: none;

    font-size: 14px;

    transition: 0.25s;

}


nav a:hover {

    color: var(--gold-light);

}




.container {

    width: 90%;

    max-width: 1180px;

    margin: 48px auto 80px;

}


.back {

    display: inline-flex;

    align-items: center;

    gap: 8px;

    color: var(--gold-light);

    text-decoration: none;

    font-size: 14px;

    margin-bottom: 28px;

    transition: 0.25s;

}


.back:hover {

    color: white;

    transform: translateX(-3px);

}



.page-title {

    margin-bottom: 35px;

}


.eyebrow {

    color: var(--gold);

    text-transform: uppercase;

    letter-spacing: 2px;

    font-size: 11px;

    font-weight: 700;

    margin-bottom: 12px;

}


.page-title h1 {

    font-family:
        Georgia,
        "Times New Roman",
        serif;

    font-size: clamp(34px, 5vw, 52px);

    font-weight: 500;

    letter-spacing: -1.5px;

    line-height: 1.05;

    margin-bottom: 12px;

}


.page-title h1 span {

    color: var(--gold);

}


.page-title p {

    color: var(--muted);

    font-size: 15px;

}




.layout {

    display: grid;

    grid-template-columns:
        0.85fr 1.5fr;

    gap: 28px;

    align-items: start;

}




.internship-summary {

    position: relative;

    overflow: hidden;

    background:
        linear-gradient(
            145deg,
            #162238,
            #0e1727
        );

    border:
        1px solid var(--border);

    border-radius: 24px;

    padding: 32px;

    box-shadow:
        0 25px 70px rgba(0,0,0,0.28);

}


.internship-summary::before {

    content: "";

    position: absolute;

    width: 180px;

    height: 180px;

    border-radius: 50%;

    background:
        rgba(212,175,112,0.08);

    filter: blur(5px);

    top: -80px;

    right: -70px;

}


.summary-label {

    color: var(--gold);

    text-transform: uppercase;

    letter-spacing: 1.8px;

    font-size: 10px;

    font-weight: 700;

    margin-bottom: 18px;

}


.internship-summary h2 {

    font-family:
        Georgia,
        "Times New Roman",
        serif;

    font-size: 28px;

    font-weight: 500;

    line-height: 1.2;

    margin-bottom: 10px;

}


.company {

    color: var(--gold-light);

    font-size: 15px;

    margin-bottom: 30px;

}


.summary-item {

    padding: 18px 0;

    border-top:
        1px solid rgba(255,255,255,0.08);

}


.summary-item strong {

    display: block;

    color: #eef1f6;

    font-size: 13px;

    margin-bottom: 7px;

}


.summary-item span {

    color: var(--muted);

    font-size: 14px;

    line-height: 1.6;

}




.form-card {

    background:
        rgba(16,24,39,0.82);

    border:
        1px solid var(--border);

    border-radius: 24px;

    padding: 36px;

    box-shadow:
        0 25px 70px rgba(0,0,0,0.25);

    backdrop-filter: blur(15px);

}


.form-heading {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    margin-bottom: 28px;

}


.form-heading h2 {

    font-family:
        Georgia,
        "Times New Roman",
        serif;

    font-size: 28px;

    font-weight: 500;

}


.form-badge {

    border:
        1px solid rgba(212,175,112,0.30);

    color: var(--gold-light);

    padding: 8px 12px;

    border-radius: 30px;

    font-size: 11px;

    white-space: nowrap;

}



.error {

    background:
        rgba(220,38,38,0.10);

    border:
        1px solid rgba(248,113,113,0.25);

    color: #fca5a5;

    padding: 14px 16px;

    border-radius: 12px;

    margin-bottom: 20px;

    font-size: 14px;

}



.info-box {

    background:
        rgba(212,175,112,0.07);

    border:
        1px solid rgba(212,175,112,0.18);

    color: #d9caa9;

    padding: 14px 16px;

    border-radius: 12px;

    margin-bottom: 25px;

    font-size: 13px;

}




.form-group {

    margin-bottom: 20px;

}


.form-group label {

    display: block;

    color: #e8ebf0;

    font-size: 13px;

    font-weight: 600;

    margin-bottom: 9px;

}


.required {

    color: #e8bd70;

}


.form-group input,

.form-group textarea {

    width: 100%;

    background:
        rgba(7,12,22,0.65);

    border:
        1px solid rgba(255,255,255,0.10);

    color: white;

    padding: 14px 15px;

    border-radius: 12px;

    font-size: 14px;

    outline: none;

    transition: 0.25s;

}


.form-group input::placeholder,

.form-group textarea::placeholder {

    color: #687386;

}


.form-group input:focus,

.form-group textarea:focus {

    border-color: var(--gold);

    box-shadow:
        0 0 0 3px rgba(212,175,112,0.08);

}


.form-group textarea {

    min-height: 135px;

    resize: vertical;

    line-height: 1.6;

}


.form-group input[type="file"] {

    padding: 11px;

    color: #aeb7c7;

    cursor: pointer;

}


.form-group input[type="file"]::file-selector-button {

    background:
        rgba(212,175,112,0.12);

    border:
        1px solid rgba(212,175,112,0.25);

    color: var(--gold-light);

    padding: 8px 12px;

    border-radius: 8px;

    margin-right: 10px;

    cursor: pointer;

}



.submit-btn {

    width: 100%;

    margin-top: 5px;

    border: none;

    background:
        linear-gradient(
            135deg,
            var(--gold-light),
            var(--gold)
        );

    color: #101010;

    padding: 16px;

    border-radius: 12px;

    font-size: 15px;

    font-weight: 800;

    cursor: pointer;

    transition: 0.25s;

    box-shadow:
        0 12px 30px rgba(212,175,112,0.16);

}


.submit-btn:hover {

    transform: translateY(-2px);

    box-shadow:
        0 16px 35px rgba(212,175,112,0.25);

}


.submit-btn:active {

    transform: translateY(0);

}




@media(max-width: 850px) {

    .topbar {

        height: auto;

        padding: 18px 5%;

        flex-direction: column;

        gap: 18px;

    }

    nav {

        gap: 16px;

        flex-wrap: wrap;

        justify-content: center;

    }

    .container {

        width: 92%;

        margin-top: 35px;

    }

    .layout {

        grid-template-columns: 1fr;

    }

    .form-card,

    .internship-summary {

        padding: 25px;

    }

}


@media(max-width: 500px) {

    nav a {

        font-size: 12px;

    }

    .page-title h1 {

        font-size: 35px;

    }

    .form-heading {

        align-items: flex-start;

        flex-direction: column;

    }

}

</style>

</head>


<body>


<header class="topbar">

    <div class="logo">

        <div class="logo-mark">
            IC
        </div>

        <div>
            Intern<span>Connect</span>
        </div>

    </div>


    <nav>

        <a href="../index.php">Home</a>

        <a href="dashboard.php">Dashboard</a>

        <a href="internships.php">Internships</a>

        <a href="profile.php">Profile</a>

        <a href="../logout.php">Logout</a>

    </nav>

</header>



<main class="container">


    <a
        href="internship-details.php?id=<?php echo $id; ?>"
        class="back"
    >
        ← Back to Internship Details
    </a>


    <section class="page-title">

        <div class="eyebrow">
            Career opportunity
        </div>

        <h1>
            Apply for your
            <span>next opportunity.</span>
        </h1>

        <p>
            Complete your profile and submit your application securely.
        </p>

    </section>



    <div class="layout">


        

        <aside class="internship-summary">

            <div class="summary-label">
                Selected Internship
            </div>


            <h2>

                <?php
                echo htmlspecialchars(
                    $internship["title"]
                );
                ?>

            </h2>


            <div class="company">

                <?php
                echo htmlspecialchars(
                    $internship["company"]
                );
                ?>

            </div>


            <div class="summary-item">

                <strong>📍 Location</strong>

                <span>

                    <?php
                    echo htmlspecialchars(
                        $internship["location"]
                    );
                    ?>

                </span>

            </div>


            <div class="summary-item">

                <strong>💰 Stipend</strong>

                <span>

                    <?php
                    echo htmlspecialchars(
                        $internship["stipend"]
                    );
                    ?>

                </span>

            </div>


            <div class="summary-item">

                <strong>⏱ Duration</strong>

                <span>

                    <?php
                    echo htmlspecialchars(
                        $internship["duration"]
                    );
                    ?>

                </span>

            </div>


            <div class="summary-item">

                <strong>💻 Required Skills</strong>

                <span>

                    <?php
                    echo htmlspecialchars(
                        $internship["skills"]
                    );
                    ?>

                </span>

            </div>

        </aside>



        
        <section class="form-card">


            <div class="form-heading">

                <h2>
                    Application Form
                </h2>

                <div class="form-badge">
                    Secure Application
                </div>

            </div>


            <?php if ($error !== ""): ?>

                <div class="error">

                    <?php
                    echo htmlspecialchars($error);
                    ?>

                </div>

            <?php endif; ?>


            <div class="info-box">

                ✦ Fields marked with
                <strong>*</strong>
                are required to submit your application.

            </div>


            <form
                method="POST"
                enctype="multipart/form-data"
            >


                <div class="form-group">

                    <label>
                        Full Name
                        <span class="required">*</span>
                    </label>

                    <input
                        type="text"
                        name="name"
                        value="<?php
                        echo htmlspecialchars($name);
                        ?>"
                        placeholder="Enter your full name"
                        required
                    >

                </div>



                <div class="form-group">

                    <label>
                        Email Address
                        <span class="required">*</span>
                    </label>

                    <input
                        type="email"
                        name="email"
                        value="<?php
                        echo htmlspecialchars($email);
                        ?>"
                        placeholder="Enter your email address"
                        required
                    >

                </div>



                <div class="form-group">

                    <label>
                        Phone Number
                        <span class="required">*</span>
                    </label>

                    <input
                        type="tel"
                        name="phone"
                        value="<?php
                        echo htmlspecialchars($phone);
                        ?>"
                        placeholder="Enter your phone number"
                        required
                    >

                </div>



                <div class="form-group">

                    <label>
                        College
                        <span class="required">*</span>
                    </label>

                    <input
                        type="text"
                        name="college"
                        value="<?php
                        echo htmlspecialchars($college);
                        ?>"
                        placeholder="Enter your college name"
                        required
                    >

                </div>



                <div class="form-group">

                    <label>
                        Skills
                        <span class="required">*</span>
                    </label>

                    <input
                        type="text"
                        name="skills"
                        value="<?php
                        echo htmlspecialchars($skills);
                        ?>"
                        placeholder="Example: PHP, HTML, CSS, JavaScript"
                        required
                    >

                </div>



                <div class="form-group">

                    <label>
                        Resume
                    </label>

                    <input
                        type="file"
                        name="resume"
                        accept=".pdf,.doc,.docx"
                    >

                </div>



                <div class="form-group">

                    <label>
                        Cover Letter
                    </label>

                    <textarea
                        name="cover_letter"
                        placeholder="Write a short message about why you are interested in this internship..."
                    ></textarea>

                </div>



                <button
                    type="submit"
                    class="submit-btn"
                >
                    Submit Application &nbsp;→
                </button>


            </form>

        </section>

    </div>

</main>


</body>

</html>