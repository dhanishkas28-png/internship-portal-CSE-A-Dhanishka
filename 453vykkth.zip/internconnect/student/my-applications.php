<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$applications = $_SESSION["applications"] ?? [];
$application = !empty($applications) ? end($applications) : null;

$status = $application["status"] ?? "Pending";
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>My Applications | InternConnect</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

:root {

    --navy: #080d19;
    --navy-light: #101827;
    --card: rgba(17, 26, 42, 0.88);

    --gold: #d4af70;
    --gold-light: #f0d9a4;

    --cream: #f5f1e8;
    --muted: #9ca8ba;

    --border: rgba(212,175,112,0.20);

}

body {

    font-family:
        Inter,
        Arial,
        sans-serif;

    min-height: 100vh;

    color: var(--cream);

    background:

        radial-gradient(
            circle at 10% 10%,
            rgba(212,175,112,0.08),
            transparent 30%
        ),

        radial-gradient(
            circle at 90% 20%,
            rgba(40,70,120,0.15),
            transparent 30%
        ),

        var(--navy);

}




.navbar {

    min-height: 78px;

    padding: 0 6%;

    display: flex;

    justify-content: space-between;

    align-items: center;

    background:
        rgba(8,13,25,0.88);

    border-bottom:
        1px solid var(--border);

    backdrop-filter: blur(18px);

    position: sticky;

    top: 0;

    z-index: 100;

}


.logo {

    display: flex;

    align-items: center;

    gap: 12px;

    font-size: 21px;

    font-weight: 700;

}


.logo-mark {

    width: 38px;

    height: 38px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 12px;

    background:
        linear-gradient(
            135deg,
            var(--gold-light),
            var(--gold)
        );

    color: #101010;

    font-size: 13px;

    font-weight: 900;

    box-shadow:
        0 8px 25px rgba(212,175,112,0.18);

}


.logo span {

    color: var(--gold);

}


.nav-links {

    display: flex;

    align-items: center;

    gap: 27px;

}


.nav-links a {

    color: #c5cedc;

    text-decoration: none;

    font-size: 14px;

    transition: 0.25s;

}


.nav-links a:hover {

    color: var(--gold-light);

}




.container {

    width: 90%;

    max-width: 1080px;

    margin: 55px auto 80px;

}




.page-title {

    margin-bottom: 35px;

}


.eyebrow {

    color: var(--gold);

    font-size: 11px;

    font-weight: 700;

    text-transform: uppercase;

    letter-spacing: 2px;

    margin-bottom: 12px;

}


.page-title h1 {

    font-family:
        Georgia,
        "Times New Roman",
        serif;

    font-size: clamp(36px, 5vw, 52px);

    font-weight: 500;

    letter-spacing: -1.5px;

    margin-bottom: 12px;

}


.page-title h1 span {

    color: var(--gold);

}


.page-title p {

    color: var(--muted);

    font-size: 15px;

}


.notification {

    padding: 19px 22px;

    border-radius: 15px;

    margin-bottom: 28px;

    font-size: 14px;

    font-weight: 600;

    backdrop-filter: blur(10px);

}


.notification.pending {

    background:
        rgba(212,175,112,0.08);

    color: var(--gold-light);

    border:
        1px solid rgba(212,175,112,0.22);

}


.notification.approved {

    background:
        rgba(34,197,94,0.08);

    color: #86efac;

    border:
        1px solid rgba(34,197,94,0.22);

}


.notification.rejected {

    background:
        rgba(239,68,68,0.08);

    color: #fca5a5;

    border:
        1px solid rgba(239,68,68,0.22);

}



.application-card {

    position: relative;

    overflow: hidden;

    background:
        rgba(16,24,39,0.86);

    border:
        1px solid var(--border);

    border-radius: 24px;

    padding: 32px;

    box-shadow:
        0 25px 70px rgba(0,0,0,0.25);

    backdrop-filter: blur(15px);

}


.application-card::before {

    content: "";

    position: absolute;

    top: -100px;

    right: -80px;

    width: 220px;

    height: 220px;

    border-radius: 50%;

    background:
        rgba(212,175,112,0.06);

    filter: blur(5px);

}


.top-section {

    display: flex;

    justify-content: space-between;

    align-items: flex-start;

    gap: 25px;

    padding-bottom: 28px;

    margin-bottom: 28px;

    border-bottom:
        1px solid rgba(255,255,255,0.08);

}


.job-title {

    font-family:
        Georgia,
        "Times New Roman",
        serif;

    font-size: 29px;

    font-weight: 500;

    line-height: 1.2;

    color: var(--cream);

}


.company {

    color: var(--gold-light);

    margin-top: 9px;

    font-size: 14px;

}



.status {

    padding: 9px 17px;

    border-radius: 30px;

    font-size: 12px;

    font-weight: 700;

    letter-spacing: 0.4px;

    white-space: nowrap;

}


.status.pending {

    background:
        rgba(212,175,112,0.10);

    color: var(--gold-light);

    border:
        1px solid rgba(212,175,112,0.25);

}


.status.approved {

    background:
        rgba(34,197,94,0.10);

    color: #86efac;

    border:
        1px solid rgba(34,197,94,0.25);

}


.status.rejected {

    background:
        rgba(239,68,68,0.10);

    color: #fca5a5;

    border:
        1px solid rgba(239,68,68,0.25);

}




.details {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 14px;

}


.detail-box {

    background:
        rgba(7,12,22,0.55);

    border:
        1px solid rgba(255,255,255,0.07);

    padding: 17px;

    border-radius: 13px;

    transition: 0.25s;

}


.detail-box:hover {

    border-color:
        rgba(212,175,112,0.22);

    transform: translateY(-2px);

}


.detail-box small {

    display: block;

    color: #7f8b9e;

    font-size: 11px;

    text-transform: uppercase;

    letter-spacing: 0.7px;

    margin-bottom: 8px;

}


.detail-box strong {

    display: block;

    color: #e8ebf0;

    font-size: 13px;

    line-height: 1.5;

    word-break: break-word;

}



.empty-box {

    background:
        rgba(16,24,39,0.86);

    border:
        1px solid var(--border);

    padding: 70px 25px;

    border-radius: 24px;

    text-align: center;

    box-shadow:
        0 25px 70px rgba(0,0,0,0.25);

}


.empty-icon {

    width: 65px;

    height: 65px;

    margin: 0 auto 20px;

    border-radius: 20px;

    display: flex;

    align-items: center;

    justify-content: center;

    background:
        rgba(212,175,112,0.08);

    border:
        1px solid rgba(212,175,112,0.20);

    color: var(--gold);

    font-size: 27px;

}


.empty-box h2 {

    font-family:
        Georgia,
        "Times New Roman",
        serif;

    font-size: 28px;

    font-weight: 500;

    margin-bottom: 10px;

}


.empty-box p {

    color: var(--muted);

    margin-bottom: 28px;

    font-size: 14px;

}




.browse-btn {

    display: inline-flex;

    align-items: center;

    gap: 9px;

    background:
        linear-gradient(
            135deg,
            var(--gold-light),
            var(--gold)
        );

    color: #101010;

    text-decoration: none;

    padding: 13px 22px;

    border-radius: 11px;

    font-size: 14px;

    font-weight: 800;

    transition: 0.25s;

}


.browse-btn:hover {

    transform: translateY(-2px);

    box-shadow:
        0 12px 30px rgba(212,175,112,0.20);

}



@media(max-width: 760px) {

    .navbar {

        padding: 18px 5%;

        flex-direction: column;

        gap: 17px;

    }

    .nav-links {

        gap: 15px;

        flex-wrap: wrap;

        justify-content: center;

    }

    .nav-links a {

        font-size: 12px;

    }

    .container {

        width: 92%;

        margin-top: 38px;

    }

    .application-card {

        padding: 24px;

    }

    .top-section {

        flex-direction: column;

    }

    .details {

        grid-template-columns: 1fr;

    }

    .job-title {

        font-size: 25px;

    }

}

</style>

</head>


<body>


<header class="navbar">


    <div class="logo">

        <div class="logo-mark">
            IC
        </div>

        <div>
            Intern<span>Connect</span>
        </div>

    </div>


    <nav class="nav-links">

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="internships.php">
            Internships
        </a>

        <a href="profile.php">
            Profile
        </a>

        <a href="../logout.php">
            Logout
        </a>

    </nav>


</header>



<main class="container">


    <section class="page-title">

        <div class="eyebrow">
            Application Center
        </div>

        <h1>
            My <span>Applications.</span>
        </h1>

        <p>
            Track your internship applications and their latest status.
        </p>

    </section>



    <?php if ($application): ?>


      

        <?php if ($status === "Approved"): ?>

            <div class="notification approved">

                🎉 Congratulations! Your internship application has been approved.

            </div>

        <?php elseif ($status === "Rejected"): ?>

            <div class="notification rejected">

                ❌ Your internship application has been rejected.

            </div>

        <?php else: ?>

            <div class="notification pending">

                ⏳ Your internship application is currently under review.

            </div>

        <?php endif; ?>




        <section class="application-card">


            <div class="top-section">


                <div>

                    <div class="job-title">

                        <?php
                        echo htmlspecialchars(
                            $application["internship"]
                        );
                        ?>

                    </div>


                    <div class="company">

                        <?php
                        echo htmlspecialchars(
                            $application["company"]
                        );
                        ?>

                    </div>

                </div>



                <div class="status

                    <?php

                    if ($status === "Approved") {

                        echo "approved";

                    } elseif ($status === "Rejected") {

                        echo "rejected";

                    } else {

                        echo "pending";

                    }

                    ?>

                ">

                    <?php
                    echo htmlspecialchars($status);
                    ?>

                </div>


            </div>



            <div class="details">


                <div class="detail-box">

                    <small>
                        Student Name
                    </small>

                    <strong>

                        <?php
                        echo htmlspecialchars(
                            $application["student_name"]
                        );
                        ?>

                    </strong>

                </div>



                <div class="detail-box">

                    <small>
                        Email
                    </small>

                    <strong>

                        <?php
                        echo htmlspecialchars(
                            $application["email"]
                        );
                        ?>

                    </strong>

                </div>



                <div class="detail-box">

                    <small>
                        Phone
                    </small>

                    <strong>

                        <?php
                        echo htmlspecialchars(
                            $application["phone"]
                        );
                        ?>

                    </strong>

                </div>



                <div class="detail-box">

                    <small>
                        College
                    </small>

                    <strong>

                        <?php
                        echo htmlspecialchars(
                            $application["college"]
                        );
                        ?>

                    </strong>

                </div>



                <div class="detail-box">

                    <small>
                        Skills
                    </small>

                    <strong>

                        <?php
                        echo htmlspecialchars(
                            $application["skills"]
                        );
                        ?>

                    </strong>

                </div>



                <div class="detail-box">

                    <small>
                        Applied Date
                    </small>

                    <strong>

                        <?php
                        echo htmlspecialchars(
                            $application["applied_at"]
                        );
                        ?>

                    </strong>

                </div>


            </div>


        </section>


    <?php else: ?>


        

        <section class="empty-box">


            <div class="empty-icon">
                ✦
            </div>


            <h2>
                No Applications Yet
            </h2>


            <p>
                You haven't applied for any internship yet.
                Start exploring opportunities today.
            </p>


            <a
                href="internships.php"
                class="browse-btn"
            >
                Browse Internships →
            </a>


        </section>


    <?php endif; ?>


</main>


</body>

</html>