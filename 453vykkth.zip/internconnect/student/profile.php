<?php

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}




if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $_SESSION["user_name"] =
        trim($_POST["name"] ?? "");

    $_SESSION["user_email"] =
        trim($_POST["email"] ?? "");

    $_SESSION["user_phone"] =
        trim($_POST["phone"] ?? "");

    $_SESSION["user_college"] =
        trim($_POST["college"] ?? "");

    $_SESSION["user_skills"] =
        trim($_POST["skills"] ?? "");

    header("Location: profile.php");
    exit();
}


$name =
    $_SESSION["user_name"] ?? "Student";

$email =
    $_SESSION["user_email"] ?? "";

$phone =
    $_SESSION["user_phone"] ?? "";

$college =
    $_SESSION["user_college"] ?? "";

$skills =
    $_SESSION["user_skills"] ?? "";


$edit =
    isset($_GET["edit"]) &&
    $_GET["edit"] === "1";

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>My Profile | InternConnect</title>


<style>



* {

    margin: 0;
    padding: 0;
    box-sizing: border-box;

}

:root {

    --navy: #080d19;

    --navy-light: #101827;

    --card: rgba(17, 26, 42, 0.88);

    --gold: #d4af70;

    --gold-light: #f0d9a4;

    --cream: #f5f1e8;

    --muted: #9ca8ba;

    --border: rgba(212,175,112,0.20);

}


body {

    min-height: 100vh;

    font-family:
        Inter,
        Arial,
        sans-serif;

    color: var(--cream);

    background:

        radial-gradient(
            circle at 10% 10%,
            rgba(212,175,112,0.08),
            transparent 30%
        ),

        radial-gradient(
            circle at 90% 20%,
            rgba(40,70,120,0.15),
            transparent 30%
        ),

        var(--navy);

}


 

.navbar {

    min-height: 78px;

    padding: 0 6%;

    display: flex;

    align-items: center;

    justify-content: space-between;

    background:
        rgba(8,13,25,0.88);

    border-bottom:
        1px solid var(--border);

    backdrop-filter: blur(18px);

    position: sticky;

    top: 0;

    z-index: 100;

}


.logo {

    display: flex;

    align-items: center;

    gap: 12px;

    font-size: 21px;

    font-weight: 700;

}


.logo-mark {

    width: 38px;

    height: 38px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 12px;

    background:
        linear-gradient(
            135deg,
            var(--gold-light),
            var(--gold)
        );

    color: #111;

    font-size: 13px;

    font-weight: 900;

    box-shadow:
        0 8px 25px rgba(212,175,112,0.18);

}


.logo span {

    color: var(--gold);

}


.nav-links {

    display: flex;

    align-items: center;

    gap: 27px;

}


.nav-links a {

    color: #c5cedc;

    text-decoration: none;

    font-size: 14px;

    transition: 0.25s;

}


.nav-links a:hover {

    color: var(--gold-light);

}




.container {

    width: 90%;

    max-width: 950px;

    margin: 55px auto 80px;

}


.heading {

    margin-bottom: 35px;

}


.eyebrow {

    color: var(--gold);

    text-transform: uppercase;

    letter-spacing: 2px;

    font-size: 11px;

    font-weight: 700;

    margin-bottom: 12px;

}


.heading h1 {

    font-family:
        Georgia,
        "Times New Roman",
        serif;

    font-size: clamp(38px, 5vw, 52px);

    font-weight: 500;

    letter-spacing: -1.5px;

    margin-bottom: 12px;

}


.heading h1 span {

    color: var(--gold);

}


.heading p {

    color: var(--muted);

    font-size: 15px;

}




.profile-card {

    position: relative;

    overflow: hidden;

    background:
        rgba(16,24,39,0.86);

    border:
        1px solid var(--border);

    border-radius: 25px;

    padding: 36px;

    box-shadow:
        0 25px 70px rgba(0,0,0,0.28);

    backdrop-filter: blur(15px);

}


.profile-card::before {

    content: "";

    position: absolute;

    width: 220px;

    height: 220px;

    border-radius: 50%;

    background:
        rgba(212,175,112,0.06);

    filter: blur(5px);

    top: -120px;

    right: -80px;

}




.profile-header {

    display: flex;

    align-items: center;

    gap: 22px;

    padding-bottom: 30px;

    margin-bottom: 30px;

    border-bottom:
        1px solid rgba(255,255,255,0.08);

}


.avatar {

    width: 88px;

    height: 88px;

    flex-shrink: 0;

    border-radius: 24px;

    display: flex;

    align-items: center;

    justify-content: center;

    background:
        linear-gradient(
            135deg,
            var(--gold-light),
            var(--gold)
        );

    color: #101010;

    font-family:
        Georgia,
        serif;

    font-size: 34px;

    font-weight: 700;

    box-shadow:
        0 15px 35px rgba(212,175,112,0.16);

}


.profile-header h2 {

    font-family:
        Georgia,
        "Times New Roman",
        serif;

    font-size: 28px;

    font-weight: 500;

    margin-bottom: 7px;

}


.profile-header p {

    color: var(--muted);

    font-size: 14px;

}




.section-title {

    font-family:
        Georgia,
        "Times New Roman",
        serif;

    color: var(--cream);

    font-size: 23px;

    font-weight: 500;

    margin-bottom: 20px;

}




.details {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 15px;

}


.detail-box {

    background:
        rgba(7,12,22,0.55);

    border:
        1px solid rgba(255,255,255,0.07);

    padding: 18px;

    border-radius: 14px;

    transition: 0.25s;

}


.detail-box:hover {

    border-color:
        rgba(212,175,112,0.22);

    transform: translateY(-2px);

}


.detail-box small {

    display: block;

    color: #7f8b9e;

    text-transform: uppercase;

    letter-spacing: 0.7px;

    font-size: 10px;

    margin-bottom: 8px;

}


.detail-box strong {

    display: block;

    color: #e8ebf0;

    font-size: 14px;

    line-height: 1.5;

    word-break: break-word;

}


.full-width {

    grid-column: 1 / -1;

}



.input-box {

    width: 100%;

    padding: 13px 14px;

    border-radius: 11px;

    border:
        1px solid rgba(255,255,255,0.10);

    background:
        rgba(4,9,18,0.65);

    color: white;

    font-size: 14px;

    outline: none;

    transition: 0.25s;

}


.input-box::placeholder {

    color: #657083;

}


.input-box:focus {

    border-color:
        var(--gold);

    box-shadow:
        0 0 0 3px
        rgba(212,175,112,0.08);

}




.status-section {

    margin-top: 28px;

    padding: 21px;

    border-radius: 15px;

    background:
        rgba(212,175,112,0.07);

    border:
        1px solid rgba(212,175,112,0.18);

}


.status-section h3 {

    color: var(--gold-light);

    font-size: 15px;

    margin-bottom: 8px;

}


.status-section p {

    color: var(--muted);

    font-size: 13px;

    line-height: 1.6;

}



.buttons {

    display: flex;

    align-items: center;

    gap: 12px;

    margin-top: 27px;

}


.edit-btn,
.save-btn,
.cancel-btn,
.back-btn {

    display: inline-flex;

    align-items: center;

    justify-content: center;

    padding: 12px 20px;

    border-radius: 11px;

    text-decoration: none;

    font-size: 13px;

    font-weight: 800;

    cursor: pointer;

    transition: 0.25s;

}



.edit-btn,
.save-btn {

    border: none;

    background:
        linear-gradient(
            135deg,
            var(--gold-light),
            var(--gold)
        );

    color: #111;

    box-shadow:
        0 10px 25px rgba(212,175,112,0.13);

}


.edit-btn:hover,
.save-btn:hover {

    transform: translateY(-2px);

    box-shadow:
        0 15px 30px rgba(212,175,112,0.22);

}



.cancel-btn {

    background:
        rgba(255,255,255,0.07);

    color: #cbd3df;

    border:
        1px solid rgba(255,255,255,0.09);

}


.cancel-btn:hover {

    background:
        rgba(255,255,255,0.11);

}



.back-btn {

    background:
        transparent;

    color: var(--gold-light);

    border:
        1px solid rgba(212,175,112,0.22);

}


.back-btn:hover {

    background:
        rgba(212,175,112,0.08);

}



@media(max-width: 760px) {

    .navbar {

        padding: 18px 5%;

        flex-direction: column;

        gap: 17px;

    }

    .nav-links {

        gap: 15px;

        flex-wrap: wrap;

        justify-content: center;

    }

    .nav-links a {

        font-size: 12px;

    }

    .container {

        width: 92%;

        margin-top: 38px;

    }

    .profile-card {

        padding: 25px;

    }

    .profile-header {

        flex-direction: column;

        text-align: center;

    }

    .details {

        grid-template-columns: 1fr;

    }

    .full-width {

        grid-column: auto;

    }

    .buttons {

        flex-direction: column;

        align-items: stretch;

    }

}


</style>

</head>


<body>




<header class="navbar">


    <div class="logo">

        <div class="logo-mark">
            IC
        </div>

        <div>
            Intern<span>Connect</span>
        </div>

    </div>


    <nav class="nav-links">

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="internships.php">
            Internships
        </a>

        <a href="my-applications.php">
            Applications
        </a>

        <a href="../logout.php">
            Logout
        </a>

    </nav>


</header>





<main class="container">


    <section class="heading">

        <div class="eyebrow">
            Personal Space
        </div>

        <h1>
            My <span>Profile.</span>
        </h1>

        <p>
            Manage your InternConnect profile information.
        </p>

    </section>



    <section class="profile-card">


        

        <div class="profile-header">


            <div class="avatar">

                <?php

                echo strtoupper(
                    substr($name, 0, 1)
                );

                ?>

            </div>


            <div>

                <h2>

                    <?php

                    echo htmlspecialchars(
                        $name
                    );

                    ?>

                </h2>


                <p>

                    <?php

                    echo htmlspecialchars(
                        $email
                    );

                    ?>

                </p>

            </div>


        </div>



        <?php if ($edit): ?>


            
            <h3 class="section-title">
                Edit Personal Information
            </h3>


            <form
                method="POST"
                action="profile.php"
            >


                <div class="details">


                    <div class="detail-box">

                        <small>
                            Full Name
                        </small>

                        <input
                            type="text"
                            name="name"
                            class="input-box"
                            value="<?php
                            echo htmlspecialchars(
                                $name
                            );
                            ?>"
                            required
                        >

                    </div>



                    <div class="detail-box">

                        <small>
                            Email Address
                        </small>

                        <input
                            type="email"
                            name="email"
                            class="input-box"
                            value="<?php
                            echo htmlspecialchars(
                                $email
                            );
                            ?>"
                            required
                        >

                    </div>



                    <div class="detail-box">

                        <small>
                            Phone Number
                        </small>

                        <input
                            type="text"
                            name="phone"
                            class="input-box"
                            value="<?php
                            echo htmlspecialchars(
                                $phone
                            );
                            ?>"
                            placeholder="Enter phone number"
                        >

                    </div>



                    <div class="detail-box">

                        <small>
                            College
                        </small>

                        <input
                            type="text"
                            name="college"
                            class="input-box"
                            value="<?php
                            echo htmlspecialchars(
                                $college
                            );
                            ?>"
                            placeholder="Enter college name"
                        >

                    </div>



                    <div class="detail-box full-width">

                        <small>
                            Skills
                        </small>

                        <input
                            type="text"
                            name="skills"
                            class="input-box"
                            value="<?php
                            echo htmlspecialchars(
                                $skills
                            );
                            ?>"
                            placeholder="PHP, HTML, CSS, JavaScript..."
                        >

                    </div>


                </div>



                <div class="buttons">


                    <button
                        type="submit"
                        class="save-btn"
                    >
                        Save Profile
                    </button>


                    <a
                        href="profile.php"
                        class="cancel-btn"
                    >
                        Cancel
                    </a>


                </div>


            </form>



        <?php else: ?>


            
            <h3 class="section-title">
                Personal Information
            </h3>


            <div class="details">


                <div class="detail-box">

                    <small>
                        Full Name
                    </small>

                    <strong>

                        <?php

                        echo htmlspecialchars(
                            $name
                        );

                        ?>

                    </strong>

                </div>



                <div class="detail-box">

                    <small>
                        Email Address
                    </small>

                    <strong>

                        <?php

                        echo htmlspecialchars(
                            $email
                        );

                        ?>

                    </strong>

                </div>



                <div class="detail-box">

                    <small>
                        Phone Number
                    </small>

                    <strong>

                        <?php

                        echo $phone !== ""
                            ? htmlspecialchars($phone)
                            : "Not added";

                        ?>

                    </strong>

                </div>



                <div class="detail-box">

                    <small>
                        College
                    </small>

                    <strong>

                        <?php

                        echo $college !== ""
                            ? htmlspecialchars($college)
                            : "Not added";

                        ?>

                    </strong>

                </div>



                <div class="detail-box full-width">

                    <small>
                        Skills
                    </small>

                    <strong>

                        <?php

                        echo $skills !== ""
                            ? htmlspecialchars($skills)
                            : "Not added";

                        ?>

                    </strong>

                </div>



                <div class="detail-box">

                    <small>
                        Account Type
                    </small>

                    <strong>
                        Student
                    </strong>

                </div>



                <div class="detail-box">

                    <small>
                        Profile Status
                    </small>

                    <strong>
                        Active
                    </strong>

                </div>


            </div>



            
            <div class="status-section">

                <h3>
                    Profile Progress
                </h3>

                <p>
                    Keep your profile updated with your phone number,
                    college and skills to make your internship applications
                    more complete.
                </p>

            </div>



            <div class="buttons">


                <a
                    href="profile.php?edit=1"
                    class="edit-btn"
                >
                    Edit Profile
                </a>


                <a
                    href="dashboard.php"
                    class="back-btn"
                >
                    ← Back to Dashboard
                </a>


            </div>


        <?php endif; ?>


    </section>


</main>


</body>

</html>