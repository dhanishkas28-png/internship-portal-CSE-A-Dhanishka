<?php

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$internships = [

    1 => [
        "title" => "Web Development Intern",
        "company" => "TechNova Solutions",
        "location" => "Chennai",
        "skills" => "HTML, CSS, JavaScript, PHP",
        "stipend" => "₹10,000/month",
        "duration" => "3 Months",
        "type" => "On-site",
        "description" => "Work on real-world web development projects and build responsive websites using modern web technologies.",
        "responsibilities" => [
            "Develop responsive web pages",
            "Work with HTML, CSS and JavaScript",
            "Develop backend features using PHP",
            "Fix bugs and improve website performance"
        ]
    ],

    2 => [
        "title" => "Python Developer Intern",
        "company" => "CodeCraft Technologies",
        "location" => "Bangalore",
        "skills" => "Python, SQL, Git",
        "stipend" => "₹12,000/month",
        "duration" => "3 Months",
        "type" => "Hybrid",
        "description" => "Learn Python development and work on practical software development projects.",
        "responsibilities" => [
            "Develop Python programs",
            "Work with SQL databases",
            "Use Git for version control",
            "Test and debug applications"
        ]
    ],

    3 => [
        "title" => "Data Science Intern",
        "company" => "DataVision Labs",
        "location" => "Remote",
        "skills" => "Python, Pandas, Machine Learning",
        "stipend" => "₹15,000/month",
        "duration" => "4 Months",
        "type" => "Remote",
        "description" => "Work with real-world datasets and learn data analysis and machine learning techniques.",
        "responsibilities" => [
            "Analyze datasets using Python",
            "Use Pandas for data processing",
            "Build basic machine learning models",
            "Prepare data visualizations"
        ]
    ],

    4 => [
        "title" => "PHP Developer Intern",
        "company" => "WebCore Technologies",
        "location" => "Chennai",
        "skills" => "PHP, MySQL, HTML, CSS",
        "stipend" => "₹11,000/month",
        "duration" => "3 Months",
        "type" => "On-site",
        "description" => "Develop dynamic websites and backend applications using PHP.",
        "responsibilities" => [
            "Develop PHP applications",
            "Create dynamic web pages",
            "Work with databases",
            "Test and debug PHP applications"
        ]
    ],

    5 => [
        "title" => "Java Developer Intern",
        "company" => "InnovateSoft",
        "location" => "Hyderabad",
        "skills" => "Java, Spring Boot, SQL",
        "stipend" => "₹14,000/month",
        "duration" => "4 Months",
        "type" => "Hybrid",
        "description" => "Learn Java backend development and work with Spring Boot applications.",
        "responsibilities" => [
            "Develop Java applications",
            "Work with Spring Boot",
            "Create REST APIs",
            "Work with SQL databases"
        ]
    ],

    6 => [
        "title" => "AI & Machine Learning Intern",
        "company" => "FutureMind AI",
        "location" => "Remote",
        "skills" => "Python, AI, Machine Learning",
        "stipend" => "₹18,000/month",
        "duration" => "6 Months",
        "type" => "Remote",
        "description" => "Explore artificial intelligence and machine learning through practical projects.",
        "responsibilities" => [
            "Build machine learning models",
            "Work with Python",
            "Analyze datasets",
            "Experiment with AI techniques"
        ]
    ],

    7 => [
        "title" => "Frontend Developer Intern",
        "company" => "PixelWorks Studio",
        "location" => "Chennai",
        "skills" => "HTML, CSS, JavaScript, React",
        "stipend" => "₹12,000/month",
        "duration" => "3 Months",
        "type" => "On-site",
        "description" => "Create modern and responsive user interfaces for web applications.",
        "responsibilities" => [
            "Create responsive websites",
            "Develop UI components",
            "Work with JavaScript",
            "Learn React development"
        ]
    ],

    8 => [
        "title" => "Backend Developer Intern",
        "company" => "ServerStack Technologies",
        "location" => "Bangalore",
        "skills" => "PHP, Node.js, MySQL",
        "stipend" => "₹13,000/month",
        "duration" => "4 Months",
        "type" => "Hybrid",
        "description" => "Work on backend systems and server-side applications.",
        "responsibilities" => [
            "Develop backend applications",
            "Work with APIs",
            "Manage databases",
            "Test server-side functionality"
        ]
    ],

    9 => [
        "title" => "Cyber Security Intern",
        "company" => "SecureNet Labs",
        "location" => "Hyderabad",
        "skills" => "Cyber Security, Networking, Linux",
        "stipend" => "₹16,000/month",
        "duration" => "4 Months",
        "type" => "On-site",
        "description" => "Learn cybersecurity concepts and practical network security techniques.",
        "responsibilities" => [
            "Learn security fundamentals",
            "Analyze network security",
            "Work with Linux",
            "Identify common security issues"
        ]
    ],

    10 => [
        "title" => "Cloud Computing Intern",
        "company" => "CloudNova Technologies",
        "location" => "Remote",
        "skills" => "AWS, Cloud, Linux",
        "stipend" => "₹15,000/month",
        "duration" => "3 Months",
        "type" => "Remote",
        "description" => "Learn cloud computing concepts and work with cloud technologies.",
        "responsibilities" => [
            "Learn cloud computing",
            "Work with AWS services",
            "Manage Linux systems",
            "Understand cloud deployment"
        ]
    ],

    11 => [
        "title" => "UI/UX Design Intern",
        "company" => "CreativePixel",
        "location" => "Chennai",
        "skills" => "Figma, UI Design, UX Research",
        "stipend" => "₹9,000/month",
        "duration" => "3 Months",
        "type" => "On-site",
        "description" => "Design attractive and user-friendly interfaces for digital products.",
        "responsibilities" => [
            "Create UI designs",
            "Develop Figma prototypes",
            "Conduct UX research",
            "Improve user experience"
        ]
    ],

    12 => [
        "title" => "Mobile App Development Intern",
        "company" => "AppWorks Technologies",
        "location" => "Coimbatore",
        "skills" => "Flutter, Dart, Firebase",
        "stipend" => "₹13,000/month",
        "duration" => "4 Months",
        "type" => "On-site",
        "description" => "Build mobile applications using Flutter and Firebase.",
        "responsibilities" => [
            "Develop Flutter applications",
            "Learn Dart programming",
            "Work with Firebase",
            "Test mobile applications"
        ]
    ]

];


$id = isset($_GET["id"])
    ? (int)$_GET["id"]
    : 1;



if (!isset($internships[$id])) {
    $id = 1;
}


$internship = $internships[$id];

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>
<?php echo htmlspecialchars($internship["title"]); ?> | InternConnect
</title>


<style>



* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {

    font-family:
        "Segoe UI",
        Arial,
        sans-serif;

    color: #f8f5ed;

    min-height: 100vh;

    background:

        radial-gradient(
            circle at 8% 5%,
            rgba(212,175,55,.12),
            transparent 28%
        ),

        radial-gradient(
            circle at 92% 15%,
            rgba(65,89,145,.18),
            transparent 30%
        ),

        radial-gradient(
            circle at 50% 100%,
            rgba(212,175,55,.07),
            transparent 35%
        ),

        #07111f;
}



.topbar {

    position: sticky;

    top: 0;

    z-index: 1000;

    display: flex;

    justify-content: space-between;

    align-items: center;

    padding: 17px 6%;

    background:
        rgba(7,17,31,.90);

    border-bottom:
        1px solid rgba(212,175,55,.18);

    backdrop-filter:
        blur(18px);

    box-shadow:
        0 10px 40px rgba(0,0,0,.20);}
.logo {

    display: flex;

    align-items: center;

    gap: 11px;

    color: white;

    font-size: 21px;

    font-weight: 800;
}

.logo-mark {

    width: 40px;

    height: 40px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 12px;

    color: #07111f;

    font-size: 13px;

    font-weight: 900;

    background:
        linear-gradient(
            135deg,
            #f4d889,
            #c99b2e
        );

    box-shadow:
        0 8px 25px rgba(212,175,55,.25);
}

.logo span {
    color: #d9b95f;
}




nav {

    display: flex;

    align-items: center;

    gap: 6px;

    flex-wrap: wrap;
}

nav a {

    text-decoration: none;

    color: #c5cfdb;

    padding: 9px 14px;

    border-radius: 10px;

    font-size: 13px;

    font-weight: 600;

    transition: .3s;
}

nav a:hover {

    color: #f5d982;

    background:
        rgba(212,175,55,.08);
}

nav a.active {

    color: #f5d982;

    background:
        rgba(212,175,55,.10);

    border:
        1px solid rgba(212,175,55,.20);
}

.logout {

    color: #ffcaca !important;

    border:
        1px solid rgba(255,80,80,.22);

    background:
        rgba(180,40,40,.09);
}

.logout:hover {

    color: white !important;

    background:
        rgba(220,60,60,.20) !important;
}



.container {

    width: 92%;

    max-width: 1150px;

    margin: auto;

    padding: 40px 0 70px;
}



.back {

    display: inline-flex;

    align-items: center;

    gap: 7px;

    margin-bottom: 20px;

    color: #d8bd69;

    text-decoration: none;

    font-size: 13px;

    font-weight: 700;

    transition: .3s;
}

.back:hover {

    color: #f5dc8d;

    transform:
        translateX(-3px);
}



.hero {

    position: relative;

    overflow: hidden;

    padding: 42px;

    margin-bottom: 25px;

    border-radius: 25px;

    background:

        linear-gradient(
            135deg,
            rgba(22,40,64,.97),
            rgba(8,22,38,.94)
        );

    border:
        1px solid rgba(212,175,55,.20);

    box-shadow:
        0 25px 70px rgba(0,0,0,.28);
}

.hero::before {

    content: "";

    position: absolute;

    width: 330px;

    height: 330px;

    right: -100px;

    top: -160px;

    border-radius: 50%;

    background:
        radial-gradient(
            circle,
            rgba(212,175,55,.19),
            transparent 70%
        );
}

.hero::after {

    content: "";

    position: absolute;

    width: 200px;

    height: 200px;

    left: 42%;

    bottom: -140px;

    border-radius: 50%;

    background:
        radial-gradient(
            circle,
            rgba(67,92,150,.15),
            transparent 70%
        );
}

.hero-content {

    position: relative;

    z-index: 2;
}

.hero-label {

    display: inline-block;

    margin-bottom: 13px;

    color: #d9b95f;

    font-size: 11px;

    font-weight: 700;

    letter-spacing: 2px;

    text-transform: uppercase;
}

.hero h1 {

    max-width: 800px;

    color: #fff;

    font-size: 36px;

    line-height: 1.2;

    margin-bottom: 10px;
}

.hero .company {

    color: #d6b85e;

    font-size: 15px;

    font-weight: 700;

    margin-bottom: 25px;
}




.tags {

    display: flex;

    flex-wrap: wrap;

    gap: 10px;
}

.tag {

    padding: 9px 13px;

    border-radius: 30px;

    color: #d6deea;

    background:
        rgba(255,255,255,.045);

    border:
        1px solid rgba(255,255,255,.09);

    font-size: 11px;

    font-weight: 600;
}




.content {

    display: grid;

    grid-template-columns:
        minmax(0, 2fr)
        minmax(280px, 1fr);

    gap: 24px;

    align-items: start;
}



.card {

    position: relative;

    padding: 27px;

    margin-bottom: 18px;

    border-radius: 19px;

    background:
        linear-gradient(
            145deg,
            rgba(18,34,55,.94),
            rgba(8,21,36,.94)
        );

    border:
        1px solid rgba(255,255,255,.07);

    box-shadow:
        0 16px 45px rgba(0,0,0,.18);
}

.card h2 {

    display: flex;

    align-items: center;

    gap: 10px;

    color: #f7f2e7;

    font-size: 19px;

    margin-bottom: 16px;
}

.card h2::before {

    content: "";

    width: 4px;

    height: 20px;

    border-radius: 5px;

    background:
        linear-gradient(
            #f1d47b,
            #b88620
        );
}

.card p {

    color: #9aa7b7;

    font-size: 13px;

    line-height: 1.8;
}




.skills-box {

    display: flex;

    flex-wrap: wrap;

    gap: 8px;
}

.skill {

    padding: 8px 12px;

    border-radius: 20px;

    color: #d7c170;

    background:
        rgba(212,175,55,.07);

    border:
        1px solid rgba(212,175,55,.15);

    font-size: 11px;

    font-weight: 650;
}



.card ul {

    list-style: none;

    padding: 0;
}

.card li {

    position: relative;

    padding: 10px 12px 10px 32px;

    margin-bottom: 8px;

    color: #a4afbd;

    font-size: 13px;

    line-height: 1.5;

    border-radius: 10px;

    background:
        rgba(255,255,255,.025);

    border:
        1px solid rgba(255,255,255,.04);
}

.card li::before {

    content: "✓";

    position: absolute;

    left: 12px;

    top: 9px;

    color: #d8ba62;

    font-weight: 800;
}




.summary {

    position: sticky;

    top: 90px;

    padding: 25px;

    border-radius: 20px;

    background:
        linear-gradient(
            145deg,
            rgba(20,37,59,.96),
            rgba(8,22,38,.95)
        );

    border:
        1px solid rgba(212,175,55,.16);

    box-shadow:
        0 20px 50px rgba(0,0,0,.24);
}

.summary h2 {

    color: #f6f0e4;

    font-size: 19px;

    margin-bottom: 18px;
}

.info {

    padding: 14px 0;

    border-bottom:
        1px solid rgba(255,255,255,.06);
}

.info:last-of-type {
    border-bottom: none;
}

.info strong {

    display: block;

    color: #d8e0eb;

    font-size: 11px;

    text-transform: uppercase;

    letter-spacing: .8px;

    margin-bottom: 5px;
}

.info span {

    color: #929eaf;

    font-size: 13px;
}




.apply-btn {

    display: block;

    width: 100%;

    padding: 13px;

    margin-top: 20px;

    text-align: center;

    text-decoration: none;

    color: #081321;

    border-radius: 11px;

    background:
        linear-gradient(
            135deg,
            #f1d47b,
            #c79c31
        );

    font-size: 13px;

    font-weight: 800;

    box-shadow:
        0 10px 25px rgba(212,175,55,.15);

    transition: .3s;
}

.apply-btn:hover {

    transform:
        translateY(-2px);

    box-shadow:
        0 15px 35px rgba(212,175,55,.25);
}




.footer {

    padding: 28px 20px;

    text-align: center;

    color: #687587;

    font-size: 11px;

    border-top:
        1px solid rgba(255,255,255,.05);
}




@media (max-width: 850px) {

    .content {

        grid-template-columns: 1fr;
    }

    .summary {

        position: static;
    }

}

@media (max-width: 700px) {

    .topbar {

        flex-direction: column;

        align-items: flex-start;

        gap: 15px;

        padding: 15px 20px;
    }

    nav {

        width: 100%;
    }

    nav a {

        padding: 8px 9px;

        font-size: 11px;
    }

    .container {

        width: 94%;

        padding-top: 25px;
    }

    .hero {

        padding: 30px 22px;
    }

    .hero h1 {

        font-size: 27px;
    }

    .card {

        padding: 22px 18px;
    }

    .summary {

        padding: 22px 18px;
    }

}

</style>

</head>


<body>




<header class="topbar">


    <div class="logo">

        <div class="logo-mark">
            IC
        </div>

        <div>
            <span>Intern</span>Connect
        </div>

    </div>


    <nav>

        <a href="../index.php">
            Home
        </a>

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="internships.php" class="active">
            Internships
        </a>

        <a href="my-applications.php">
            Applications
        </a>

        <a href="profile.php">
            Profile
        </a>

        <a href="../logout.php" class="logout">
            Logout
        </a>

    </nav>


</header>




<div class="container">


    <a
        href="internships.php"
        class="back"
    >
        ← Back to Internships
    </a>


    

    <section class="hero">


        <div class="hero-content">

            <div class="hero-label">
                Internship Opportunity
            </div>


            <h1>

                <?php

                echo htmlspecialchars(
                    $internship["title"]
                );

                ?>

            </h1>


            <div class="company">

                <?php

                echo htmlspecialchars(
                    $internship["company"]
                );

                ?>

            </div>


            <div class="tags">


                <span class="tag">

                    📍

                    <?php

                    echo htmlspecialchars(
                        $internship["location"]
                    );

                    ?>

                </span>


                <span class="tag">

                    💰

                    <?php

                    echo htmlspecialchars(
                        $internship["stipend"]
                    );

                    ?>

                </span>


                <span class="tag">

                    ⏱

                    <?php

                    echo htmlspecialchars(
                        $internship["duration"]
                    );

                    ?>

                </span>


                <span class="tag">

                    💼

                    <?php

                    echo htmlspecialchars(
                        $internship["type"]
                    );

                    ?>

                </span>


            </div>

        </div>


    </section>


    

    <div class="content">


        

        <div>


            

            <section class="card">

                <h2>
                    About the Internship
                </h2>

                <p>

                    <?php

                    echo htmlspecialchars(
                        $internship["description"]
                    );

                    ?>

                </p>

            </section>


            

            <section class="card">

                <h2>
                    Required Skills
                </h2>


                <div class="skills-box">

                    <?php

                    $skills =
                        explode(
                            ",",
                            $internship["skills"]
                        );

                    foreach ($skills as $skill):

                    ?>

                        <span class="skill">

                            <?php

                            echo htmlspecialchars(
                                trim($skill)
                            );

                            ?>

                        </span>

                    <?php endforeach; ?>

                </div>

            </section>


            
            <section class="card">

                <h2>
                    Responsibilities
                </h2>


                <ul>

                    <?php

                    foreach (
                        $internship["responsibilities"]
                        as $responsibility
                    ):

                    ?>

                        <li>

                            <?php

                            echo htmlspecialchars(
                                $responsibility
                            );

                            ?>

                        </li>

                    <?php endforeach; ?>

                </ul>

            </section>


            
            <section class="card">

                <h2>
                    Who Can Apply?
                </h2>


                <ul>

                    <li>
                        Students pursuing a relevant degree
                    </li>

                    <li>
                        Students interested in practical projects
                    </li>

                    <li>
                        Basic knowledge of required skills
                    </li>

                    <li>
                        Good communication and learning ability
                    </li>

                </ul>

            </section>


        </div>


        

        <aside class="summary">


            <h2>
                Internship Summary
            </h2>


            <div class="info">

                <strong>
                    Company
                </strong>

                <span>

                    <?php

                    echo htmlspecialchars(
                        $internship["company"]
                    );

                    ?>

                </span>

            </div>


            <div class="info">

                <strong>
                    Location
                </strong>

                <span>

                    <?php

                    echo htmlspecialchars(
                        $internship["location"]
                    );

                    ?>

                </span>

            </div>


            <div class="info">

                <strong>
                    Duration
                </strong>

                <span>

                    <?php

                    echo htmlspecialchars(
                        $internship["duration"]
                    );

                    ?>

                </span>

            </div>


            <div class="info">

                <strong>
                    Stipend
                </strong>

                <span>

                    <?php

                    echo htmlspecialchars(
                        $internship["stipend"]
                    );

                    ?>

                </span>

            </div>


            <div class="info">

                <strong>
                    Work Type
                </strong>

                <span>

                    <?php

                    echo htmlspecialchars(
                        $internship["type"]
                    );

                    ?>

                </span>

            </div>


            <a
                href="apply.php?id=<?php echo $id; ?>"
                class="apply-btn"
            >
                Apply Now →
            </a>


        </aside>


    </div>


</div>


<footer class="footer">

    © 2026 InternConnect · Student Career Portal

</footer>


</body>

</html>