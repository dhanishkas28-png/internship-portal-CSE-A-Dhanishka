<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}


$userName = $_SESSION["user_name"] ?? "Student";
$userEmail = $_SESSION["user_email"] ?? "";

$applications = $_SESSION["applications"] ?? [];
$totalApplications = count($applications);


$pendingApplications = 0;
$approvedApplications = 0;
$rejectedApplications = 0;

foreach ($applications as $application) {

    $status = $application["status"] ?? "Pending";

    if ($status === "Pending") {
        $pendingApplications++;
    } elseif ($status === "Approved") {
        $approvedApplications++;
    } elseif ($status === "Rejected") {
        $rejectedApplications++;
    }
}


$profileFields = [
    $_SESSION["user_name"] ?? "",
    $_SESSION["user_email"] ?? "",
    $_SESSION["user_phone"] ?? "",
    $_SESSION["user_college"] ?? "",
    $_SESSION["user_skills"] ?? ""
];

$completedFields = 0;

foreach ($profileFields as $field) {
    if (trim($field) !== "") {
        $completedFields++;
    }
}

$profileStatus = round(($completedFields / count($profileFields)) * 100);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Student Dashboard | InternConnect</title>

<style>


* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    font-family: "Segoe UI", Arial, sans-serif;
    color: #f8f5ed;

    background:
        radial-gradient(
            circle at 10% 10%,
            rgba(212,175,55,0.12),
            transparent 28%
        ),
        radial-gradient(
            circle at 90% 20%,
            rgba(72,91,145,0.20),
            transparent 30%
        ),
        radial-gradient(
            circle at 50% 100%,
            rgba(212,175,55,0.08),
            transparent 35%
        ),
        #07111f;

    min-height: 100vh;
}




.topbar {

    position: sticky;
    top: 0;
    z-index: 1000;

    display: flex;
    justify-content: space-between;
    align-items: center;

    padding: 18px 6%;

    background: rgba(7,17,31,0.88);

    border-bottom: 1px solid rgba(212,175,55,0.18);

    backdrop-filter: blur(18px);

    box-shadow:
        0 10px 40px rgba(0,0,0,0.20);
}




.logo {

    display: flex;
    align-items: center;
    gap: 11px;

    color: #fff;

    font-size: 22px;
    font-weight: 800;
    letter-spacing: -0.5px;
}

.logo-mark {

    width: 40px;
    height: 40px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 12px;

    color: #08111e;

    background:
        linear-gradient(
            135deg,
            #f4d889,
            #c99b2e
        );

    font-size: 14px;
    font-weight: 900;

    box-shadow:
        0 8px 25px rgba(212,175,55,0.25);
}

.logo span {
    color: #d9b95f;
}




nav {

    display: flex;
    align-items: center;
    gap: 7px;

    flex-wrap: wrap;
}

nav a {

    text-decoration: none;

    color: #c9d1dc;

    padding: 10px 15px;

    border-radius: 10px;

    font-size: 13px;
    font-weight: 600;

    transition: 0.3s;
}

nav a:hover {

    color: #f5d982;

    background: rgba(212,175,55,0.08);
}

nav a.active {

    color: #f5d982;

    background: rgba(212,175,55,0.10);

    border: 1px solid rgba(212,175,55,0.20);
}

.logout {

    color: #ffd0d0 !important;

    border: 1px solid rgba(255,90,90,0.25);

    background: rgba(180,40,40,0.10);
}

.logout:hover {

    background: rgba(220,60,60,0.20) !important;

    color: #fff !important;
}



.container {

    width: 92%;
    max-width: 1250px;

    margin: auto;

    padding: 45px 0 70px;
}




.welcome {

    position: relative;

    overflow: hidden;

    padding: 45px;

    margin-bottom: 25px;

    border-radius: 25px;

    background:
        linear-gradient(
            135deg,
            rgba(20,35,58,0.95),
            rgba(10,22,38,0.88)
        );

    border: 1px solid rgba(212,175,55,0.20);

    box-shadow:
        0 25px 70px rgba(0,0,0,0.28);
}




.welcome::before {

    content: "";

    position: absolute;

    width: 260px;
    height: 260px;

    right: -80px;
    top: -100px;

    border-radius: 50%;

    background:
        radial-gradient(
            circle,
            rgba(212,175,55,0.20),
            transparent 70%
        );
}

.welcome::after {

    content: "";

    position: absolute;

    width: 180px;
    height: 180px;

    left: 45%;
    bottom: -130px;

    border-radius: 50%;

    background:
        radial-gradient(
            circle,
            rgba(80,105,170,0.20),
            transparent 70%
        );
}

.welcome-content {
    position: relative;
    z-index: 2;
}

.welcome-label {

    display: inline-block;

    color: #d9b95f;

    font-size: 12px;

    font-weight: 700;

    letter-spacing: 2px;

    text-transform: uppercase;

    margin-bottom: 12px;
}

.welcome h1 {

    font-size: 36px;

    line-height: 1.15;

    margin-bottom: 12px;

    color: #fff;
}

.welcome h1 span {
    color: #e1c568;
}

.welcome p {

    color: #aeb9c8;

    font-size: 15px;

    line-height: 1.7;

    max-width: 680px;
}




.stats {

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 18px;

    margin-bottom: 25px;
}

.stat-card {

    position: relative;

    overflow: hidden;

    padding: 25px;

    min-height: 145px;

    border-radius: 20px;

    background:
        linear-gradient(
            145deg,
            rgba(19,35,57,0.92),
            rgba(10,24,40,0.90)
        );

    border: 1px solid rgba(255,255,255,0.07);

    box-shadow:
        0 15px 40px rgba(0,0,0,0.20);

    transition: 0.3s;
}

.stat-card:hover {

    transform: translateY(-5px);

    border-color:
        rgba(212,175,55,0.30);

    box-shadow:
        0 20px 50px rgba(0,0,0,0.30);
}

.stat-card::after {

    content: "";

    position: absolute;

    width: 100px;
    height: 100px;

    right: -35px;
    bottom: -40px;

    border-radius: 50%;

    background:
        rgba(212,175,55,0.07);
}

.stat-title {

    color: #94a3b8;

    font-size: 12px;

    text-transform: uppercase;

    letter-spacing: 1px;

    margin-bottom: 15px;
}

.stat-number {

    font-size: 34px;

    font-weight: 800;

    color: #f7f3e8;
}

.stat-icon {

    position: absolute;

    right: 22px;
    top: 22px;

    width: 42px;
    height: 42px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 12px;

    background: rgba(212,175,55,0.10);

    border: 1px solid rgba(212,175,55,0.18);

    font-size: 19px;
}




.section {

    padding: 28px;

    margin-bottom: 25px;

    border-radius: 22px;

    background:
        linear-gradient(
            145deg,
            rgba(18,33,54,0.90),
            rgba(8,21,36,0.92)
        );

    border: 1px solid rgba(255,255,255,0.06);

    box-shadow:
        0 18px 50px rgba(0,0,0,0.18);
}

.section-title {

    display: flex;
    align-items: center;
    gap: 10px;

    color: #f8f5ed;

    font-size: 20px;

    font-weight: 750;

    margin-bottom: 20px;
}

.section-title::before {

    content: "";

    width: 4px;
    height: 22px;

    border-radius: 5px;

    background:
        linear-gradient(
            #f1d37b,
            #b88620
        );
}




.actions {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 17px;
}

.action-card {

    position: relative;

    overflow: hidden;

    text-decoration: none;

    color: #fff;

    padding: 25px;

    border-radius: 17px;

    background:
        rgba(255,255,255,0.025);

    border: 1px solid rgba(255,255,255,0.08);

    transition: 0.3s;
}

.action-card::before {

    content: "";

    position: absolute;

    top: 0;
    left: 0;

    width: 100%;
    height: 2px;

    background:
        linear-gradient(
            90deg,
            transparent,
            #d5b452,
            transparent
        );

    opacity: 0;

    transition: 0.3s;
}

.action-card:hover {

    transform: translateY(-6px);

    background:
        rgba(212,175,55,0.055);

    border-color:
        rgba(212,175,55,0.25);

    box-shadow:
        0 18px 40px rgba(0,0,0,0.25);
}

.action-card:hover::before {
    opacity: 1;
}

.action-icon {

    width: 50px;
    height: 50px;

    display: flex;
    align-items: center;
    justify-content: center;

    margin-bottom: 17px;

    border-radius: 14px;

    background:
        rgba(212,175,55,0.09);

    border:
        1px solid rgba(212,175,55,0.17);

    font-size: 23px;
}

.action-card h3 {

    color: #f7f2e6;

    font-size: 16px;

    margin-bottom: 8px;
}

.action-card p {

    color: #8f9bad;

    font-size: 13px;

    line-height: 1.6;
}




.application {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    padding: 19px;

    margin-bottom: 12px;

    border-radius: 15px;

    background:
        rgba(255,255,255,0.025);

    border:
        1px solid rgba(255,255,255,0.07);

    transition: 0.3s;
}

.application:hover {

    border-color:
        rgba(212,175,55,0.20);

    background:
        rgba(212,175,55,0.035);
}

.application:last-child {
    margin-bottom: 0;
}

.application h3 {

    color: #f5f1e8;

    font-size: 15px;

    margin-bottom: 6px;
}

.application p {

    color: #8f9bad;

    font-size: 13px;
}

.status {

    padding: 7px 13px;

    border-radius: 30px;

    font-size: 11px;

    font-weight: 700;

    letter-spacing: .5px;

    white-space: nowrap;
}

.pending {

    background: rgba(245,158,11,0.12);

    color: #f5c76b;

    border: 1px solid rgba(245,158,11,0.20);
}

.approved {

    background: rgba(34,197,94,0.11);

    color: #7ee49b;

    border: 1px solid rgba(34,197,94,0.20);
}

.rejected {

    background: rgba(239,68,68,0.11);

    color: #ff9898;

    border: 1px solid rgba(239,68,68,0.20);
}

.empty {

    text-align: center;

    padding: 35px 20px;

    color: #8490a2;

    font-size: 14px;

    line-height: 1.8;
}




.profile-button {

    display: inline-block;

    text-decoration: none;

    color: #101827;

    background:
        linear-gradient(
            135deg,
            #f1d47b,
            #c79c31
        );

    padding: 11px 19px;

    border-radius: 10px;

    font-size: 13px;

    font-weight: 750;

    box-shadow:
        0 8px 22px rgba(212,175,55,0.16);

    transition: 0.3s;
}

.profile-button:hover {

    transform: translateY(-2px);

    box-shadow:
        0 12px 28px rgba(212,175,55,0.25);
}



.profile-box {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 20px;

    padding: 5px 0;
}

.profile-info h3 {

    color: #f8f4e9;

    font-size: 17px;

    margin-bottom: 6px;
}

.profile-info p {

    color: #8995a6;

    font-size: 13px;

    margin-bottom: 4px;
}

.profile-info strong {
    color: #d8ba62;
}




.footer {

    text-align: center;

    padding: 30px 20px;

    color: #697689;

    font-size: 12px;

    border-top:
        1px solid rgba(255,255,255,0.05);
}




@media (max-width: 1000px) {

    .stats {

        grid-template-columns:
            repeat(2, 1fr);
    }

    .actions {

        grid-template-columns:
            1fr;
    }

}

@media (max-width: 700px) {

    .topbar {

        padding: 15px 20px;

        align-items: flex-start;

        flex-direction: column;
    }

    nav {

        width: 100%;
    }

    nav a {

        padding: 8px 10px;

        font-size: 12px;
    }

    .container {

        width: 94%;

        padding-top: 25px;
    }

    .welcome {

        padding: 30px 23px;
    }

    .welcome h1 {

        font-size: 27px;
    }

    .stats {

        grid-template-columns: 1fr;
    }

    .section {

        padding: 22px 18px;
    }

    .application {

        flex-direction: column;

        align-items: flex-start;
    }

    .profile-box {

        flex-direction: column;

        align-items: flex-start;
    }

}

</style>

</head>

<body>



<header class="topbar">

    <div class="logo">

        <div class="logo-mark">
            IC
        </div>

        <div>
            <span>Intern</span>Connect
        </div>

    </div>


    <nav>

        <a href="dashboard.php" class="active">
            Dashboard
        </a>

        <a href="internships.php">
            Internships
        </a>

        <a href="my-applications.php">
            My Applications
        </a>

        <a href="profile.php">
            Profile
        </a>

        <a href="../logout.php" class="logout">
            Logout
        </a>

    </nav>

</header>



<div class="container">


    

    <section class="welcome">

        <div class="welcome-content">

            <div class="welcome-label">
                Student Portal
            </div>

            <h1>
                Welcome back,
                <span><?php echo htmlspecialchars($userName); ?></span> 👋
            </h1>

            <p>
                Discover meaningful internship opportunities, track your applications
                and build your professional journey with InternConnect.
            </p>

        </div>

    </section>


    
    <div class="stats">


        <div class="stat-card">

            <div class="stat-icon">
                💼
            </div>

            <div class="stat-title">
                Available Internships
            </div>

            <div class="stat-number">
                12
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-icon">
                📄
            </div>

            <div class="stat-title">
                My Applications
            </div>

            <div class="stat-number">
                <?php echo $totalApplications; ?>
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-icon">
                ✓
            </div>

            <div class="stat-title">
                Approved
            </div>

            <div class="stat-number">
                <?php echo $approvedApplications; ?>
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-icon">
                ◈
            </div>

            <div class="stat-title">
                Profile Status
            </div>

            <div class="stat-number">
                <?php echo $profileStatus; ?>%
            </div>

        </div>


    </div>


   <section class="section">

        <div class="section-title">
            Quick Actions
        </div>


        <div class="actions">


            <a href="internships.php" class="action-card">

                <div class="action-icon">
                    💼
                </div>

                <h3>
                    Browse Internships
                </h3>

                <p>
                    Explore curated internship opportunities and discover
                    roles that match your skills.
                </p>

            </a>


            <a href="my-applications.php" class="action-card">

                <div class="action-icon">
                    📋
                </div>

                <h3>
                    My Applications
                </h3>

                <p>
                    Track your submitted applications and monitor
                    every application status.
                </p>

            </a>


            <a href="profile.php" class="action-card">

                <div class="action-icon">
                    👤
                </div>

                <h3>
                    My Profile
                </h3>

                <p>
                    Keep your personal information, college details
                    and skills up to date.
                </p>

            </a>


        </div>

    </section>


    

    <section class="section">

        <div class="section-title">
            Recent Applications
        </div>


        <?php if (!empty($applications)): ?>


            <?php foreach (array_reverse($applications) as $application): ?>


                <?php

                $status = $application["status"] ?? "Pending";

                if ($status === "Approved") {

                    $statusClass = "approved";

                } elseif ($status === "Rejected") {

                    $statusClass = "rejected";

                } else {

                    $statusClass = "pending";

                }

                ?>


                <div class="application">


                    <div>

                        <h3>

                            <?php

                            echo htmlspecialchars(
                                $application["internship"] ?? "Internship"
                            );

                            ?>

                        </h3>


                        <p>

                            <?php

                            echo htmlspecialchars(
                                $application["company"] ?? ""
                            );

                            ?>

                            &nbsp; • &nbsp;

                            <?php

                            echo htmlspecialchars(
                                $application["location"] ?? ""
                            );

                            ?>

                        </p>

                    </div>


                    <div class="status <?php echo $statusClass; ?>">

                        <?php

                        echo htmlspecialchars($status);

                        ?>

                    </div>


                </div>


            <?php endforeach; ?>


        <?php else: ?>


            <div class="empty">

                No applications submitted yet.

                <br><br>

                <a href="internships.php" class="profile-button">
                    Browse Internships
                </a>

            </div>


        <?php endif; ?>


    </section>


      <section class="section">

        <div class="section-title">
            Profile
        </div>


        <div class="profile-box">


            <div class="profile-info">

                <h3>
                    <?php echo htmlspecialchars($userName); ?>
                </h3>

                <p>
                    <?php echo htmlspecialchars($userEmail); ?>
                </p>

                <p>
                    Profile completion:
                    <strong>
                        <?php echo $profileStatus; ?>%
                    </strong>
                </p>

            </div>


            <a href="profile.php" class="profile-button">
                Edit Profile
            </a>


        </div>

    </section>


</div>




<footer class="footer">

    © 2026 InternConnect · Student Career Portal

</footer>


</body>

</html>