<?php
session_start();

$message = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Get form values
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirmPassword = $_POST["confirm_password"] ?? "";
    $phone = trim($_POST["phone"] ?? "");
    $role = trim($_POST["role"] ?? "");
    $college = trim($_POST["college"] ?? "");


    // =========================
    // NAME VALIDATION
    // =========================

    if ($name === "") {

        $message = "Name is required!";

    }
    elseif (strlen($name) < 3) {

        $message = "Name must contain at least 3 characters!";

    }


    // =========================
    // EMAIL VALIDATION
    // =========================

    elseif ($email === "") {

        $message = "Email is required!";

    }
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $message = "Email not valid!";

    }


    // =========================
    // PASSWORD VALIDATION
    // =========================

    elseif ($password === "") {

        $message = "Password is required!";

    }
    elseif (strlen($password) < 6) {

        $message = "Password must contain at least 6 characters!";

    }


    // =========================
    // CONFIRM PASSWORD
    // =========================

    elseif ($confirmPassword === "") {

        $message = "Confirm password is required!";

    }
    elseif ($password !== $confirmPassword) {

        $message = "Password does not match!";

    }


    // =========================
    // PHONE VALIDATION
    // =========================

    elseif ($phone === "") {

        $message = "Phone number is required!";

    }
    elseif (!preg_match("/^[0-9]{10}$/", $phone)) {

        $message = "Phone number must contain 10 digits!";

    }


    // =========================
    // ROLE VALIDATION
    // =========================

    elseif ($role === "") {

        $message = "Register role is required!";

    }
    elseif (
        strtolower($role) !== "student" &&
        strtolower($role) !== "company" &&
        strtolower($role) !== "admin"
    ) {

        $message = "Register as Student, Company or Admin!";

    }


    // =========================
    // COLLEGE VALIDATION
    // =========================

    elseif ($college !== "" && strlen($college) < 3) {

        $message = "College name is too short!";

    }


    // =========================
    // NESTED IF
    // =========================

    else {

        if (
            isset($_SESSION["registered_email"]) &&
            $email === $_SESSION["registered_email"]
        ) {

            $message = "Email already registered!";

        }
        else {

            // Store registration details in session

            $_SESSION["registered_name"] = $name;
            $_SESSION["registered_email"] = $email;
            $_SESSION["registered_password"] = $password;
            $_SESSION["registered_phone"] = $phone;
            $_SESSION["registered_role"] = $role;
            $_SESSION["registered_college"] = $college;

            $success = "Registration successful!";

            header("Location: login.php");
            exit();
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>InternConnect - Create Account</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    min-height: 100vh;

    font-family: Arial, Helvetica, sans-serif;

    background:
        radial-gradient(
            circle at 10% 20%,
            rgba(212,175,112,0.12),
            transparent 28%
        ),
        radial-gradient(
            circle at 90% 80%,
            rgba(212,175,112,0.08),
            transparent 30%
        ),
        linear-gradient(
            135deg,
            #070D18,
            #0B1220 55%,
            #111827
        );

    color: #F8FAFC;

    display: flex;
    align-items: center;
    justify-content: center;

    padding: 30px;

    position: relative;
    overflow: hidden;
}

body::before {
    content: "";

    position: absolute;

    width: 300px;
    height: 300px;

    border: 1px solid rgba(212,175,112,0.16);

    border-radius: 50%;

    top: -120px;
    left: -100px;
}

body::after {
    content: "";

    position: absolute;

    width: 380px;
    height: 380px;

    border: 1px solid rgba(212,175,112,0.10);

    border-radius: 50%;

    bottom: -190px;
    right: -130px;
}

.container {

    width: 100%;
    max-width: 1000px;

    min-height: 620px;

    display: grid;

    grid-template-columns: 42% 58%;

    background: rgba(15,23,42,0.84);

    border: 1px solid rgba(212,175,112,0.18);

    border-radius: 28px;

    overflow: hidden;

    box-shadow:
        0 30px 80px rgba(0,0,0,0.45),
        0 0 50px rgba(212,175,112,0.05);

    backdrop-filter: blur(18px);

    position: relative;

    z-index: 2;
}

.left {

    padding: 55px 45px;

    background:
        linear-gradient(
            145deg,
            rgba(212,175,112,0.13),
            rgba(11,18,32,0.35)
        );

    border-right: 1px solid rgba(255,255,255,0.07);

    display: flex;

    flex-direction: column;

    justify-content: center;
}

.logo {

    display: flex;

    align-items: center;

    gap: 12px;

    margin-bottom: 55px;
}

.logo-mark {

    width: 48px;
    height: 48px;

    border-radius: 14px;

    background:
        linear-gradient(
            135deg,
            #D4AF70,
            #B88A3B
        );

    color: #0B1220;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 18px;

    font-weight: 900;

    box-shadow:
        0 8px 25px rgba(212,175,112,0.20);
}

.logo-text {

    font-size: 23px;

    font-weight: 800;

    color: #F8FAFC;
}

.logo-text span {

    color: #D4AF70;
}

.left h1 {

    font-size: 40px;

    line-height: 1.12;

    color: #F8FAFC;

    margin-bottom: 20px;
}

.left h1 span {

    color: #D4AF70;
}

.left-description {

    color: #AAB4C3;

    font-size: 15px;

    line-height: 1.75;

    margin-bottom: 35px;
}

.features {

    display: flex;

    flex-direction: column;

    gap: 16px;
}

.feature {

    display: flex;

    align-items: center;

    gap: 13px;

    color: #D8DEE8;

    font-size: 14px;
}

.feature-icon {

    width: 35px;
    height: 35px;

    border-radius: 10px;

    display: flex;

    align-items: center;

    justify-content: center;

    background: rgba(212,175,112,0.12);

    border: 1px solid rgba(212,175,112,0.22);

    color: #D4AF70;

    font-weight: bold;
}

.right {

    padding: 48px 55px;

    background: rgba(9,15,27,0.65);

    display: flex;

    flex-direction: column;

    justify-content: center;
}

.right h2 {

    color: #F8FAFC;

    font-size: 30px;

    margin-bottom: 8px;
}

.subtitle {

    color: #8F9AAA;

    font-size: 14px;

    margin-bottom: 25px;
}

.error {

    background: rgba(185,28,28,0.14);

    border: 1px solid rgba(248,113,113,0.25);

    color: #FCA5A5;

    padding: 12px 14px;

    border-radius: 12px;

    text-align: center;

    margin-bottom: 20px;

    font-size: 14px;
}

.form-group {

    margin-bottom: 17px;
}

label {

    display: block;

    margin-bottom: 8px;

    color: #DDE3EC;

    font-size: 14px;

    font-weight: 600;
}

.input-box {

    position: relative;
}

.input-icon {

    position: absolute;

    left: 15px;

    top: 50%;

    transform: translateY(-50%);

    color: #8B97A8;

    font-size: 15px;
}

input {

    width: 100%;

    padding: 13px 15px 13px 43px;

    border-radius: 12px;

    border: 1px solid rgba(148,163,184,0.18);

    background: rgba(255,255,255,0.045);

    color: #F8FAFC;

    font-size: 14px;

    outline: none;

    transition: 0.25s;
}

input::placeholder {

    color: #687588;
}

input:focus {

    border-color: #D4AF70;

    background: rgba(255,255,255,0.07);

    box-shadow:
        0 0 0 3px rgba(212,175,112,0.08);
}

button {

    width: 100%;

    padding: 15px;

    margin-top: 8px;

    border: none;

    border-radius: 12px;

    background:
        linear-gradient(
            135deg,
            #D4AF70,
            #B98A42
        );

    color: #0B1220;

    font-size: 15px;

    font-weight: 800;

    cursor: pointer;

    transition: 0.25s;

    box-shadow:
        0 10px 25px rgba(212,175,112,0.16);
}

button:hover {

    transform: translateY(-2px);

    box-shadow:
        0 14px 30px rgba(212,175,112,0.25);
}

.login-link {

    text-align: center;

    margin-top: 23px;

    color: #8793A5;

    font-size: 14px;
}

.login-link a {

    color: #D4AF70;

    text-decoration: none;

    font-weight: 700;
}

.login-link a:hover {

    text-decoration: underline;
}

.home-link {

    text-align: center;

    margin-top: 15px;
}

.home-link a {

    color: #7F8A9B;

    text-decoration: none;

    font-size: 13px;

    transition: 0.2s;
}

.home-link a:hover {

    color: #D4AF70;
}

.security-note {

    margin-top: 22px;

    padding-top: 16px;

    border-top: 1px solid rgba(255,255,255,0.07);

    text-align: center;

    color: #667386;

    font-size: 11px;
}

@media (max-width: 800px) {

    body {

        padding: 18px;
    }

    .container {

        grid-template-columns: 1fr;

        max-width: 520px;

        min-height: auto;
    }

    .left {

        padding: 38px 30px;

        border-right: none;

        border-bottom: 1px solid rgba(255,255,255,0.07);
    }

    .logo {

        margin-bottom: 35px;
    }

    .left h1 {

        font-size: 32px;
    }

    .right {

        padding: 38px 30px;
    }
}

@media (max-width: 420px) {

    body {

        padding: 10px;
    }

    .left,
    .right {

        padding: 28px 22px;
    }

    .left h1 {

        font-size: 28px;
    }

    .right h2 {

        font-size: 26px;
    }
}

</style>

</head>

<body>

<div class="container">

    <div class="left">

        <div class="logo">

            <div class="logo-mark">
                IC
            </div>

            <div class="logo-text">
                Intern<span>Connect</span>
            </div>

        </div>

        <h1>
            Build your
            <span>future.</span>
        </h1>

        <p class="left-description">

            Create your InternConnect account and discover
            meaningful internship opportunities that help
            you grow your skills and career.

        </p>

        <div class="features">

            <div class="feature">

                <div class="feature-icon">
                    ✓
                </div>

                <span>
                    Discover internship opportunities
                </span>

            </div>

            <div class="feature">

                <div class="feature-icon">
                    ✓
                </div>

                <span>
                    Apply for opportunities easily
                </span>

            </div>

            <div class="feature">

                <div class="feature-icon">
                    ✓
                </div>

                <span>
                    Track your applications
                </span>

            </div>

            <div class="feature">

                <div class="feature-icon">
                    ✓
                </div>

                <span>
                    Start building your career
                </span>

            </div>

        </div>

    </div>

    <div class="right">

        <h2>
            Create Account
        </h2>

        <p class="subtitle">
            Join InternConnect and start your journey
        </p>

        <?php if ($message != ""): ?>

            <div class="error">

                <?php echo htmlspecialchars($message); ?>

            </div>

        <?php endif; ?>

        <form method="POST" action="">

            <div class="form-group">

                <label>
                    Full Name
                </label>

                <div class="input-box">

                    <span class="input-icon">
                        👤
                    </span>

                    <input
                        type="text"
                        name="name"
                        placeholder="Enter your full name"
                        required
                    >

                </div>

            </div>

            <div class="form-group">

                <label>
                    Email Address
                </label>

                <div class="input-box">

                    <span class="input-icon">
                        ✉
                    </span>

                    <input
                        type="email"
                        name="email"
                        placeholder="Enter your email"
                        required
                    >

                </div>

            </div>

            <div class="form-group">

                <label>
                    Password
                </label>

                <div class="input-box">

                    <span class="input-icon">
                        🔒
                    </span>

                    <input
                        type="password"
                        name="password"
                        placeholder="Create a password"
                        required
                    >

                </div>

            </div>

            <div class="form-group">

                <label>
                    Confirm Password
                </label>

                <div class="input-box">

                    <span class="input-icon">
                        ✓
                    </span>

                    <input
                        type="password"
                        name="confirm_password"
                        placeholder="Confirm your password"
                        required
                    >

                </div>

            </div>

            <div class="form-group">

                <label>
                    Phone number
                </label>

                <div class="input-box">

                    <span class="input-icon">
                        📱
                    </span>

                    <input
                        type="tel"
                        name="phone"
                        placeholder="Enter Phone number"
                        required
                    >

                </div>

            </div>

            <div class="form-group">

                <label>
                    Register As
                </label>

                <div class="input-box">

                    <span class="input-icon">
                        👤
                    </span>

                    <input
                        type="text"
                        name="role"
                        placeholder="Student / Company / Admin"
                        required
                    >

                </div>

            </div>

            <button type="submit">
                Create My Account →
            </button>

        </form>

        <div class="login-link">

            Already have an account?

            <a href="login.php">
                Login
            </a>

        </div>

        <div class="home-link">

            <a href="index.php">
                ← Back to Home
            </a>

        </div>

        <div class="security-note">

            🔐 Your account information is securely handled.

        </div>

    </div>

</div>

</body>

</html>