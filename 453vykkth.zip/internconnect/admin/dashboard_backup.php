<?php

require_once "auth.php";

$applications = $_SESSION["applications"] ?? [];

$totalStudents = 1;
$activeInternships = 12;
$totalApplications = count($applications);

$pendingApplications = 0;
$approvedApplications = 0;
$rejectedApplications = 0;

foreach ($applications as $application) {

    $status = $application["status"] ?? "Pending";

    if ($status === "Pending") {
        $pendingApplications++;
    }

    if ($status === "Approved") {
        $approvedApplications++;
    }

    if ($status === "Rejected") {
        $rejectedApplications++;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Admin Dashboard - InternConnect</title>

<style>

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f5f7fb;
    color: #1f2937;
}

.topbar {
    background: white;
    padding: 20px 6%;
    display: flex;
    justify-content: space-between;
    box-shadow: 0 2px 10px rgba(0,0,0,0.08);
}

.logo {
    font-size: 25px;
    font-weight: bold;
}

.logo span {
    color: #3157d5;
}

.container {
    width: 92%;
    max-width: 1200px;
    margin: 35px auto;
}

.nav {
    background: white;
    padding: 18px;
    border-radius: 12px;
    margin-bottom: 25px;
}

.nav a {
    text-decoration: none;
    color: #374151;
    margin-right: 20px;
    font-weight: bold;
}

.logout {
    color: red !important;
}

h1 {
    margin-bottom: 8px;
}

.subtitle {
    color: #6b7280;
    margin-bottom: 25px;
}

.stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 18px;
}

.card {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 5px 18px rgba(0,0,0,0.06);
}

.card h2 {
    font-size: 30px;
    margin: 10px 0;
}

.card p {
    color: #6b7280;
}

.section {
    background: white;
    padding: 25px;
    border-radius: 15px;
    margin-top: 25px;
}

.actions {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

.action {
    text-decoration: none;
    color: #111827;
    background: #f8fafc;
    padding: 20px;
    border-radius: 10px;
    border: 1px solid #e5e7eb;
}

.action:hover {
    border-color: #3157d5;
}

.application {
    padding: 15px;
    border: 1px solid #e5e7eb;
    border-radius: 10px;
    margin-bottom: 12px;
    display: flex;
    justify-content: space-between;
}

.status {
    padding: 7px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.pending {
    background: #fff7ed;
    color: #c2410c;
}

.approved {
    background: #dcfce7;
    color: #15803d;
}

.rejected {
    background: #fee2e2;
    color: #b91c1c;
}

@media(max-width: 700px) {

    .stats,
    .actions {
        grid-template-columns: 1fr;
    }

    .application {
        flex-direction: column;
        gap: 10px;
    }

}

</style>

</head>

<body>

<header class="topbar">

    <div class="logo">
        <span>Intern</span>Connect
    </div>

    <div>
        Admin Panel
    </div>

</header>

<div class="container">

    <div class="nav">

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="students.php">
            Students
        </a>

        <a href="internships.php">
            Internships
        </a>

        <a href="applications.php">
            Applications
        </a>

        <a href="../logout.php" class="logout">
            Logout
        </a>

    </div>


    <h1>
        Admin Dashboard
    </h1>

    <p class="subtitle">
        Manage InternConnect platform.
    </p>


    <div class="stats">

        <div class="card">

            <p>Total Students</p>

            <h2>
                <?php echo $totalStudents; ?>
            </h2>

        </div>


        <div class="card">

            <p>Active Internships</p>

            <h2>
                <?php echo $activeInternships; ?>
            </h2>

        </div>


        <div class="card">

            <p>Total Applications</p>

            <h2>
                <?php echo $totalApplications; ?>
            </h2>

        </div>


        <div class="card">

            <p>Pending Applications</p>

            <h2>
                <?php echo $pendingApplications; ?>
            </h2>

        </div>


        <div class="card">

            <p>Approved Applications</p>

            <h2>
                <?php echo $approvedApplications; ?>
            </h2>

        </div>


        <div class="card">

            <p>Rejected Applications</p>

            <h2>
                <?php echo $rejectedApplications; ?>
            </h2>

        </div>

    </div>


    <div class="section">

        <h2>
            Quick Actions
        </h2>

        <div class="actions">

            <a href="students.php" class="action">
                👨‍🎓 Manage Students
            </a>

            <a href="internships.php" class="action">
                💼 Manage Internships
            </a>

            <a href="applications.php" class="action">
                📋 Manage Applications
            </a>

        </div>

    </div>


    <div class="section">

        <h2>
            Recent Applications
        </h2>


        <?php if (empty($applications)): ?>

            <p>
                No applications submitted yet.
            </p>

        <?php else: ?>

            <?php foreach (array_reverse($applications) as $application): ?>

                <?php

                $status =
                    $application["status"] ?? "Pending";

                $class = "pending";

                if ($status === "Approved") {
                    $class = "approved";
                }

                if ($status === "Rejected") {
                    $class = "rejected";
                }

                ?>

                <div class="application">

                    <div>

                        <strong>

                            <?php

                            echo htmlspecialchars(
                                $application["student_name"]
                                ?? "Student"
                            );

                            ?>

                        </strong>

                        <br>

                        <small>

                            <?php

                            echo htmlspecialchars(
                                $application["internship"]
                                ?? "Internship"
                            );

                            ?>

                        </small>

                    </div>

                    <span class="status <?php echo $class; ?>">

                        <?php echo htmlspecialchars($status); ?>

                    </span>

                </div>

            <?php endforeach; ?>

        <?php endif; ?>

    </div>

</div>

</body>

</html>