<?php

require_once "auth.php";

$internships = [
    [
        "id" => 1,
        "title" => "Web Development Intern",
        "company" => "TechNova Solutions",
        "location" => "Chennai",
        "skills" => "HTML, CSS, JavaScript, PHP",
        "stipend" => "₹10,000/month",
        "duration" => "3 Months",
        "status" => "Active"
    ],
    [
        "id" => 2,
        "title" => "Python Developer Intern",
        "company" => "CodeCraft Technologies",
        "location" => "Bangalore",
        "skills" => "Python, SQL, Git",
        "stipend" => "₹12,000/month",
        "duration" => "3 Months",
        "status" => "Active"
    ],
    [
        "id" => 3,
        "title" => "Data Science Intern",
        "company" => "DataVision Labs",
        "location" => "Remote",
        "skills" => "Python, Pandas, Machine Learning",
        "stipend" => "₹15,000/month",
        "duration" => "4 Months",
        "status" => "Active"
    ],
    [
        "id" => 4,
        "title" => "PHP Developer Intern",
        "company" => "WebCore Technologies",
        "location" => "Chennai",
        "skills" => "PHP, MySQL, HTML, CSS",
        "stipend" => "₹11,000/month",
        "duration" => "3 Months",
        "status" => "Active"
    ],
    [
        "id" => 5,
        "title" => "Java Developer Intern",
        "company" => "InnovateSoft",
        "location" => "Hyderabad",
        "skills" => "Java, Spring Boot, SQL",
        "stipend" => "₹14,000/month",
        "duration" => "4 Months",
        "status" => "Active"
    ],
    [
        "id" => 6,
        "title" => "AI & Machine Learning Intern",
        "company" => "FutureMind AI",
        "location" => "Remote",
        "skills" => "Python, AI, Machine Learning",
        "stipend" => "₹18,000/month",
        "duration" => "6 Months",
        "status" => "Active"
    ],
    [
        "id" => 7,
        "title" => "Frontend Developer Intern",
        "company" => "PixelWorks Studio",
        "location" => "Chennai",
        "skills" => "HTML, CSS, JavaScript, React",
        "stipend" => "₹12,000/month",
        "duration" => "3 Months",
        "status" => "Active"
    ],
    [
        "id" => 8,
        "title" => "Backend Developer Intern",
        "company" => "ServerStack Technologies",
        "location" => "Bangalore",
        "skills" => "PHP, Node.js, MySQL",
        "stipend" => "₹13,000/month",
        "duration" => "4 Months",
        "status" => "Active"
    ],
    [
        "id" => 9,
        "title" => "Cyber Security Intern",
        "company" => "SecureNet Labs",
        "location" => "Hyderabad",
        "skills" => "Cyber Security, Networking, Linux",
        "stipend" => "₹16,000/month",
        "duration" => "4 Months",
        "status" => "Active"
    ],
    [
        "id" => 10,
        "title" => "Cloud Computing Intern",
        "company" => "CloudNova Technologies",
        "location" => "Remote",
        "skills" => "AWS, Cloud, Linux",
        "stipend" => "₹15,000/month",
        "duration" => "3 Months",
        "status" => "Active"
    ],
    [
        "id" => 11,
        "title" => "UI/UX Design Intern",
        "company" => "CreativePixel",
        "location" => "Chennai",
        "skills" => "Figma, UI Design, UX Research",
        "stipend" => "₹9,000/month",
        "duration" => "3 Months",
        "status" => "Active"
    ],
    [
        "id" => 12,
        "title" => "Mobile App Development Intern",
        "company" => "AppWorks Technologies",
        "location" => "Coimbatore",
        "skills" => "Flutter, Dart, Firebase",
        "stipend" => "₹13,000/month",
        "duration" => "4 Months",
        "status" => "Active"
    ]
];

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Internships | InternConnect Admin</title>

<style>


* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

:root {

    --navy: #0b1220;
    --navy2: #101a2c;
    --card: #151f32;

    --gold: #d4af70;
    --gold-light: #e6c88d;

    --cream: #f5f0e6;

    --muted: #98a5b8;

    --border:
        rgba(212,175,112,0.18);

    --green: #55d68a;
}

html {
    scroll-behavior: smooth;
}

body {

    font-family:
        "Segoe UI",
        Arial,
        sans-serif;

    background:
        radial-gradient(
            circle at top right,
            rgba(212,175,112,0.08),
            transparent 32%
        ),
        var(--navy);

    color: var(--cream);

    min-height: 100vh;
}

.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 255px;

    height: 100vh;

    padding: 27px 17px;

    background:
        linear-gradient(
            180deg,
            #0d1627,
            #09111f
        );

    border-right:
        1px solid var(--border);

    box-shadow:
        15px 0 45px
        rgba(0,0,0,0.18);

    z-index: 100;
}


.logo {

    display: flex;

    align-items: center;

    gap: 11px;

    color: var(--cream);

    font-size: 20px;

    font-weight: 700;

    padding:
        0 10px 30px;
}

.logo-mark {

    width: 43px;

    height: 43px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 12px;

    background:
        linear-gradient(
            135deg,
            var(--gold),
            #a77e3d
        );

    color: var(--navy);

    font-weight: 900;

    font-size: 15px;

    box-shadow:
        0 8px 25px
        rgba(212,175,112,0.18);
}

.logo span {
    color: var(--gold);
}



.admin-label {

    color: #66758b;

    font-size: 10px;

    letter-spacing: 1.8px;

    text-transform: uppercase;

    font-weight: 700;

    padding: 0 12px;

    margin-bottom: 12px;
}




.sidebar a {

    display: flex;

    align-items: center;

    gap: 11px;

    color: #9ba8ba;

    text-decoration: none;

    padding: 13px 14px;

    margin-bottom: 6px;

    border-radius: 11px;

    font-size: 13px;

    font-weight: 600;

    transition: 0.25s ease;

    border:
        1px solid transparent;
}

.sidebar a:hover {

    color: var(--cream);

    background:
        rgba(212,175,112,0.07);

    border-color:
        rgba(212,175,112,0.08);
}

.sidebar a.active {

    color: var(--gold);

    background:
        linear-gradient(
            90deg,
            rgba(212,175,112,0.13),
            rgba(212,175,112,0.04)
        );

    border-color:
        rgba(212,175,112,0.18);

    box-shadow:
        inset 3px 0 0
        var(--gold);
}




.main {

    margin-left: 255px;

    padding: 42px 42px 70px;

    min-height: 100vh;
}




.topbar {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 20px;

    margin-bottom: 32px;
}

.eyebrow {

    color: var(--gold);

    font-size: 10px;

    text-transform: uppercase;

    letter-spacing: 2px;

    font-weight: 700;

    margin-bottom: 9px;
}

.topbar h1 {

    font-family: Georgia, serif;

    font-size: 36px;

    font-weight: 500;

    margin-bottom: 7px;

    letter-spacing: -0.5px;
}

.topbar p {

    color: var(--muted);

    font-size: 13px;
}


.admin-profile {

    display: flex;

    align-items: center;

    gap: 10px;

    padding: 11px 16px;

    border-radius: 12px;

    background:
        rgba(21,31,50,0.9);

    border:
        1px solid var(--border);

    color: #dfe4ec;

    font-size: 12px;

    font-weight: 600;
}




.search-box {

    padding: 17px;

    margin-bottom: 26px;

    background:
        rgba(21,31,50,0.85);

    border:
        1px solid var(--border);

    border-radius: 16px;

    box-shadow:
        0 15px 40px
        rgba(0,0,0,0.14);
}

.search-box input {

    width: 100%;

    padding: 15px 17px;

    border:
        1px solid
        rgba(212,175,112,0.16);

    border-radius: 11px;

    outline: none;

    background:
        #0d1728;

    color: var(--cream);

    font-size: 13px;

    transition: 0.25s ease;
}

.search-box input::placeholder {

    color: #68778c;
}

.search-box input:focus {

    border-color: var(--gold);

    box-shadow:
        0 0 0 3px
        rgba(212,175,112,0.07);
}



.internship-grid {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 18px;
}



.internship-card {

    position: relative;

    overflow: hidden;

    padding: 23px;

    background:
        linear-gradient(
            145deg,
            rgba(21,31,50,0.98),
            rgba(13,23,40,0.98)
        );

    border:
        1px solid var(--border);

    border-radius: 18px;

    box-shadow:
        0 18px 50px
        rgba(0,0,0,0.18);

    transition:
        transform 0.3s ease,
        border-color 0.3s ease,
        box-shadow 0.3s ease;
}

.internship-card::before {

    content: "";

    position: absolute;

    top: 0;
    left: 0;

    width: 100%;

    height: 2px;

    background:
        linear-gradient(
            90deg,
            transparent,
            var(--gold),
            transparent
        );

    opacity: 0.55;
}

.internship-card:hover {

    transform:
        translateY(-5px);

    border-color:
        rgba(212,175,112,0.34);

    box-shadow:
        0 25px 60px
        rgba(0,0,0,0.28);
}




.card-top {

    display: flex;

    justify-content: space-between;

    align-items: flex-start;

    gap: 15px;

    margin-bottom: 20px;
}

.card-number {

    width: 35px;

    height: 35px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 10px;

    background:
        rgba(212,175,112,0.09);

    border:
        1px solid
        rgba(212,175,112,0.15);

    color: var(--gold);

    font-size: 11px;

    font-weight: 800;

    margin-bottom: 12px;
}

.internship-card h2 {

    color: var(--cream);

    font-family: Georgia, serif;

    font-size: 19px;

    line-height: 1.25;

    font-weight: 500;

    margin-bottom: 7px;
}

.company {

    color: var(--muted);

    font-size: 12px;

    line-height: 1.5;
}




.status {

    color: var(--green);

    background:
        rgba(85,214,138,0.08);

    border:
        1px solid
        rgba(85,214,138,0.20);

    padding: 6px 10px;

    border-radius: 30px;

    font-size: 9px;

    font-weight: 800;

    letter-spacing: 0.8px;

    text-transform: uppercase;

    white-space: nowrap;
}



.details {

    display: grid;

    grid-template-columns:
        1fr 1fr;

    gap: 10px;
}

.detail {

    min-height: 72px;

    padding: 13px;

    border-radius: 11px;

    background:
        rgba(255,255,255,0.025);

    border:
        1px solid
        rgba(255,255,255,0.05);

    transition: 0.2s ease;
}

.detail:hover {

    border-color:
        rgba(212,175,112,0.16);
}

.detail small {

    display: block;

    color: #738196;

    font-size: 9px;

    text-transform: uppercase;

    letter-spacing: 1px;

    margin-bottom: 7px;
}

.detail strong {

    color: #e3e7ee;

    font-size: 12px;

    line-height: 1.5;

    font-weight: 600;
}

.skills {

    grid-column:
        1 / -1;
}




.no-results {

    display: none;

    grid-column:
        1 / -1;

    text-align: center;

    padding: 60px 20px;

    border:
        1px solid var(--border);

    border-radius: 18px;

    background:
        rgba(21,31,50,0.8);

    color: var(--muted);
}

.no-results h2 {

    font-family: Georgia, serif;

    color: var(--cream);

    font-weight: 500;

    margin-bottom: 8px;
}




@media (max-width: 1150px) {

    .internship-grid {

        grid-template-columns:
            repeat(2, 1fr);
    }
}


@media (max-width: 850px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;

        padding: 20px;

        border-right: none;

        border-bottom:
            1px solid var(--border);
    }

    .logo {

        padding-bottom: 20px;
    }

    .sidebar a {

        display: inline-flex;

        margin-right: 5px;

        margin-bottom: 5px;
    }

    .admin-label {

        margin-bottom: 8px;
    }

    .main {

        margin-left: 0;

        padding: 30px 20px 50px;
    }
}


@media (max-width: 650px) {

    .topbar {

        flex-direction: column;

        align-items: flex-start;
    }

    .admin-profile {

        width: 100%;

        justify-content: center;
    }

    .internship-grid {

        grid-template-columns:
            1fr;
    }
}


@media (max-width: 450px) {

    .main {

        padding:
            25px 15px 45px;
    }

    .topbar h1 {

        font-size: 30px;
    }

    .details {

        grid-template-columns:
            1fr;
    }

    .skills {

        grid-column:
            auto;
    }

    .card-top {

        flex-direction: column;
    }

    .status {

        align-self: flex-start;
    }
}




::-webkit-scrollbar {
    width: 7px;
}

::-webkit-scrollbar-track {
    background: var(--navy);
}

::-webkit-scrollbar-thumb {

    background:
        rgba(212,175,112,0.35);

    border-radius: 10px;
}

::-webkit-scrollbar-thumb:hover {

    background:
        rgba(212,175,112,0.60);
}

</style>

</head>


<body>




<div class="sidebar">


    <div class="logo">

        <div class="logo-mark">
            IC
        </div>

        <div>
            Intern<span>Connect</span>
        </div>

    </div>


    <div class="admin-label">
        Admin Panel
    </div>


    <a href="dashboard.php">
        📊 Dashboard
    </a>


    <a href="students.php">
        👩‍🎓 Students
    </a>


    <a href="internships.php"
       class="active">
        💼 Internships
    </a>


    <a href="applications.php">
        📄 Applications
    </a>


    <a href="../index.php">
        🏠 Main Website
    </a>


    <a href="../logout.php">
        🚪 Logout
    </a>

</div>




<div class="main">


    

    <div class="topbar">

        <div>

            <div class="eyebrow">
                Opportunity Management
            </div>

            <h1>
                Internships
            </h1>

            <p>
                Explore and manage available internship opportunities.
            </p>

        </div>


        <div class="admin-profile">

            👤

            <span>
                Administrator
            </span>

        </div>

    </div>



    

    <div class="search-box">

        <input
            type="text"
            id="internshipSearch"
            placeholder="🔍  Search internship, company, location or skill..."
            onkeyup="searchInternships()"
        >

    </div>



    

    <div
        class="internship-grid"
        id="internshipGrid"
    >


        <?php foreach ($internships as $internship): ?>


            <div class="internship-card">


                <div class="card-top">


                    <div>

                        <div class="card-number">

                            #<?php

                            echo htmlspecialchars(
                                $internship["id"]
                            );

                            ?>

                        </div>


                        <h2>

                            <?php

                            echo htmlspecialchars(
                                $internship["title"]
                            );

                            ?>

                        </h2>


                        <div class="company">

                            <?php

                            echo htmlspecialchars(
                                $internship["company"]
                            );

                            ?>

                        </div>

                    </div>


                    <span class="status">

                        <?php

                        echo htmlspecialchars(
                            $internship["status"]
                        );

                        ?>

                    </span>


                </div>



                <div class="details">


                    <div class="detail">

                        <small>
                            Location
                        </small>

                        <strong>

                            📍

                            <?php

                            echo htmlspecialchars(
                                $internship["location"]
                            );

                            ?>

                        </strong>

                    </div>


                    <div class="detail">

                        <small>
                            Stipend
                        </small>

                        <strong>

                            💰

                            <?php

                            echo htmlspecialchars(
                                $internship["stipend"]
                            );

                            ?>

                        </strong>

                    </div>


                    <div class="detail">

                        <small>
                            Duration
                        </small>

                        <strong>

                            ⏱

                            <?php

                            echo htmlspecialchars(
                                $internship["duration"]
                            );

                            ?>

                        </strong>

                    </div>


                    <div class="detail skills">

                        <small>
                            Required Skills
                        </small>

                        <strong>

                            <?php

                            echo htmlspecialchars(
                                $internship["skills"]
                            );

                            ?>

                        </strong>

                    </div>


                </div>


            </div>


        <?php endforeach; ?>


        <div class="no-results" id="noResults">

            <h2>
                No internships found
            </h2>

            <p>
                Try searching with another keyword.
            </p>

        </div>


    </div>

</div>



<script>

function searchInternships() {

    var input =
        document
        .getElementById("internshipSearch")
        .value
        .toLowerCase()
        .trim();


    var cards =
        document
        .getElementById("internshipGrid")
        .getElementsByClassName("internship-card");


    var visibleCount = 0;


    for (
        var i = 0;
        i < cards.length;
        i++
    ) {

        var text =
            cards[i]
            .innerText
            .toLowerCase();


        if (
            text.indexOf(input) !== -1
        ) {

            cards[i].style.display = "";

            visibleCount++;

        } else {

            cards[i].style.display =
                "none";

        }

    }


    var noResults =
        document.getElementById(
            "noResults"
        );


    if (
        visibleCount === 0
        && input !== ""
    ) {

        noResults.style.display =
            "block";

    } else {

        noResults.style.display =
            "none";

    }

}

</script>


</body>

</html>s