<?php
require_once "auth.php";

$students = [
    [
        "id" => 1,
        "name" => "Dhanishka S",
        "email" => "dhanishkamahalakshmi@gmail.com",
        "college" => "Mahendra College of Engineering",
        "course" => "B.E Computer Science and Engineering",
        "status" => "Active"
    ],
    [
        "id" => 2,
        "name" => "Abirami R",
        "email" => "abiramiravi1767@gmail.com",
        "college" => "Mahendra College of Engineering",
        "course" => "B.E Computer Science",
        "status" => "Active"
    ],
    [
        "id" => 3,
        "name" => "Dhanushrajan S",
        "email" => "dhanushrajans2005@gmail.com",
        "college" => "Mahendra College of Engineering",
        "course" => "B.E Computer Science",
        "status" => "Active"
    ],
    [
        "id" => 4,
        "name" => "Bharanidharan K",
        "email" => "bharanidharan0403@gmail.com",
        "college" => "Mahendra College of Engineering",
        "course" => "B.E Computer Science",
        "status" => "Active"
    ],
    [
        "id" => 5,
        "name" => "Dhanusha K",
        "email" => "dhanusha34576@gmail.com",
        "college" => "Mahendra College of Engineering",
        "course" => "B.E Computer Science",
        "status" => "Active"
    ],
    [
        
        "id" => 6,
        "name" => "Vishal T",
        "email" => "smart7vishal@gmail.com",
        "college" => "Mahendra College of Engineering",
        "course" => "B.E Computer Science",
        "status" => "Active"
    ]
];
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Students | InternConnect</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #080d17;
            color: #f7f3eb;
            min-height: 100vh;
        }

       
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 255px;
            height: 100vh;
            padding: 28px 18px;
            background:
                linear-gradient(
                    180deg,
                    #0b1220,
                    #080d17
                );
            border-right: 1px solid rgba(212,175,112,0.15);
            z-index: 100;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0 10px 30px;
        }

        .logo-mark {
            width: 43px;
            height: 43px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(
                135deg,
                #d4af70,
                #b88b45
            );
            color: #090e17;
            font-size: 15px;
            font-weight: 900;
        }

        .logo-text {
            font-size: 21px;
            font-weight: 800;
        }

        .logo-text span {
            color: #d4af70;
        }

        .admin-label {
            color: #6f7b8d;
            font-size: 10px;
            padding: 0 12px;
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 1.8px;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            gap: 11px;
            color: #929dad;
            text-decoration: none;
            padding: 13px 14px;
            margin-bottom: 6px;
            border-radius: 11px;
            font-size: 13px;
            transition: 0.25s ease;
        }

        .sidebar a:hover {
            color: #d4af70;
            background: rgba(212,175,112,0.06);
        }

        .sidebar a.active {
            color: #d4af70;
            background:
                linear-gradient(
                    90deg,
                    rgba(212,175,112,0.13),
                    rgba(212,175,112,0.03)
                );
            border: 1px solid rgba(212,175,112,0.13);
        }

        .sidebar .logout {
            margin-top: 18px;
            color: #e99b9b;
        }

        .sidebar .logout:hover {
            color: #fca5a5;
            background: rgba(220,38,38,0.08);
        }

        
        .main {
            margin-left: 255px;
            padding: 38px;
            min-height: 100vh;
        }

        

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
        }

        .eyebrow {
            color: #d4af70;
            text-transform: uppercase;
            letter-spacing: 2.5px;
            font-size: 10px;
            font-weight: bold;
            margin-bottom: 9px;
        }

        .topbar h1 {
            font-size: 31px;
            letter-spacing: -0.7px;
            margin-bottom: 7px;
        }

        .topbar p {
            color: #7f8a9b;
            font-size: 14px;
        }

        .admin-profile {
            display: flex;
            align-items: center;
            gap: 10px;
            background: #0f1726;
            border: 1px solid #202c40;
            padding: 11px 16px;
            border-radius: 12px;
            color: #c5ccd6;
            font-size: 13px;
        }

        .profile-dot {
            width: 9px;
            height: 9px;
            border-radius: 50%;
            background: #d4af70;
            box-shadow: 0 0 10px rgba(212,175,112,0.5);
        }

        
        .search-box {
            background: #0f1726;
            border: 1px solid #202c40;
            padding: 18px;
            border-radius: 17px;
            margin-bottom: 22px;
        }

        .search-wrapper {
            position: relative;
        }

        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #697587;
            font-size: 14px;
        }

        .search-box input {
            width: 100%;
            padding: 14px 16px 14px 42px;
            background: #0b1220;
            border: 1px solid #263246;
            border-radius: 11px;
            color: #f7f3eb;
            font-size: 14px;
            outline: none;
            transition: 0.25s ease;
        }

        .search-box input::placeholder {
            color: #697587;
        }

        .search-box input:focus {
            border-color: #d4af70;
            box-shadow:
                0 0 0 3px rgba(212,175,112,0.07);
        }
        .table-container {
            background: #0f1726;
            border: 1px solid #202c40;
            border-radius: 20px;
            padding: 10px;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            min-width: 900px;
        }

        th {
            text-align: left;
            background: #0b1220;
            padding: 16px 14px;
            color: #7f8a9b;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            border-bottom: 1px solid #202c40;
        }

        th:first-child {
            border-radius: 11px 0 0 11px;
        }

        th:last-child {
            border-radius: 0 11px 11px 0;
        }

        td {
            padding: 17px 14px;
            border-bottom: 1px solid #1b2637;
            font-size: 13px;
            color: #c3cad4;
            vertical-align: middle;
        }

        tr:last-child td {
            border-bottom: none;
        }

        tbody tr {
            transition: 0.2s ease;
        }

        tbody tr:hover {
            background: rgba(212,175,112,0.035);
        }

        .student-number {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            background: rgba(212,175,112,0.08);
            border: 1px solid rgba(212,175,112,0.15);
            color: #d4af70;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 12px;
        }

        .student-name {
            font-weight: 700;
            color: #f1ede5;
            margin-bottom: 4px;
        }

        .student-role {
            color: #667386;
            font-size: 11px;
        }

        .email {
            color: #8994a5;
            font-size: 12px;
        }

        .college {
            color: #b5bdc9;
            max-width: 190px;
            line-height: 1.5;
        }

        .course {
            color: #9da7b6;
            max-width: 200px;
            line-height: 1.5;
        }

        .status {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 7px 11px;
            border-radius: 20px;
            background: rgba(34,197,94,0.08);
            border: 1px solid rgba(34,197,94,0.16);
            color: #86efac;
            font-size: 11px;
            font-weight: bold;
        }

        .status-dot {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: #86efac;
        }

        

        @media (max-width: 850px) {

            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
                border-right: none;
                border-bottom: 1px solid rgba(212,175,112,0.15);
                padding: 20px;
            }

            .brand {
                padding-bottom: 20px;
            }

            .sidebar a {
                display: inline-flex;
                margin-right: 5px;
            }

            .admin-label {
                margin-bottom: 8px;
            }

            .main {
                margin-left: 0;
                padding: 25px 18px;
            }

            .topbar {
                flex-direction: column;
                align-items: flex-start;
            }

        }

        @media (max-width: 500px) {

            .main {
                padding: 22px 13px;
            }

            .topbar h1 {
                font-size: 26px;
            }

            .admin-profile {
                width: 100%;
            }

            .search-box {
                padding: 13px;
            }

        }

    </style>

</head>

<body>




<div class="sidebar">

    <div class="brand">

        <div class="logo-mark">
            IC
        </div>

        <div class="logo-text">
            Intern<span>Connect</span>
        </div>

    </div>


    <div class="admin-label">
        Admin Panel
    </div>


    <a href="dashboard.php">
        <span>📊</span>
        Dashboard
    </a>


    <a href="students.php" class="active">
        <span>👩‍🎓</span>
        Students
    </a>


    <a href="internships.php">
        <span>💼</span>
        Internships
    </a>


    <a href="applications.php">
        <span>📄</span>
        Applications
    </a>


    <a href="../index.php">
        <span>🏠</span>
        Main Website
    </a>


    <a href="../logout.php" class="logout">
        <span>🚪</span>
        Logout
    </a>

</div>




<div class="main">

    <div class="topbar">

        <div>

            <div class="eyebrow">
                Student Management
            </div>

            <h1>
                Students
            </h1>

            <p>
                View and manage registered students.
            </p>

        </div>


        <div class="admin-profile">

            <div class="profile-dot"></div>

            Administrator

        </div>

    </div>


    

    <div class="search-box">

        <div class="search-wrapper">

            <span class="search-icon">
                🔍
            </span>

            <input
                type="text"
                id="studentSearch"
                placeholder="Search by name, email or college..."
                onkeyup="searchStudents()"
            >

        </div>

    </div>


    

    <div class="table-container">

        <table>

            <thead>

                <tr>

                    <th>#</th>

                    <th>Student</th>

                    <th>Email</th>

                    <th>College</th>

                    <th>Course</th>

                    <th>Status</th>

                </tr>

            </thead>


            <tbody id="studentTable">


                <?php foreach ($students as $student): ?>


                    <tr>


                        <td>

                            <div class="student-number">

                                <?php
                                echo $student["id"];
                                ?>

                            </div>

                        </td>


                        <td>

                            <div class="student-name">

                                <?php
                                echo htmlspecialchars(
                                    $student["name"]
                                );
                                ?>

                            </div>

                            <div class="student-role">
                                Registered Student
                            </div>

                        </td>


                        <td>

                            <div class="email">

                                <?php
                                echo htmlspecialchars(
                                    $student["email"]
                                );
                                ?>

                            </div>

                        </td>


                        <td>

                            <div class="college">

                                <?php
                                echo htmlspecialchars(
                                    $student["college"]
                                );
                                ?>

                            </div>

                        </td>


                        <td>

                            <div class="course">

                                <?php
                                echo htmlspecialchars(
                                    $student["course"]
                                );
                                ?>

                            </div>

                        </td>


                        <td>

                            <span class="status">

                                <span class="status-dot"></span>

                                <?php
                                echo htmlspecialchars(
                                    $student["status"]
                                );
                                ?>

                            </span>

                        </td>


                    </tr>


                <?php endforeach; ?>


            </tbody>

        </table>

    </div>


</div>


<script>

function searchStudents() {

    var input = document
        .getElementById("studentSearch")
        .value
        .toLowerCase();

    var rows = document
        .getElementById("studentTable")
        .getElementsByTagName("tr");

    for (var i = 0; i < rows.length; i++) {

        var text = rows[i]
            .innerText
            .toLowerCase();

        if (text.indexOf(input) !== -1) {

            rows[i].style.display = "";

        } else {

            rows[i].style.display = "none";

        }

    }

}

</script>


</body>
</html>