<?php
session_start();

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");
    $password = trim($_POST["password"] ?? "");

    
    $adminEmail = "admin@internconnect.com";
    $adminPassword = "admin123";

    if ($email === $adminEmail && $password === $adminPassword) {

        $_SESSION["admin_logged_in"] = true;
        $_SESSION["admin_email"] = $email;

        header("Location: dashboard.php");
        exit();

    } else {

        $error = "Invalid admin email or password.";

    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Admin Login | InternConnect</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            min-height: 100vh;
            font-family: Arial, sans-serif;
            background:
                radial-gradient(circle at 15% 20%, rgba(212,175,112,0.10), transparent 30%),
                radial-gradient(circle at 85% 80%, rgba(212,175,112,0.08), transparent 30%),
                #080d17;
            color: #f7f3eb;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 25px;
        }

        .page {
            width: 100%;
            max-width: 1050px;
            min-height: 620px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            background: rgba(15, 23, 42, 0.88);
            border: 1px solid rgba(212,175,112,0.20);
            border-radius: 28px;
            overflow: hidden;
            box-shadow:
                0 30px 80px rgba(0,0,0,0.55),
                0 0 60px rgba(212,175,112,0.05);
        }

        

        .brand-section {
            position: relative;
            padding: 55px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            background:
                linear-gradient(
                    145deg,
                    rgba(212,175,112,0.10),
                    rgba(8,13,23,0.95)
                );
            border-right: 1px solid rgba(212,175,112,0.14);
        }

        .brand-section::before {
            content: "";
            position: absolute;
            width: 260px;
            height: 260px;
            border-radius: 50%;
            background: rgba(212,175,112,0.06);
            top: -100px;
            left: -100px;
        }

        .logo {
            position: relative;
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .logo-mark {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #d4af70, #b88b45);
            color: #0a0f18;
            font-size: 18px;
            font-weight: 900;
            box-shadow: 0 10px 25px rgba(212,175,112,0.18);
        }

        .logo-text {
            font-size: 24px;
            font-weight: 800;
            letter-spacing: -0.5px;
        }

        .logo-text span {
            color: #d4af70;
        }

        .brand-content {
            position: relative;
            margin-top: 30px;
        }

        .eyebrow {
            color: #d4af70;
            text-transform: uppercase;
            letter-spacing: 3px;
            font-size: 11px;
            font-weight: bold;
            margin-bottom: 18px;
        }

        .brand-content h1 {
            font-size: clamp(38px, 5vw, 58px);
            line-height: 1.05;
            letter-spacing: -2px;
            margin-bottom: 22px;
        }

        .brand-content h1 span {
            color: #d4af70;
        }

        .brand-content p {
            max-width: 420px;
            color: #a8b1c0;
            line-height: 1.8;
            font-size: 15px;
        }

        .features {
            position: relative;
            display: grid;
            gap: 14px;
        }

        .feature {
            display: flex;
            align-items: center;
            gap: 13px;
            color: #c8ced8;
            font-size: 14px;
        }

        .feature-icon {
            width: 32px;
            height: 32px;
            border: 1px solid rgba(212,175,112,0.30);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #d4af70;
            font-size: 14px;
        }

        

        .login-section {
            padding: 55px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-box {
            width: 100%;
            max-width: 400px;
        }

        .login-heading {
            margin-bottom: 32px;
        }

        .login-heading .small {
            color: #d4af70;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 2px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .login-heading h2 {
            font-size: 32px;
            margin-bottom: 10px;
        }

        .login-heading p {
            color: #8993a3;
            font-size: 14px;
        }

        .error {
            background: rgba(220, 38, 38, 0.12);
            border: 1px solid rgba(248,113,113,0.25);
            color: #fca5a5;
            padding: 13px 15px;
            border-radius: 12px;
            margin-bottom: 22px;
            font-size: 13px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 9px;
            color: #d9dde5;
            font-size: 13px;
            font-weight: 600;
        }

        input {
            width: 100%;
            padding: 15px 16px;
            background: #0b1220;
            border: 1px solid #263246;
            border-radius: 12px;
            color: #f7f3eb;
            font-size: 14px;
            outline: none;
            transition: 0.25s ease;
        }

        input::placeholder {
            color: #667085;
        }

        input:focus {
            border-color: #d4af70;
            box-shadow: 0 0 0 3px rgba(212,175,112,0.08);
        }

        .login-btn {
            width: 100%;
            border: none;
            border-radius: 12px;
            padding: 15px;
            margin-top: 5px;
            background: linear-gradient(135deg, #d4af70, #b88b45);
            color: #0a0f18;
            font-size: 15px;
            font-weight: 800;
            cursor: pointer;
            transition: 0.25s ease;
        }

        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 28px rgba(212,175,112,0.18);
        }

        .demo {
            margin-top: 22px;
            padding: 16px;
            border: 1px solid rgba(212,175,112,0.16);
            background: rgba(212,175,112,0.05);
            border-radius: 13px;
            color: #aeb6c4;
            font-size: 12px;
            line-height: 1.7;
        }

        .demo strong {
            color: #d4af70;
            font-size: 12px;
        }

        .back {
            display: block;
            text-align: center;
            margin-top: 22px;
            color: #9da6b5;
            text-decoration: none;
            font-size: 13px;
            transition: 0.2s ease;
        }

        .back:hover {
            color: #d4af70;
        }


        @media (max-width: 800px) {

            .page {
                grid-template-columns: 1fr;
                max-width: 520px;
            }

            .brand-section {
                padding: 35px;
                min-height: 390px;
                border-right: none;
                border-bottom: 1px solid rgba(212,175,112,0.14);
            }

            .brand-content h1 {
                font-size: 42px;
            }

            .features {
                margin-top: 30px;
            }

            .login-section {
                padding: 35px;
            }
        }

        @media (max-width: 480px) {

            body {
                padding: 12px;
            }

            .page {
                border-radius: 20px;
            }

            .brand-section,
            .login-section {
                padding: 28px 22px;
            }

            .brand-content h1 {
                font-size: 36px;
            }

            .logo-text {
                font-size: 21px;
            }

            .login-heading h2 {
                font-size: 27px;
            }
        }

    </style>

</head>

<body>

<div class="page">

    

    <section class="brand-section">

        <div>

            <div class="logo">

                <div class="logo-mark">
                    IC
                </div>

                <div class="logo-text">
                    Intern<span>Connect</span>
                </div>

            </div>

            <div class="brand-content">

                <div class="eyebrow">
                    Management Portal
                </div>

                <h1>
                    Control the<br>
                    <span>future of talent.</span>
                </h1>

                <p>
                    Manage students, internships and applications
                    through one elegant administration workspace.
                </p>

            </div>

        </div>

        <div class="features">

            <div class="feature">
                <div class="feature-icon">✓</div>
                <span>Manage student profiles</span>
            </div>

            <div class="feature">
                <div class="feature-icon">✓</div>
                <span>Manage internship opportunities</span>
            </div>

            <div class="feature">
                <div class="feature-icon">✓</div>
                <span>Review applications</span>
            </div>

        </div>

    </section>


    

    <section class="login-section">

        <div class="login-box">

            <div class="login-heading">

                <div class="small">
                    Secure Access
                </div>

                <h2>
                    Admin Login
                </h2>

                <p>
                    Sign in to access the InternConnect dashboard.
                </p>

            </div>


            <?php if ($error !== ""): ?>

                <div class="error">
                    <?php echo htmlspecialchars($error); ?>
                </div>

            <?php endif; ?>


            <form method="POST">

                <div class="form-group">

                    <label for="email">
                        Admin Email
                    </label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="admin@internconnect.com"
                        required
                    >

                </div>


                <div class="form-group">

                    <label for="password">
                        Password
                    </label>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Enter your password"
                        required
                    >

                </div>


                <button type="submit" class="login-btn">
                    Sign in to Dashboard →
                </button>

            </form>


            <div class="demo">

                <strong>Demo Access</strong><br>

                Email: admin@internconnect.com<br>

                Password: admin123

            </div>


            <a href="../index.php" class="back">
                ← Back to Main Website
            </a>

        </div>

    </section>

</div>

</body>

</html>