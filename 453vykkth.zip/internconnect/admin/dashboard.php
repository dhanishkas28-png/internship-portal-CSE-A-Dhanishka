<?php
require_once "auth.php";

$applications = $_SESSION["applications"] ?? [];

$totalStudents = 6;
$activeInternships = 12;
$totalApplications = count($applications);

$pendingApplications = 0;
$approvedApplications = 0;
$rejectedApplications = 0;

foreach ($applications as $application) {
    $status = $application["status"] ?? "Pending";

    if ($status === "Pending") {
        $pendingApplications++;
    } elseif ($status === "Approved") {
        $approvedApplications++;
    } elseif ($status === "Rejected") {
        $rejectedApplications++;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard | InternConnect</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background:
                radial-gradient(
                    circle at 10% 10%,
                    rgba(212,175,112,0.06),
                    transparent 30%
                ),
                #080d17;
            color: #f7f3eb;
            min-height: 100vh;
        }

        

        .topbar {
            background: rgba(8,13,23,0.94);
            border-bottom: 1px solid rgba(212,175,112,0.16);
            padding: 18px 42px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            position: sticky;
            top: 0;
            z-index: 100;
            backdrop-filter: blur(15px);
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 13px;
        }

        .logo-mark {
            width: 46px;
            height: 46px;
            border-radius: 13px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(
                135deg,
                #d4af70,
                #b88b45
            );
            color: #090e17;
            font-size: 16px;
            font-weight: 900;
            box-shadow:
                0 8px 22px rgba(212,175,112,0.18);
        }

        .logo-text {
            font-size: 23px;
            font-weight: 800;
        }

        .logo-text span {
            color: #d4af70;
        }

        .admin-label {
            color: #7f8a9b;
            font-size: 11px;
            margin-top: 4px;
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        nav {
            display: flex;
            align-items: center;
            gap: 5px;
            flex-wrap: wrap;
        }

        nav a {
            color: #aeb7c6;
            text-decoration: none;
            padding: 10px 13px;
            border-radius: 9px;
            font-size: 13px;
            transition: 0.25s ease;
        }

        nav a:hover {
            color: #d4af70;
            background: rgba(212,175,112,0.07);
        }

        nav .active {
            color: #d4af70;
            background: rgba(212,175,112,0.08);
        }

        nav .logout {
            color: #fca5a5;
            border: 1px solid rgba(248,113,113,0.18);
            margin-left: 5px;
        }

        nav .logout:hover {
            background: rgba(220,38,38,0.10);
            color: #fca5a5;
        }

    

        .container {
            width: 100%;
            max-width: 1250px;
            margin: auto;
            padding: 38px 25px 60px;
        }

    
        .welcome {
            position: relative;
            overflow: hidden;
            background:
                linear-gradient(
                    135deg,
                    rgba(212,175,112,0.10),
                    rgba(15,23,42,0.78)
                );
            border: 1px solid rgba(212,175,112,0.18);
            border-radius: 24px;
            padding: 34px;
            margin-bottom: 25px;
        }

        .welcome::after {
            content: "";
            position: absolute;
            width: 260px;
            height: 260px;
            border-radius: 50%;
            background: rgba(212,175,112,0.05);
            right: -100px;
            top: -120px;
        }

        .eyebrow {
            color: #d4af70;
            text-transform: uppercase;
            letter-spacing: 2.5px;
            font-size: 10px;
            font-weight: bold;
            margin-bottom: 12px;
        }

        .welcome h1 {
            font-size: 32px;
            letter-spacing: -0.8px;
            margin-bottom: 9px;
        }

        .welcome p {
            color: #8f9aaa;
            font-size: 14px;
            line-height: 1.7;
        }

        
        .stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 17px;
            margin-bottom: 28px;
        }

        .stat-card {
            position: relative;
            overflow: hidden;
            background: #0f1726;
            border: 1px solid #202c40;
            border-radius: 18px;
            padding: 23px;
            transition: 0.25s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            border-color: rgba(212,175,112,0.30);
            box-shadow:
                0 15px 35px rgba(0,0,0,0.20);
        }

        .stat-card::after {
            content: "";
            position: absolute;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: rgba(212,175,112,0.04);
            right: -25px;
            bottom: -30px;
        }

        .stat-title {
            color: #818c9d;
            font-size: 12px;
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 0.8px;
        }

        .stat-number {
            color: #f7f3eb;
            font-size: 31px;
            font-weight: 800;
        }

        .stat-card.blue,
        .stat-card.green,
        .stat-card.orange,
        .stat-card.red {
            border-left: 3px solid #d4af70;
        }

        

        .section {
            background: #0f1726;
            border: 1px solid #202c40;
            border-radius: 21px;
            padding: 27px;
            margin-bottom: 25px;
        }

        .section-title {
            font-size: 19px;
            font-weight: 700;
            margin-bottom: 20px;
            color: #f5f1e9;
        }

        .section-title::after {
            content: "";
            display: block;
            width: 35px;
            height: 2px;
            background: #d4af70;
            margin-top: 9px;
        }

        

        .actions {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 17px;
        }

        .action-card {
            text-decoration: none;
            color: #f7f3eb;
            background: #0b1220;
            border: 1px solid #263246;
            border-radius: 16px;
            padding: 22px;
            transition: 0.25s ease;
        }

        .action-card:hover {
            transform: translateY(-4px);
            border-color: rgba(212,175,112,0.38);
            box-shadow:
                0 15px 30px rgba(0,0,0,0.20);
        }

        .action-icon {
            width: 48px;
            height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(212,175,112,0.08);
            border: 1px solid rgba(212,175,112,0.15);
            border-radius: 13px;
            font-size: 22px;
            margin-bottom: 15px;
        }

        .action-card h3 {
            font-size: 16px;
            margin-bottom: 7px;
        }

        .action-card p {
            color: #7f8a9b;
            font-size: 13px;
            line-height: 1.6;
        }



        .application {
            background: #0b1220;
            border: 1px solid #263246;
            border-radius: 14px;
            padding: 18px;
            margin-bottom: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            transition: 0.2s ease;
        }

        .application:hover {
            border-color: rgba(212,175,112,0.25);
        }

        .application:last-child {
            margin-bottom: 0;
        }

        .application h3 {
            font-size: 15px;
            margin-bottom: 6px;
        }

        .application p {
            color: #7f8a9b;
            font-size: 13px;
        }

        .status {
            padding: 7px 13px;
            border-radius: 30px;
            font-size: 11px;
            font-weight: bold;
            white-space: nowrap;
            border: 1px solid transparent;
        }

        .pending {
            background: rgba(212,175,112,0.10);
            color: #d4af70;
            border-color: rgba(212,175,112,0.18);
        }

        .approved {
            background: rgba(34,197,94,0.09);
            color: #86efac;
            border-color: rgba(34,197,94,0.18);
        }

        .rejected {
            background: rgba(239,68,68,0.09);
            color: #fca5a5;
            border-color: rgba(239,68,68,0.18);
        }

        .empty {
            text-align: center;
            padding: 35px;
            color: #717d8e;
            font-size: 14px;
            background: #0b1220;
            border: 1px dashed #263246;
            border-radius: 14px;
        }

        

        @media (max-width: 950px) {

            .stats {
                grid-template-columns: repeat(2, 1fr);
            }

            .actions {
                grid-template-columns: 1fr;
            }

        }

        @media (max-width: 700px) {

            .topbar {
                padding: 16px 20px;
            }

            nav {
                width: 100%;
            }

            nav a {
                padding: 8px 9px;
                font-size: 12px;
            }

            .container {
                padding: 25px 15px 45px;
            }

            .welcome {
                padding: 25px;
            }

            .welcome h1 {
                font-size: 25px;
            }

            .section {
                padding: 21px;
            }

        }

        @media (max-width: 500px) {

            .stats {
                grid-template-columns: 1fr;
            }

            .brand {
                width: 100%;
            }

            .logo-text {
                font-size: 20px;
            }

            nav {
                gap: 3px;
            }

            nav .logout {
                margin-left: 0;
            }

            .application {
                flex-direction: column;
                align-items: flex-start;
            }

        }

    </style>

</head>

<body>

<header class="topbar">

    <div class="brand">

        <div class="logo-mark">
            IC
        </div>

        <div>

            <div class="logo-text">
                Intern<span>Connect</span>
            </div>

            <div class="admin-label">
                Administrator Panel
            </div>

        </div>

    </div>


    <nav>

        <a href="dashboard.php" class="active">
            Dashboard
        </a>

        <a href="students.php">
            Students
        </a>

        <a href="internships.php">
            Internships
        </a>

        <a href="applications.php">
            Applications
        </a>

        <a href="../logout.php" class="logout">
            Logout
        </a>

    </nav>

</header>


<div class="container">


    

    <div class="welcome">

        <div class="eyebrow">
            Admin Workspace
        </div>

        <h1>
            Welcome, Admin 👋
        </h1>

        <p>
            Manage students, internships and applications
            from one elegant workspace.
        </p>

    </div>




    <div class="stats">


        <div class="stat-card blue">

            <div class="stat-title">
                Total Students
            </div>

            <div class="stat-number">
                <?php echo $totalStudents; ?>
            </div>

        </div>


        <div class="stat-card green">

            <div class="stat-title">
                Active Internships
            </div>

            <div class="stat-number">
                <?php echo $activeInternships; ?>
            </div>

        </div>


        <div class="stat-card orange">

            <div class="stat-title">
                Total Applications
            </div>

            <div class="stat-number">
                <?php echo $totalApplications; ?>
            </div>

        </div>


        <div class="stat-card red">

            <div class="stat-title">
                Pending Applications
            </div>

            <div class="stat-number">
                <?php echo $pendingApplications; ?>
            </div>

        </div>


    </div>


    

    <div class="section">

        <div class="section-title">
            Quick Actions
        </div>

        <div class="actions">


            <a href="students.php" class="action-card">

                <div class="action-icon">
                    👨‍🎓
                </div>

                <h3>
                    Manage Students
                </h3>

                <p>
                    View and search registered students.
                </p>

            </a>


            <a href="internships.php" class="action-card">

                <div class="action-icon">
                    💼
                </div>

                <h3>
                    Manage Internships
                </h3>

                <p>
                    View available internship opportunities.
                </p>

            </a>


            <a href="applications.php" class="action-card">

                <div class="action-icon">
                    📄
                </div>

                <h3>
                    Manage Applications
                </h3>

                <p>
                    Review, approve or reject applications.
                </p>

            </a>


        </div>

    </div>


    

    <div class="section">

        <div class="section-title">
            Application Overview
        </div>


        <?php if (!empty($applications)): ?>


            <?php foreach (array_reverse($applications) as $application): ?>


                <?php

                $status = $application["status"] ?? "Pending";

                if ($status === "Approved") {

                    $statusClass = "approved";

                } elseif ($status === "Rejected") {

                    $statusClass = "rejected";

                } else {

                    $statusClass = "pending";

                }

                ?>


                <div class="application">

                    <div>

                        <h3>

                            <?php

                            echo htmlspecialchars(
                                $application["student_name"] ?? "Student"
                            );

                            ?>

                        </h3>


                        <p>

                            <?php

                            echo htmlspecialchars(
                                $application["internship"] ?? "Internship"
                            );

                            ?>

                            —

                            <?php

                            echo htmlspecialchars(
                                $application["company"] ?? ""
                            );

                            ?>

                        </p>

                    </div>


                    <div class="status <?php echo $statusClass; ?>">

                        <?php echo htmlspecialchars($status); ?>

                    </div>

                </div>


            <?php endforeach; ?>


        <?php else: ?>


            <div class="empty">

                No applications submitted yet.

            </div>


        <?php endif; ?>


    </div>


    
    <div class="section">

        <div class="section-title">
            Application Status
        </div>


        <div class="stats">


            <div class="stat-card orange">

                <div class="stat-title">
                    Pending
                </div>

                <div class="stat-number">
                    <?php echo $pendingApplications; ?>
                </div>

            </div>


            <div class="stat-card green">

                <div class="stat-title">
                    Approved
                </div>

                <div class="stat-number">
                    <?php echo $approvedApplications; ?>
                </div>

            </div>


            <div class="stat-card red">

                <div class="stat-title">
                    Rejected
                </div>

                <div class="stat-number">
                    <?php echo $rejectedApplications; ?>
                </div>

            </div>


        </div>

    </div>


</div>

</body>
</html>