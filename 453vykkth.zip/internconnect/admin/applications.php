<?php

require_once "auth.php";


if (isset($_GET["action"]) && isset($_GET["id"])) {

    $id = (int)$_GET["id"];
    $action = $_GET["action"];

    if (isset($_SESSION["applications"][$id])) {

        if ($action === "approve") {
            $_SESSION["applications"][$id]["status"] = "Approved";
        }

        if ($action === "reject") {
            $_SESSION["applications"][$id]["status"] = "Rejected";
        }
    }

    header("Location: applications.php");
    exit();
}


$applications = $_SESSION["applications"] ?? [];

$totalApplications = count($applications);

$pendingApplications = 0;
$approvedApplications = 0;
$rejectedApplications = 0;

foreach ($applications as $application) {

    $status = $application["status"] ?? "Pending";

    if ($status === "Pending") {
        $pendingApplications++;
    } elseif ($status === "Approved") {
        $approvedApplications++;
    } elseif ($status === "Rejected") {
        $rejectedApplications++;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Applications | InternConnect Admin</title>


<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

:root {
    --navy: #0b1220;
    --navy-light: #111b2e;
    --navy-card: #151f32;
    --gold: #d4af70;
    --gold-light: #e7c98e;
    --cream: #f5f0e6;
    --muted: #9ca8ba;
    --border: rgba(212,175,112,0.18);
    --green: #55d68a;
    --red: #ef6b73;
    --orange: #e7aa55;
}

html {
    scroll-behavior: smooth;
}

body {

    font-family:
        Inter,
        "Segoe UI",
        Arial,
        sans-serif;

    background:
        radial-gradient(
            circle at top right,
            rgba(212,175,112,0.08),
            transparent 35%
        ),
        var(--navy);

    color: var(--cream);

    min-height: 100vh;
}



.topbar {

    position: sticky;

    top: 0;

    z-index: 100;

    min-height: 76px;

    padding: 0 5%;

    display: flex;

    justify-content: space-between;

    align-items: center;

    background:
        rgba(11,18,32,0.94);

    backdrop-filter: blur(18px);

    border-bottom:
        1px solid var(--border);
}



.logo {

    display: flex;

    align-items: center;

    gap: 12px;

    text-decoration: none;

    color: var(--cream);

    font-size: 20px;

    font-weight: 700;

    letter-spacing: 0.4px;
}

.logo-mark {

    width: 42px;

    height: 42px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 12px;

    background:
        linear-gradient(
            135deg,
            var(--gold),
            #a9803e
        );

    color: var(--navy);

    font-size: 16px;

    font-weight: 900;

    box-shadow:
        0 8px 25px
        rgba(212,175,112,0.18);
}

.logo span {
    color: var(--gold);
}



nav {

    display: flex;

    align-items: center;

    gap: 7px;
}

nav a {

    text-decoration: none;

    color: var(--muted);

    font-size: 13px;

    font-weight: 600;

    padding: 10px 13px;

    border-radius: 9px;

    transition: 0.25s ease;
}

nav a:hover {

    color: var(--cream);

    background:
        rgba(212,175,112,0.08);
}

nav a.active {

    color: var(--gold);

    background:
        rgba(212,175,112,0.10);
}

nav .logout {

    color: #f08086;

    margin-left: 5px;
}

nav .logout:hover {

    background:
        rgba(239,107,115,0.10);

    color: #ff9298;
}




.container {

    width: 90%;

    max-width: 1280px;

    margin: 0 auto;

    padding: 50px 0 70px;
}



.header {

    display: flex;

    justify-content: space-between;

    align-items: flex-end;

    gap: 20px;

    margin-bottom: 30px;
}

.eyebrow {

    color: var(--gold);

    font-size: 11px;

    text-transform: uppercase;

    letter-spacing: 2px;

    font-weight: 700;

    margin-bottom: 10px;
}

.header h1 {

    font-family: Georgia, serif;

    font-size: clamp(30px, 4vw, 42px);

    font-weight: 500;

    letter-spacing: -0.5px;

    margin-bottom: 8px;
}

.header p {

    color: var(--muted);

    font-size: 14px;
}

.stats {

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 16px;

    margin-bottom: 25px;
}

.stat-card {

    position: relative;

    overflow: hidden;

    padding: 22px;

    min-height: 140px;

    background:
        linear-gradient(
            145deg,
            rgba(21,31,50,0.96),
            rgba(15,25,42,0.96)
        );

    border:
        1px solid var(--border);

    border-radius: 17px;

    box-shadow:
        0 18px 50px
        rgba(0,0,0,0.20);

    transition: 0.25s ease;
}

.stat-card:hover {

    transform: translateY(-3px);

    border-color:
        rgba(212,175,112,0.35);
}

.stat-card::after {

    content: "";

    position: absolute;

    width: 100px;

    height: 100px;

    right: -35px;

    top: -35px;

    border-radius: 50%;

    background:
        rgba(212,175,112,0.06);
}

.stat-icon {

    width: 42px;

    height: 42px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 12px;

    background:
        rgba(212,175,112,0.10);

    border:
        1px solid rgba(212,175,112,0.14);

    font-size: 19px;

    margin-bottom: 14px;
}

.stat-card h3 {

    font-size: 29px;

    font-weight: 700;

    margin-bottom: 4px;

    color: var(--cream);
}

.stat-card p {

    color: var(--muted);

    font-size: 12px;
}

.stat-card.total {
    border-top: 2px solid var(--gold);
}

.stat-card.pending {
    border-top: 2px solid var(--orange);
}

.stat-card.approved {
    border-top: 2px solid var(--green);
}

.stat-card.rejected {
    border-top: 2px solid var(--red);
}




.search-box {

    position: relative;

    background:
        rgba(21,31,50,0.82);

    border:
        1px solid var(--border);

    border-radius: 16px;

    padding: 17px;

    margin-bottom: 25px;

    box-shadow:
        0 15px 40px
        rgba(0,0,0,0.15);
}

.search-box input {

    width: 100%;

    padding: 15px 18px;

    border:
        1px solid
        rgba(212,175,112,0.16);

    border-radius: 11px;

    background:
        #0d1728;

    color: var(--cream);

    font-size: 14px;

    outline: none;

    transition: 0.25s ease;
}

.search-box input::placeholder {
    color: #6f7d91;
}

.search-box input:focus {

    border-color: var(--gold);

    box-shadow:
        0 0 0 3px
        rgba(212,175,112,0.08);
}




.application-card {

    position: relative;

    overflow: hidden;

    background:
        linear-gradient(
            145deg,
            rgba(21,31,50,0.98),
            rgba(14,24,40,0.98)
        );

    border:
        1px solid var(--border);

    border-radius: 20px;

    padding: 28px;

    margin-bottom: 20px;

    box-shadow:
        0 20px 60px
        rgba(0,0,0,0.20);

    transition: 0.3s ease;
}

.application-card:hover {

    border-color:
        rgba(212,175,112,0.30);

    transform: translateY(-2px);
}


.application-top {

    display: flex;

    justify-content: space-between;

    align-items: flex-start;

    gap: 20px;

    padding-bottom: 20px;

    border-bottom:
        1px solid
        rgba(255,255,255,0.06);

    margin-bottom: 20px;
}

.student-info h2 {

    font-size: 20px;

    font-weight: 650;

    margin-bottom: 8px;

    color: var(--cream);
}

.student-info h2:first-letter {
    color: var(--gold);
}

.student-info p {

    color: var(--muted);

    font-size: 12px;
}


.status {

    padding: 8px 14px;

    border-radius: 30px;

    font-size: 11px;

    font-weight: 700;

    letter-spacing: 0.5px;

    white-space: nowrap;

    border: 1px solid;
}

.status-pending {

    color: var(--orange);

    background:
        rgba(231,170,85,0.09);

    border-color:
        rgba(231,170,85,0.22);
}

.status-approved {

    color: var(--green);

    background:
        rgba(85,214,138,0.09);

    border-color:
        rgba(85,214,138,0.22);
}

.status-rejected {

    color: var(--red);

    background:
        rgba(239,107,115,0.09);

    border-color:
        rgba(239,107,115,0.22);
}



.details-grid {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 12px;

    margin-bottom: 18px;
}

.detail {

    background:
        rgba(255,255,255,0.025);

    border:
        1px solid
        rgba(255,255,255,0.05);

    padding: 15px;

    border-radius: 12px;

    transition: 0.2s ease;
}

.detail:hover {

    border-color:
        rgba(212,175,112,0.16);
}

.detail strong {

    display: block;

    color: #78869a;

    font-size: 10px;

    text-transform: uppercase;

    letter-spacing: 1.1px;

    margin-bottom: 7px;
}

.detail span {

    color: #e6e9ef;

    font-size: 13px;

    line-height: 1.5;

    word-break: break-word;
}


.internship-box {

    background:
        linear-gradient(
            135deg,
            rgba(212,175,112,0.10),
            rgba(212,175,112,0.035)
        );

    border:
        1px solid
        rgba(212,175,112,0.18);

    padding: 18px;

    border-radius: 13px;

    margin-bottom: 17px;
}

.internship-box strong {

    color: var(--gold);

    display: block;

    font-size: 12px;

    letter-spacing: 0.5px;

    margin-bottom: 7px;
}

.internship-box span {

    color: #dce1e9;

    font-size: 13px;

    line-height: 1.6;
}



.resume {

    background:
        rgba(255,255,255,0.025);

    border:
        1px solid
        rgba(255,255,255,0.06);

    padding: 14px 16px;

    border-radius: 11px;

    margin-bottom: 17px;

    color: var(--muted);

    font-size: 13px;
}

.resume strong {

    color: #dfe4ec;

    margin-right: 6px;
}

.resume-name {

    color: var(--gold);

    font-weight: 600;
}




.cover-letter {

    background:
        rgba(255,255,255,0.02);

    border:
        1px solid
        rgba(255,255,255,0.06);

    padding: 18px;

    border-radius: 13px;

    margin-bottom: 18px;
}

.cover-letter h3 {

    color: var(--cream);

    font-size: 14px;

    margin-bottom: 10px;
}

.cover-letter p {

    color: var(--muted);

    font-size: 13px;

    line-height: 1.7;

    white-space: pre-wrap;
}



.actions {

    display: flex;

    gap: 10px;

    border-top:
        1px solid
        rgba(255,255,255,0.06);

    padding-top: 18px;
}

.action-btn {

    text-decoration: none;

    display: inline-flex;

    align-items: center;

    justify-content: center;

    padding: 10px 17px;

    border-radius: 10px;

    font-size: 12px;

    font-weight: 700;

    transition: 0.25s ease;

    border: 1px solid transparent;
}

.approve-btn {

    background:
        rgba(85,214,138,0.10);

    color: var(--green);

    border-color:
        rgba(85,214,138,0.18);
}

.approve-btn:hover {

    background:
        rgba(85,214,138,0.18);

    transform: translateY(-1px);
}

.reject-btn {

    background:
        rgba(239,107,115,0.10);

    color: var(--red);

    border-color:
        rgba(239,107,115,0.18);
}

.reject-btn:hover {

    background:
        rgba(239,107,115,0.18);

    transform: translateY(-1px);
}


.no-applications {

    background:
        linear-gradient(
            145deg,
            rgba(21,31,50,0.96),
            rgba(14,24,40,0.96)
        );

    border:
        1px solid var(--border);

    padding: 75px 30px;

    text-align: center;

    border-radius: 20px;

    box-shadow:
        0 20px 60px
        rgba(0,0,0,0.18);
}

.empty-icon {

    width: 70px;

    height: 70px;

    margin: 0 auto 18px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 20px;

    background:
        rgba(212,175,112,0.08);

    border:
        1px solid
        rgba(212,175,112,0.15);

    font-size: 28px;
}

.no-applications h2 {

    font-family: Georgia, serif;

    font-weight: 500;

    color: var(--cream);

    margin-bottom: 9px;
}

.no-applications p {

    color: var(--muted);

    font-size: 13px;
}


@media(max-width: 1000px) {

    .stats {
        grid-template-columns:
            repeat(2, 1fr);
    }

    .details-grid {
        grid-template-columns:
            repeat(2, 1fr);
    }

    nav a {
        padding: 9px;
    }
}


@media(max-width: 720px) {

    .topbar {

        flex-direction: column;

        gap: 15px;

        padding: 16px 5%;
    }

    nav {

        flex-wrap: wrap;

        justify-content: center;
    }

    .container {

        width: 92%;

        padding-top: 35px;
    }

    .header {

        align-items: flex-start;

        flex-direction: column;
    }

    .stats {

        grid-template-columns: 1fr;
    }

    .details-grid {

        grid-template-columns: 1fr;
    }

    .application-top {

        flex-direction: column;
    }

    .actions {

        flex-direction: column;
    }

    .action-btn {

        width: 100%;
    }
}


@media(max-width: 450px) {

    .logo {
        font-size: 18px;
    }

    .logo-mark {
        width: 38px;
        height: 38px;
    }

    nav {
        gap: 2px;
    }

    nav a {
        font-size: 11px;
    }

    .application-card {
        padding: 20px;
    }

}




::-webkit-scrollbar {
    width: 7px;
}

::-webkit-scrollbar-track {
    background: var(--navy);
}

::-webkit-scrollbar-thumb {

    background:
        rgba(212,175,112,0.35);

    border-radius: 10px;
}

::-webkit-scrollbar-thumb:hover {

    background:
        rgba(212,175,112,0.60);
}

</style>

</head>


<body>




<header class="topbar">

    <a href="dashboard.php" class="logo">

        <div class="logo-mark">
            IC
        </div>

        <div>
            Intern<span>Connect</span>
        </div>

    </a>


    <nav>

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="students.php">
            Students
        </a>

        <a href="internships.php">
            Internships
        </a>

        <a href="applications.php" class="active">
            Applications
        </a>

        <a href="../index.php">
            Main Website
        </a>

        <a href="../logout.php" class="logout">
            Logout
        </a>

    </nav>

</header>





<div class="container">


    <!-- HEADER -->

    <div class="header">

        <div>

            <div class="eyebrow">
                Administration
            </div>

            <h1>
                Applications
            </h1>

            <p>
                Review, approve and manage student internship applications.
            </p>

        </div>

    </div>




    <div class="stats">


        <div class="stat-card total">

            <div class="stat-icon">
                📋
            </div>

            <h3>
                <?php echo $totalApplications; ?>
            </h3>

            <p>
                Total Applications
            </p>

        </div>


        <div class="stat-card pending">

            <div class="stat-icon">
                ⏳
            </div>

            <h3>
                <?php echo $pendingApplications; ?>
            </h3>

            <p>
                Pending Applications
            </p>

        </div>


        <div class="stat-card approved">

            <div class="stat-icon">
                ✓
            </div>

            <h3>
                <?php echo $approvedApplications; ?>
            </h3>

            <p>
                Approved Applications
            </p>

        </div>


        <div class="stat-card rejected">

            <div class="stat-icon">
                ×
            </div>

            <h3>
                <?php echo $rejectedApplications; ?>
            </h3>

            <p>
                Rejected Applications
            </p>

        </div>

    </div>



    <div class="search-box">

        <input
            type="text"
            id="searchInput"
            placeholder="🔍  Search student, email, college or internship..."
            onkeyup="searchApplications()"
        >

    </div>





    <div id="applicationsContainer">


    <?php if (empty($applications)): ?>


        <div class="no-applications">

            <div class="empty-icon">
                📋
            </div>

            <h2>
                No Applications Yet
            </h2>

            <p>
                Student applications will appear here after submission.
            </p>

        </div>


    <?php else: ?>


        <?php foreach ($applications as $index => $application): ?>


            <?php

            $status =
                $application["status"] ?? "Pending";

            $statusClass = "status-pending";

            if ($status === "Approved") {
                $statusClass = "status-approved";
            } elseif ($status === "Rejected") {
                $statusClass = "status-rejected";
            }

            ?>


            <div
                class="application-card"
                data-search="<?php

                    echo htmlspecialchars(

                        strtolower(

                            ($application["student_name"] ?? "") . " " .

                            ($application["email"] ?? "") . " " .

                            ($application["college"] ?? "") . " " .

                            ($application["internship"] ?? "") . " " .

                            ($application["company"] ?? "") . " " .

                            ($application["skills"] ?? "")

                        )

                    );

                ?>"
            >


                <!-- TOP -->

                <div class="application-top">

                    <div class="student-info">

                        <h2>

                            👤

                            <?php

                            echo htmlspecialchars(
                                $application["student_name"]
                                ?? "Unknown Student"
                            );

                            ?>

                        </h2>


                        <p>

                            Applied on:

                            <?php

                            echo htmlspecialchars(

                                $application["applied_at"]
                                ?? "N/A"

                            );

                            ?>

                        </p>

                    </div>


                    <div
                        class="status <?php echo $statusClass; ?>"
                    >

                        <?php echo htmlspecialchars($status); ?>

                    </div>

                </div>



                <!-- STUDENT DETAILS -->

                <div class="details-grid">


                    <div class="detail">

                        <strong>
                            Email
                        </strong>

                        <span>

                            <?php

                            echo htmlspecialchars(

                                $application["email"]
                                ?? "N/A"

                            );

                            ?>

                        </span>

                    </div>


                    <div class="detail">

                        <strong>
                            Phone
                        </strong>

                        <span>

                            <?php

                            echo htmlspecialchars(

                                $application["phone"]
                                ?? "N/A"

                            );

                            ?>

                        </span>

                    </div>


                    <div class="detail">

                        <strong>
                            College
                        </strong>

                        <span>

                            <?php

                            echo htmlspecialchars(

                                $application["college"]
                                ?? "N/A"

                            );

                            ?>

                        </span>

                    </div>


                    <div class="detail">

                        <strong>
                            Skills
                        </strong>

                        <span>

                            <?php

                            echo htmlspecialchars(

                                $application["skills"]
                                ?? "N/A"

                            );

                            ?>

                        </span>

                    </div>


                    <div class="detail">

                        <strong>
                            Location
                        </strong>

                        <span>

                            <?php

                            echo htmlspecialchars(

                                $application["location"]
                                ?? "N/A"

                            );

                            ?>

                        </span>

                    </div>


                    <div class="detail">

                        <strong>
                            Duration
                        </strong>

                        <span>

                            <?php

                            echo htmlspecialchars(

                                $application["duration"]
                                ?? "N/A"

                            );

                            ?>

                        </span>

                    </div>

                </div>



                <!-- INTERNSHIP -->

                <div class="internship-box">

                    <strong>
                        💼 Applied Internship
                    </strong>

                    <span>

                        <?php

                        echo htmlspecialchars(

                            $application["internship"]
                            ?? "N/A"

                        );

                        ?>

                        &nbsp; — &nbsp;

                        <?php

                        echo htmlspecialchars(

                            $application["company"]
                            ?? "N/A"

                        );

                        ?>

                        &nbsp; | &nbsp;

                        <?php

                        echo htmlspecialchars(

                            $application["stipend"]
                            ?? "N/A"

                        );

                        ?>

                    </span>

                </div>



                <!-- RESUME -->

                <?php if (
                    !empty($application["resume"])
                ): ?>

                    <div class="resume">

                        <strong>
                            📄 Resume:
                        </strong>

                        <span class="resume-name">

                            <?php

                            echo htmlspecialchars(

                                $application["resume"]

                            );

                            ?>

                        </span>

                    </div>

                <?php else: ?>

                    <div class="resume">

                        <strong>
                            📄 Resume:
                        </strong>

                        <span>
                            Not provided
                        </span>

                    </div>

                <?php endif; ?>



                <!-- COVER LETTER -->

                <?php if (
                    !empty($application["cover_letter"])
                ): ?>

                    <div class="cover-letter">

                        <h3>
                            📝 Cover Letter
                        </h3>

                        <p>

                            <?php

                            echo htmlspecialchars(

                                $application["cover_letter"]

                            );

                            ?>

                        </p>

                    </div>

                <?php endif; ?>



                <!-- ACTIONS -->

                <?php if ($status === "Pending"): ?>

                    <div class="actions">


                        <a
                            href="applications.php?action=approve&id=<?php echo $index; ?>"
                            class="action-btn approve-btn"
                            onclick="return confirm('Are you sure you want to approve this application?');"
                        >
                            ✓ &nbsp; Approve
                        </a>


                        <a
                            href="applications.php?action=reject&id=<?php echo $index; ?>"
                            class="action-btn reject-btn"
                            onclick="return confirm('Are you sure you want to reject this application?');"
                        >
                            × &nbsp; Reject
                        </a>


                    </div>

                <?php else: ?>

                    <div class="actions">

                        <?php if ($status === "Approved"): ?>

                            <span class="action-btn approve-btn">
                                ✓ &nbsp; Application Approved
                            </span>

                        <?php elseif ($status === "Rejected"): ?>

                            <span class="action-btn reject-btn">
                                × &nbsp; Application Rejected
                            </span>

                        <?php endif; ?>

                    </div>

                <?php endif; ?>


            </div>


        <?php endforeach; ?>


    <?php endif; ?>


    </div>

</div>



<script>

function searchApplications() {

    var input =
        document
        .getElementById("searchInput")
        .value
        .toLowerCase()
        .trim();


    var cards =
        document
        .getElementsByClassName("application-card");


    for (
        var i = 0;
        i < cards.length;
        i++
    ) {

        var searchData =
            cards[i]
            .getAttribute("data-search");


        if (
            searchData.includes(input)
        ) {

            cards[i].style.display =
                "block";

        } else {

            cards[i].style.display =
                "none";

        }

    }

}

</script>


</body>

</html>